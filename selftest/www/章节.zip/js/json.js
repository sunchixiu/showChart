var homeworkjson = {};
homeworkjson = {
    "id": "",
    "title": "卷一1",
    "desc": "",
    "type": "",
    "examparts": [
        {
            "title": "",
            "examsections": [
                {
                    "title": "一、填空题",
                    "index": 0,
                    "questions": [
                        {
                            "id": "1123000",
                            "innerid": "",
                            "index": 1,
                            "typeid": "e487b4e564cf4589849ada35a453141f",
                            "typename": "填空题",
                            "content": "<ruby style=\"ruby-align:center\">看<rp>(</rp><rt style=\"font-size:10.0pt;font-family: 黑体;layout-grid-mode:line\">kàn</rt><rp>)</rp></ruby><ruby style=\"ruby-align:center\">图<rp>(</rp><rt style=\"font-size:10.0pt;font-family:黑体;layout-grid-mode:line\">tú</rt><rp>)</rp></ruby><ruby style=\"ruby-align:center\">说<rp>(</rp><rt style=\"font-size:10.0pt;font-family: 黑体;layout-grid-mode:line\">shuō</rt><rp>)</rp></ruby><ruby style=\"ruby-align:center\">一<rp>(</rp><rt style=\"font-size:10.0pt;font-family:黑体;layout-grid-mode:line\">yī</rt><rp>)</rp></ruby><ruby style=\"ruby-align:center\">说<rp>(</rp><rt style=\"font-size:10.0pt;font-family: 黑体;layout-grid-mode:line\">shuō</rt><rp>)</rp></ruby>。 <br>  <br><img style=\"vertical-align:middle\" align=\"absmiddle\" src=\"data:image/gif;base64,R0lGODdhMAA7AHcAACH+GlNvZnR3YXJlOiBNaWNyb3NvZnQgT2ZmaWNlACwAAAAAMAA7AIUAAAAAGQgAABAIGTEIQhkhCBApGTEhIRApQhkpQlJSShlKSlJKa1pSa5RzSlpra1pza4xzjIRzrZyce4yUnKWMpYScta2c1rW9vbW9vd69zrXO1tbF1u/F77XF7+bm1ubm7+/v9///7/////8BAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMG/8CRcEgsGo/IpHIpBIE2GBBzOt0wCoCsdrv4UL+jyGJLLgMOC+KHEvGCRxaseU6OZA7awVQqxNP/c2lMGAUjG4CIdBtKIQAWH4mRZhhJEQAgkplaBQFJDwAGmppLY6JmAQIBc0oQplkLEBWLRaVaFpWaAwa3SpgAAVgQSJ9/CwYHCQ+USwaLGq+GfEW+dMJgFmIgGRYPgkgMgAchQxgDFEqz0UyOoXQRQwYjC9JHGweGbkrvgO9gBgwfNlygAmiZEAAGj2hIkwBEQiV/9Ax5AGGAhiQWACyosIaKHDNFEEgJkK/IoSyY0ikBZ8abkARZMFg7okVmgikUuOQEgIBWlv8BPZEkGKOBQdB10IQMAFASAgI/SSq02gCTys4NT0Z8qDBCGogFjQAUETGCwrks47qNILskS7R7RPgwaCXWiAgLCzY86DqCwUMkGRdRdenkbpabR7AJCeEkQyF6SADsjXeRrxMpGBAimcX4MoBzU9L09OpkwwevSE6DOC0BAoGSGC1kmLC462WsTpCAYCBIShoMe6fEi1B5benLIiA/KLDgHZ/mLyEnidfE8mXpzTsRkTrkg8slByJQ8FZYirQQH8SDFoK3CAVeUyxQqBC8Olsi74k4TdBvSKE3GCxAgXRIhLDAXiA4QAR6DHxB1jgaHEDBaUpkJM0DEhRxgEpghID/gAEICKiBNOOtJ0RO0/T3RhjjYCCfGAho8YAFBlBwgAAQQKDdEBKt+EECxZEDZHMJ4OWhXiqOwB0YHyCzQSgCigGAMJc4gcEGIRjgwTzTKABGAAxEYIAUIWhgwZUhRBDAiKZ5cBOQ4hVhwUxMiJhBBXMN1c0Cc6G3gQenPbABBBQsVMSYVOymQQYXbODoBhZEqpoHWGEVwaUbnPNfWQFwqMQEdmCgAQemYXWaowE5CmiAYN0kTEZHLSHFIbJp8CilIDSAFQcdfADonyC4Jo8FF3ymAXVWaXBBBqMG9EEHICAQQpsBPYGVjQ7NMwAIHOwoXAaMokoplmP+aVoHjj5x7eSPGkAQwQabJsEWAhdgcKWqlYJAgJ9P+BoQoPIJJBYCTlExAAbgLopqqSAUEEKv5j5b7QYDQAqTLuMwEUACfjX6p69YXdDcBxxQ+q+vq0mg0QMDfvFABBjY2EAUEmO1AFj5XnZnBAN0E+QUIUAAqAfTDlABt1iBQ8GV9kbAwAFAtWyIiV9YYUAUIzQwD6UGXABBmHNBgIEbyV32V6JitDHCyyAoc1kI44DQmROqBbuiSRaNUGMD1tZ9nd/y3G3EuyOA+QQIHlyneFflfCf4EBQQautqij8xXgQWEPj4EKvZCqkG9kaqAWyblz5FEAA7\"><br><br>",
                            "subquestions": [
                                {
                                    "id": "a0c9dd2808ae5da26a90eecb20f7931f",
                                    "innerid": "",
                                    "index": 1,
                                    "typeid": "e487b4e564cf4589849ada35a453141f",
                                    "typename": "填空题",
                                    "isobjective": false,
                                    "content": "鼻子在嘴巴的（　　）面。<br><br>",
                                    "score": "1",
                                    "selectitems": [

                                    ],
                                    "answer": "上",
                                    "diff": "1",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "119210",
                                                "name": "相对位置（上下、左右、前后）"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96871",
                                                "name": "1.上、下、前后"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                },
                                {
                                    "id": "0522e58dc4db5a4e29fa3db3af691c75",
                                    "innerid": "",
                                    "index": 2,
                                    "typeid": "e487b4e564cf4589849ada35a453141f",
                                    "typename": "填空题",
                                    "isobjective": false,
                                    "content": "嘴巴在鼻子的（　　）面。<br><br>",
                                    "score": "1",
                                    "selectitems": [

                                    ],
                                    "answer": "下",
                                    "diff": "1",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "119210",
                                                "name": "相对位置（上下、左右、前后）"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96871",
                                                "name": "1.上、下、前后"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                },
                                {
                                    "id": "55893787cb404d2c3e7e53a7ec8c8381",
                                    "innerid": "",
                                    "index": 3,
                                    "typeid": "e487b4e564cf4589849ada35a453141f",
                                    "typename": "填空题",
                                    "isobjective": false,
                                    "content": "眉毛的（　　）面是眼睛。<br><br>",
                                    "score": "1",
                                    "selectitems": [

                                    ],
                                    "answer": "下",
                                    "diff": "1",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "119210",
                                                "name": "相对位置（上下、左右、前后）"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96871",
                                                "name": "1.上、下、前后"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                },
                                {
                                    "id": "6dc1a33059ad9092a29e2801e970ee17",
                                    "innerid": "",
                                    "index": 4,
                                    "typeid": "e487b4e564cf4589849ada35a453141f",
                                    "typename": "填空题",
                                    "isobjective": false,
                                    "content": "眼睛的（　　）面是眉毛。",
                                    "score": "1",
                                    "selectitems": [

                                    ],
                                    "answer": "上",
                                    "diff": "1",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "119210",
                                                "name": "相对位置（上下、左右、前后）"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96871",
                                                "name": "1.上、下、前后"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                }
                            ],
                            "score": 4,
                            "answer": "",
                            "diff": 0,
                            "analysis": "",
                            "extend": {

                            }
                        },
                        {
                            "id": "1123005",
                            "innerid": "",
                            "index": 2,
                            "typeid": "e487b4e564cf4589849ada35a453141f",
                            "typename": "填空题",
                            "content": "<ruby style=\"ruby-align:center\">看<rp>(</rp><rt style=\"font-size:10.0pt;font-family: 黑体;layout-grid-mode:line\">kàn</rt><rp>)</rp></ruby><ruby style=\"ruby-align:center\">图<rp>(</rp><rt style=\"font-size:10.0pt;font-family:黑体;layout-grid-mode:line\">tú</rt><rp>)</rp></ruby><ruby style=\"ruby-align:center\">填<rp>(</rp><rt style=\"font-size:10.0pt;font-family: 黑体;layout-grid-mode:line\">tián</rt><rp>)</rp></ruby><ruby style=\"ruby-align:center\">上<rp>(</rp><rt style=\"font-size:10.0pt;font-family:黑体;layout-grid-mode:line\">shàng</rt><rp>)</rp></ruby><ruby style=\"ruby-align:center\">前<rp>(</rp><rt style=\"font-size:10.0pt;font-family: 黑体;layout-grid-mode:line\">qián</rt><rp>)</rp></ruby><ruby style=\"ruby-align:center\">和<rp>(</rp><rt style=\"font-size:10.0pt;font-family:黑体;layout-grid-mode:line\">hé</rt><rp>)</rp></ruby><ruby style=\"ruby-align:center\">后<rp>(</rp><rt style=\"font-size:10.0pt;font-family: 黑体;layout-grid-mode:line\">hòu</rt><rp>)</rp></ruby>。 <br>  <br><img style=\"vertical-align:middle\" align=\"absmiddle\" src=\"data:image/gif;base64,R0lGODdhIwHeAHcAACH+GlNvZnR3YXJlOiBNaWNyb3NvZnQgT2ZmaWNlACwAAAAAIwHeAIUAAAAAEAgQGRAAAAgQCAgZEBAICCEZIRAQMRkQISEhGSExMRApKSk6Ojo6OkIxUkpaUlJKWlJKSkpKWnNjY1pra2tze3N7hISEhIyEnJyMlIycpZyljJStraWtrbW1vbW9xcXOzsXW1tbW3u/m3t7v5u/v9//v9+//9/////8BAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMG/8CUcEgsGo/IpHLJbDqf0Kh0Sq1ar9isdsvter/gsHhMLpvP6LR6zW67i6FN6E2v2+/nEQVS6YA8EBYYH3iFhoeISYFHJSQbDCWJkpOUagokTAyYlZydnlcKTwyfpKWmRw1MG0MXc6evsJQbHZmbKRCxubp4qUwRGRRCDrvExWohGEyDKR8TKRKktsbTaxUjTKFCFoKfJAHU4E+RSeNN0EobGLQpJRUAnyEACeH0S/FJDQJO50kKDhbjMOjrFCKAgnn1EhoJMdAICQAYBEmooITfEQm4IIgQAqCCNEke5Cn4prCkEBIDkADAleJhMkWKMqTAACCCkA4XVlHqIDLAS/+T9SCiTNFrSANCowAQUjKsyIYKE1x1mLDOmk5JGXquA0rvnjeOQyzITLEBwNUkFmfKKbI1RIN3kmgmYABgK9dwDGiFSJnCwkBXFgDEk3AtybIhEC58LIKBYiIKABSMBHG3XgmSXzm+xDBgw1qaANISKZpiwgcLSSw0+GlIQoAEBwJsrEyPZAoRcFNUaBBCgqsUACgzU1JhaYoOZ+F0EJGcjgkhDAQcFFCYNjgJtoYKKVG9T8snl4ZUGJXEg907sKdbr/ecXQjc5QUIYL1EwThHSDA4wCD8TjzpApC2Xj0ghLbECB09wdtxyXVQgU8pUNCeHR+8NlJTA5ZU3RKLEWf/Xn9CfODAOQK+EZhkAqCW4YpXQADAhtvpVGIbEFgIIYs4UrFBAvedp4cdDBg0WY5ETgHQEIIRQUGHQ5ywXRgmkCBAAgcdwGSRWCLBUgojuFhYBxi2wdMBCQSY5ZlKfADBRAkcRRZFDVRwgGNKYICRkynguUVgVAawJZqADhGBiil4MFMD/GDigJ5HQEDCPDNWMU6QBwUwVqCYUtBcEg0ZUQIGI/BEAp1ZiCDAAdOBiCmaHpDKBAnBIHHBLQW5aoUGIqG66q6d7lNOEYRaMMqEUrRXY5827Qroc706YcKfeZLFgQkhkKARFqYKGcCmyhaZAQdH2BqWENCStcpRGsAo/84QuFZpZbeYEqBlEq2kcOlNybSqxVt9igYvluocQQKhRqBgE35CYPBSpFEUJAADI93775nZGFEvPs+oWIFOHmEBGZVTXjlxjuKmEOYRF1BQQjAYXMXwEng+alACAcQ6cqAKEDuEv0SIkOx8Q2Dwm5EASJcAAcbdDGhgRnTJhL8Vr8vOSJIF8LLSRELwQVoaDI3Eyc+IrERgqNLMLdZFihDMBwpEdIFATTC9s6own1QmAiM18CvaaDaktYMpeJ3f1kLYBwUKQrhT9rZ8r2rBUqfddrYRIGxAAqJTfCDAzFbv3XiWJPCTzQaGOtEOFSVIIFKZk3+eI3nMOICJ0FDwjP/EOLiSOZIEnruOpYDIRJCbE1dTHluVAiRthuC+cxJpB8UTYXuT26lOZQIDEIxGaGI3b8ijSGwANkxNPKh7523ABoDs3nvS9hGPJO6PAucJkawRE26w+XQH1H+GX1NSXwRm0z5ZKMACIiAWQxqwJX9N7wMGIACVYqO9NFhgAArQn9EEAIAGgKh3BawDCCwgAQU0YAOIa0l1HIgEtwRgcRLQWRo2MLOEyecgCQAAA5QXQkR8IAQZUICrSjA+COhMBG/Z4ILcUJY+EUEgqDrIAA7AGhD2sA0YAgEDtgQ4IeTvJyawHt4M4r808IRKACDgEDIgn+tt7khXLERaPFO4hRj/AAIbiIAEGMDHHD6Mh2vgSdXoNoQOBCmKHJRAf6wYxzLQrghrwggRSCDEJAzGAQxoAKIASYYPRAYBSmFCb144QXlooJEmggDzhDCCDahuEUkQga1geYYzjqSMRxjBg6Y0HT8NjZGo5AIGGLCB1YSgchaggAQcQAG9SCBlFGBeBgjpAE5+4YwMGAAulRDEF05HHvQJ5hgk8JIQGOADHlBXiBwQgQnwYRCzKdcQFLDKLmSlattkAggiMEXJlCk0ygOmOItVAQksxWZLuECcPtABO0mgWUQAgECtYAIOGASU1oyCBWhWNg4GoAL1HKgV6mWnBqgzCbBiQAUiEs4iSDQM/w/qU0anAIIa6U4B+7MAjCYqUiREjwlRwmkIVMOAiRhhTkOY6DgYSQELJQkMwyTlNxmgAZ72FGNG6EAFOSQBB/UnakF76RYaoK3uYWEEfnkhxGimQwzszaoDpSP8xpcE2xBhA1tNgQBIxciihscIOFXAAQ5wUjCEYAIBIACqGBAbgyjmqk8wgBJKcEBzqJEImkBCVmaquePY9SQWSgBC1qCmAIT2ABxMAEiLAFff/UoDeSWCAiJAzCTgVQnDM4JrWCses5TAAOsYR4X69NMxlDaA3/RT61DpSgAAQGwmFYL4GnCBXxFuss8lh4GkJ4B/ECUtNKkaQuugps2RCWIGCP+ADi0guNayg7dFKkcJmnsqA/ilAUx6CuUKOij9NqEBeXskEeKxlANWEgIHgCTnZoWIEFRgJLpjQJkGEAAJZMCsSThBCbiDJhGoBgChlUxdIpSXpDKjeCmEwnxV55siSODFFqjARgranxNQDQFIqwQJNJAPqeJUvQKIgOU8ZQQ8VYCZFaiAavRmHc91gALYO9VaN/fQe5XlxTAmQ28AsKSTYGA1qWgZPzTnRgzj4ckcpVIvixYBDIjMlZ4rQf8GdBq6BMAAZaOZALrKDO3BTg0fCJIFHtHQBohAA5LVRq6Ki4hWPjQAvPSneq32uF+FQJ5DqK1lijBCsg4g0rCZUnH/ShAHhRVBAGYOAw3nIBASjsMBQgJAbEshAjtBGtRlUu8ByBmCP/s0pLtwBAXsLAADSEawkKYuJo5cgQx84LICkCEbmnKCNlOmQkYLwExfQQI7jeRU/qwURJrwDvcWwnMk0Go+KMzLCcZGtR9oj2qsGIAU04F3t/iUbmZ2AAZIexrCDpJ8jP1Z2y63EiUAQWOCxG5jSxjZ0qGABxiVAuAqQQD2psNlLvCBBIiAakcrWUKQAZl8JrUzzxaouaHgJGCSGifD3pzM++3PwZr2H2UsAQEYucRC7FkDEkT2thMiGkJyJAADALF0JECBQaecDY34wAYucOQgIR3SBlCzG03b/++NMYmEeH2eA0wo8nsbJEjTMwlyTHyaDkj7IApYK2wMsLmkA3kuDuCDIGbhgR++hwSNGMGGB88dEpBABMf8wAc4kIGIUCACDYiOaSn8aW/OpeanSmwCJGCBDhSWFXBq6YNbige5CBYAEitEBxLNCAb8hJZSUPLOYqwOR6kr7pu7daTjfj3BwgbSk786hUFs2uIbH8Qgprzu6S7aY0MM7rHJfYCeuZwofAADMoFW6Aw9CUoK6WEUN0SgPbUBBUCEEKtoOhWwP4Trq+g5o9iAGnvRiIZWAAINoJlp5cN/0ao57gfxfP8XRVGkAHgDgMeWAAVQJvyXe2oVAStVfVdQUP/2MwTlN16IQDaMdSOTwBCspQEb0RDvMAGkxwSksVKY0AESsAEjoAkEUzwkAALIQXUQgH981FgelVj7V3zSZ3yklEl513Tq8AGABwYQECthRj+VgG2iZTWfZwcO0AEloA8tpQ/Q8A4UUILEYRe40B4AgCcOEAdz0GZdUAInMAKGl4aGN3h0QAIG4AqoMmt3QESRoQAGYBacIFFD4V8Zw0GN4Um6oYWMcECroCIZMCOfYgKpkDNi8Bz/1gYUqA2M1gZk0y+dUAHBICWFQzDOJRxYyGBLYAK00HQOQCUlJAQ88wiRsYJ3oVLSRXWT0AH7UyYHMHR3ABfwwRGuQHUMNA//77BS5LBFayIiVuOB0tUBpUMEhEACzkYBRkcPCIIkAnBZeBACI2EAGwiKziMcDzEEDtAU7/AOqfCJSUBFebISnDcVRLBnR4AhaRcOEEAeSVEIKTQC1lMpDvCIiHBbJ5EbcZACCqBhuREKwOgpgpEOYDVg2VUEakIu1jFiz5AAB5cGJeAiuiMd1FgJdhGNROAHXPJZsncEGTAitsIBxsEPHVA/k0gMWbEzKwkGE6I4VcI4pTAhJgAaSNCNJ/EWJic9RwEmgiANMUQEEbByuZAiSIIH7VA0ohUbgvgJsYVWRXA/TBCPOuOPMxEac2AB4EIbglECHlBwapBiFgBpeLM5/2XHIgyhLofHEgDwHJSxAZoyII0xkWSwMiDmTwNQAfrIInaCBM9xARogAZokBB6wQ5A1BFHiIkYTGxBglEDBh0lQfWzTAKckUjrzAUk0QTXTlzjyLIlZBeUXWmjpmTkyC0ggcsDWPIwyKkgnGYMlANq4KyQkMLHlDCK1NQAQRTQjkROzUhioV2MTQuFXAhaQXmTyewY1MZRECKIRXakBmd2igkXzfJvTZRMDAfejcETQeUvgZq4Tfg6GdFSCAJujaRPDdL+Cf45xaegwE6nWLSRwAebHS6hFAFGhNFLZftlwhBnga0ZAEbM5BAoXn7RRnFHVbrHRAKk3Mn+CECbAMv8ckgxb5QGzEEq78ilkJVUDZwEGCigVUA4RQRRO8BlHgBoh0EVEQnEeNhLeNB0C4IzeszJ3tTFOoBhyxRgpMADedSYfUAF+dHl0V2HJ2D5DOQR80QQOcAFGNGD3N0+YVhLhxyX0FWnRpzWolGCI8QS4IIXHAQFUQS5O8gDBSRs/an6W92P4aYuuAwIVswFDJwIyQQJbtBVyVpHKZJq6MKV99ha7qXU5tZohpInskJba4D8YQJXWcRpv8WnNF2oB4AAbIJ2n0AcdgjiUOgUZUAB1ZIIDCgE9CQt4EmdPgabF9nyoNQAMYAHPWBKb41xbJDSZWgWj0htk0TJRigLcID3/bEoMp+EaRYNcgmVeVKGnCWFsePN7uuYAG1NPKOAkGWcFlJQ4c9AAHjoAvQMQLNEBejSrd/CsjHB9EpBDWBduqGUQzeStu7A1Mtd8/pRrzvUwEKAOH9oEJUAavgagz9ASE9GrphAHu5GDBShY0beqbpclwrMdOCEB0ddGkoEA/veqRcOs6iCo4JoEFdKRYFQuA/MKfJpUlVNQOVhsCKisCkABGZCROdIBkDZaRGACzFFQdDdwN7V1SFc0CjARFWtVbtoYRLAl0Kkk6voGCadVEfBjStd77mJaCDCvgroiBlOHEHUEKWoBEABxDst7TZl7SScPiCIIHUCErGWtuvEb/yzRkEagqGYwqkLwsSgldRYwAQ1wAM61f8b2fwy4OW0yaCqLJmXBOYZ6O1JXAbQlfVl7eQcwswIwfM5livPAEgowFhfwODPiAU+7BiMQAgw1ufg3EnX7aQtogAkYm+YVJ4MQrRlKViiSAP66BCgQAh7QGCWUa69BJpH2cIwFF/Z4C2wzByBQpgqAhiQwAm6LBRrWCIjHUOkQY2sCYLHxucA3JbpzgAQrHy3LQBewHMbaBCZgJmhbEhfwpzQTuFpAAnBbUBDDgzlUDr02DqpBeiWAfKaVfOaFZ5fHR/gbefqbSfgLgIqrg/N7dQQAaYlbwI/6fDU3s8DHRxCYAR5Qr/9KSpih8BBvsxwQzAlBNTPScbliEHVfaA+ESR9NxHvh1nv+539VAhsqnJxNmQALYML+9HBw18K2y39cNxcYkRMeIAJDWxEMxCWbsAmy9pKeoDgSFgByqAZ0hQSClH/mh2zRq3sN2ICDNbNWLB+olbjRa73A52MMMCJ6N4Qh0MNSID5RahRkXAeyyDmQMAaNsRqThIzZuimHdwSDglnbgbyJZx7IsQEcoAEKM7mCvA0spTAZ4Bl813cgIAJruL1uQAJL7GK5lQtEZCGxYZdVoFUUwXmEGSeeQQHvI4n6wQhb9SykUmJcgLqlICxcWgwY8KIVVgYhkHdCgF/SxjYWEAH/rhA6F4EEVnsWtZkjHrQEJUALG1GmpaA5N3QqrboFJcAAyQJHT9AxDMktDTABaiQC/oYj+IYEclozX6yir1ACwnM92XMG7MgOaktuizG13/UrJTCg1gF5WpI85UCnsUA2VcNkZrA+Q0AB+5GS3SNLxGRU3hiJRiBLw5w4EDkg3lkEJFAQLRVjp6DMc/FCoZoF8YshH6BQymsBmNTJ1eVFoKxTBJoADoZqZCHPffGjqxACwVAB0TYgHmYEkXEEP2qhpQDJqyNrabBdAFmYGHu0hAlC4IkYnCQ7GRCPQ4ACSGkd96CMsCMiwuEzBkMKMpk3aZwE2xW/8Vu8IRIFCbkz/19mBPxYGcVxatKVQbewHRtBxGmAJ7gSQPLRulgAAkUBAQVywUvgzi/SjuvRK1JHFv9cBGN9CGzDb+PGBhfAOyDgJ2SQkAo1HuHiyIYwooaBm0fA1mRRQpO8RvvaffxSKWdsBhX5lFvwpgKwDh3HAHOQQqj5CiD9sigwC2GLf4o3Ab1ypGEoAtp0OzyZCBG6m+nLAH1LD9sQhSe6JboECxTNaSYQCUnGDl1JBM+Mik3BSJ/dBr8SGK9Bi3YNvtJzCrjQGJnrYgqjSRowuYtBHg5QOUogJXANJRywP1WD2k1GMO+ICAXyKcHAfTOhZBjAY6sByEAtBCNEFChgRW5qMv91oCcd8G6VQr4D8iePWQpw7LPAEQnjUBx99wHYaQQD8VGhuN9moEW5UmFbbQwWsbufYAJwkTI3MTzvsIaVFC5zgIHEwh9JHAbsO9o003OYIiD6OgkqPRP84NMcMbmCEAC4NAq2U5YgwAGY/AU83VEKEN7rkRYJ3gm7mgKNLR7GERzIyDa49A4JyQFcBhcU8IRicOWidSoZTSQ/qtaWvQa1TQQ8phJRggknZBgSoKjP8XGOcdhkEDqWJx9VXiToKS2kYJwEwDNwMTCdgVtFzsPQcQYxozrJiVr4HSgGDRYYDkK9ECVvWSf8QKMM2eNbQALC01Gy6Tp8UEisDg6kgof/oyEGjLJldB3rzTMBhPIOqlwPDjYEsiQbFmjiV7BlzScfLN04fzV1QFFQDaBHCQLmoGoACreqUTBRjKKZAICNDPjsrpMbAbDihaBtRLDIuzZaG7NaTGABJtTMRhBoU3TRBPDpaEOoxa6YRDDspIACk8xIrIcPRPS71sQo+rM68tGgPcSkQpCkTd0BDm8Kp85yLyODJ3ACBDACxSMQA6Bmxbbon+MmMD0BHSRicGron+AmsWdN+CFrQjQ0eoKXQkIzqAxZaeQXWiUZFIA47qDld7ANVcDydCLTPDTLTIlsQg5ZPIGtCO0XRf4JU4gEQ8deRNblol5IEHY9ARABfO07/7jpFYSb5bow06iADphQApqtjBQRYxTg8ihwAXrbSyEamkbQC/EoFky3CzWFVTkZKxX096kzScJz8/JR3XhfBKkAAu/Oz2dvSWlJHtqD2QIwDh1Qn6XUAHMuUiTEULXeCYWPBNi8BOdgEXw2EyFgAg9iIYI1ABRw3IsPHa43DYONBJy6BLNwtQXWHzWxm8f2Qhdw57NPDL0G+EnQvRsxCj3HJzNZTcW/ItfOGD3Jek/FEXbv5tFfEoQpOD81Zj8LYpy//TiiSimgWtbtsmMjOAVCzeQ/IIOOIRAAIL/sBDzBFvP9/tTQEIrokFCAIEAASA0rleERmVQumU3nExqVTv+pVesVm9UiJaCjMFWiVEsACWSk+GzZbfcbHpfPoxvL8dIZgjDWSKrjjm6QsNDwEPFpAwJJAUNPY61KIbHS8hIz06nDKOljo0HgilKz1PQUdcuEdAmik6ohVXaWtpYkoEmij0qi1vcXuNAEScBrKUFvaKRDkqk3GDpaGosEw0EAoEFkSYHxQwDDgkFQiXH6HF0aBamDAlsgQUEhACC7YvtoYwBsiIHpL11AgbREYGgAIICBeAkOCAjQAAOJFCAMmGmWhFWSWAM5diy07giJDRLoCTgQT8GBAAIgeFDSi4SEjENIAFTiwGNOnXBKdICQACE8BgoMOGRwIQSTE+bCJNj/OIQTkwoldla1KqXEBgpAA6BUkMChAArJnFDAdyTEsxT8kpBgEOGDxKtzr4qEgG0lSoYBAuiSG8VfuT4f1B4BcaABiBIYIIRqIG8CXcnAhnnCIKFeQgUI5Kl8aCFpFcIjllw4k6SD2CcYLnDY8NpDCKqTaZcSWUEBwgAHvn4VYBT0locM/iYBYcEBUAsTLi7RIOHCBQsWKohjVLl2djezkYjYUOFgUK9gd+sKzWbCxghDGwxl0ACCBWMpGljg0GBDLibTtfePwt2JELRqIIABVhKAM6JM6gqCDYpzA74jRNAAChEckMCCCCQg64gDmlDDvxCpIKED0+YxUAAD5PnK/wCVDsCwuTjEKOGA/CyIkQkTJjiqAw0VqECDDgpTAgDSRJyLuxNAYoIEDzJkoJ4BTEpArwNUEqCBCjow0pA8hhiJqSk+UECCbUYgwQEckWCro/OObEKEDzCowIEDMkvxJAaoBMuhBDDcgMtKPGyjhAqwhACXJ0IYQCcDFXCggg1CCHSJJYcA0BLuMMWUiREEtKAxA+gB4DcqGUjwgKJWUiACDj7gNFOclmAGiw4AgICT9hoYMoUPAIAVnYUaMpBUA7LMIy5goTGBhDjtqEAmO0vCUwE9O2uxwAMYoOARZTOB4Cwl8LsCABMguODVIRJYooz8ODpwoRVT+o3YvHat7v8REEQgwdtBzgzhk3AqiOCx30ZNcTdTV6TyyoQliFQ2aNZ1ArwqEnhwCAx2eWmmdD4Bj7xS4ZHHWoZ+M5gevvhKkYH3zqCgiOk01lgDDGquWWPppisCAg0fY6Ahh1IOKqyRvUqQT6G7gs+CDRRLR0soSLi13yEs2JjIJnx1EwoTml4HO1RI+CADaB9baaVUU9VrKHlTYoghUU82eO665xY11Smp7I1keeJpsaiTV6724TwizonNJgQYQQIB3GWig6fYTRwJAwIDu4kNCADhoGk87SAD6hozWWWHGlK7q4VUTDUlFeNlvbeT4K4b7dKrdQDmpp0mIey59IFCgbM4cIr/wyFCCMyJC8JUwtcMnug8BAUe78iEEkgA2IMNwqGOAggk+F5XXVse/733GrgQAggmwBeDDZgBgQSMj6xOAgfkT4G6JTJQAD49QpAVChd6ngD+UpkSiAMAenAAJSz1Jge+IT6XOt8HtlECqlwAgDkKGBU2UI8GIGUJIbgVEhgAKQCs4RoPVGEcJkCOL1DgQpiZ3hxGYIGDOKB4KaAAGA5QBAB44Sf3W+EQqVAdJQSgaoMIwUFcmILoBYAPG3lYE4lYRSeMQCsSaFkOf4UKDAAARL2yYQlOU4EPTMyKaYScACSwgXAhYWq0IMFBKgCCxqSAARjIwAcIoEY/KkE1ThBB/6J8cQEA5McEt9oAcf7YSBH2KwSiCIZaJECBCXCtkVWsgAGgUAJOQuOTKZBACHKYSREN4wQSeIwIZ5iERezwjb7gTwMSacohHnAMIKDclyx3gX2dQ4ZdtKUKLdCBPmQAkzEJQCvPMadhDhECsgrOETDwKCE+E5unIGMnLDAMtzSglNkUJyosIAEjkUkANhnnOlMxjAY8xYyvYOc8T0ECAZAFAruk5z4r4Y4j6EKd/BRoJQBwgSH4SgEuGehCDTEMC/BDCPpk6ETfEABzNO2QFNXoHGw1m6vxaqMh1UK1jlAGkZ60DcL0FUpZqgXCVEueLZXpTGlaU5veFKc51elOrQISBAA7\"><br><br>",
                            "subquestions": [
                                {
                                    "id": "6b6a6b3eeb6aad35464e8819e52de7f3",
                                    "innerid": "",
                                    "index": 5,
                                    "typeid": "e487b4e564cf4589849ada35a453141f",
                                    "typename": "填空题",
                                    "isobjective": false,
                                    "content": "小冬跑在最（　　）面。<br><br>",
                                    "score": "1",
                                    "selectitems": [

                                    ],
                                    "answer": "前",
                                    "diff": "3",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "119210",
                                                "name": "相对位置（上下、左右、前后）"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96871",
                                                "name": "1.上、下、前后"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                },
                                {
                                    "id": "bb460b745bcf072df048ae28f08715ab",
                                    "innerid": "",
                                    "index": 6,
                                    "typeid": "e487b4e564cf4589849ada35a453141f",
                                    "typename": "填空题",
                                    "isobjective": false,
                                    "content": "小利跑在最（　　）面。<br><br>",
                                    "score": "1",
                                    "selectitems": [

                                    ],
                                    "answer": "后",
                                    "diff": "3",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "119210",
                                                "name": "相对位置（上下、左右、前后）"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96871",
                                                "name": "1.上、下、前后"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                },
                                {
                                    "id": "d319cd4eb294555355e206417be02a9c",
                                    "innerid": "",
                                    "index": 7,
                                    "typeid": "e487b4e564cf4589849ada35a453141f",
                                    "typename": "填空题",
                                    "isobjective": false,
                                    "content": "小冬在小青的（　　）面。<br><br>",
                                    "score": "1",
                                    "selectitems": [

                                    ],
                                    "answer": "前",
                                    "diff": "3",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "119210",
                                                "name": "相对位置（上下、左右、前后）"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96871",
                                                "name": "1.上、下、前后"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                },
                                {
                                    "id": "eb146227eb75898b474e5ad08e9a1196",
                                    "innerid": "",
                                    "index": 8,
                                    "typeid": "e487b4e564cf4589849ada35a453141f",
                                    "typename": "填空题",
                                    "isobjective": false,
                                    "content": "小青在小利的（　　）面。",
                                    "score": "1",
                                    "selectitems": [

                                    ],
                                    "answer": "前",
                                    "diff": "3",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "119210",
                                                "name": "相对位置（上下、左右、前后）"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96871",
                                                "name": "1.上、下、前后"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                }
                            ],
                            "score": 4,
                            "answer": "",
                            "diff": 0,
                            "analysis": "",
                            "extend": {

                            }
                        },
                        {
                            "id": "1123010",
                            "innerid": "",
                            "index": 3,
                            "typeid": "e487b4e564cf4589849ada35a453141f",
                            "typename": "填空题",
                            "content": "",
                            "subquestions": [
                                {
                                    "id": "1123010",
                                    "innerid": "",
                                    "index": 9,
                                    "typeid": "e487b4e564cf4589849ada35a453141f",
                                    "typename": "填空题",
                                    "isobjective": false,
                                    "content": "<ruby style=\"ruby-align:center\">猜<rp>(</rp><rt style=\"font-size:10.0pt;font-family: 黑体;layout-grid-mode:line\">cāi</rt><rp>)</rp></ruby><ruby style=\"ruby-align:center\">猜<rp>(</rp><rt style=\"font-size:10.0pt;font-family:黑体;layout-grid-mode:line\">cāi</rt><rp>)</rp></ruby><ruby style=\"ruby-align:center\">看<rp>(</rp><rt style=\"font-size:10.0pt;font-family: 黑体;layout-grid-mode:line\">kàn</rt><rp>)</rp></ruby>。 <br>    玲玲、桐桐、宁宁家的阳台上都摆着花。玲玲住在桐桐楼下，桐桐住在宁宁楼下。玲玲家住在第（　　）层，桐桐家住在第（　　）层，宁宁家住在第（　　）层。<br><img style=\"vertical-align:middle\" align=\"absmiddle\" src=\"data:image/gif;base64,R0lGODdhcwBtAHcAACH+GlNvZnR3YXJlOiBNaWNyb3NvZnQgT2ZmaWNlACwAAAAAcwBtAIUAAAAICAgAAAgACAgQGSEIOhkQOkohEAgpCCkpOhkhISExOkIpWlJKUjFKSlJKWlJSY2NjUlpja2NzY3NjhFpjhJSEhFqEhISMnJSMhJycnKWlnIytnK2tvaW1vcWlxe+t5sWt7+/O3t7e3t7F1sXF1tbOxcXFxebe5r3F78Xmxeb/1u/m7+bv9/f//+b///8BAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMG/8CXcEgsGo/IpHLJbDqf0Kh0Sq1ar9isdsvteq8djZgj1pDH5bM5zUa712+1vC1mfaEaAMCxWDT6f36Ag4KFgYeEiIaJjIULAAt3TBd6GCwimJmam5ydnp+gniwjD5AtkkYSAAQkmCSvsCWxr7K0s7Yktbi5u7y4ur7BrSwQkHaopQqtJ68frycgzM/T1CTS1tTM19Lc2NnT3dge0iIjqgEjXiYOAA/LsPCwHiUeJNEgJM71zvj8JPX4AOaz94+gQH8CDxbEx2zcK0yUFIjQMkJBO0zX/jVk5oxECG/wdGXExkzWSG28TmIzGU8aPo0PRag6MLGKhwAAJFySd6JeQf9or+r5HFevZ8GgHIP+o9fMmtClPp0ZfToUKMyj86xhUiXAgxQOei5gRAoLmi6f0joyw8eyY8isA+GBkFXLbdm51qI9cwjzoyyfmTDo4eCE0gANl1yJKCHi4+JMjDu1ErFsMePJjE+UiBxC8YnHmDZfFvF5s6bIrSKn4IwNtCYWLTQMGOA1iQc9CyRAeLCb94Pfv3sDf+Dgd/HhyJMrP578uHDl0IMn392HQAICChQQsP5IzzEjLDRsuICB/IULGc6nv7ABwPr0GTBkiJ9eA3r1+N/nP89//X3/8O2H33/83VcgeoKZ4MGCCyrogYIdZAFAESyYIAIKI2RowneoSNj/oRATEgHJAgr00UeIH2KBIiorvoBiBhaAmAU7etSIU4045qhjjRkY0eIdLYa4wAND/DgFASa8YIcdIS75AgeRKCnlCw/06MIpE0xQRAtGehGkkgBAIIGMWEhUxI8mRFmEBBoQgcGYZ6b4JVguetVlFAqkI6IRHqhJBAQbEHGBlkRwKQWJ2SWq6KLZPRKnCBMCEOGdUBDAQYYZujjKCCqMwMIGCmzaqQgrOHABpixIQOieUQBgwj+vPgjrrLI+GOcLEhBH5hUSYBcAAQGUGOx225V4ALHYWaeddthFWCilSEDbhKsPnmCCgtKmOK0U2RbhQhEPCBJIbtpeYWir5aYL/0W3rKrrbhLnrttCCyzUa++9+Nq7Qr6w8evvv//SW6/AAONLML/sFgmAAAEw7HDDEAvgMAF6DCBxABhjzHDGGT/sccQgP9wxxCRzbLLJHkv8sZzvSpJwFS+3/ETMR3ggQW1HtLgAxsBm7KfM21pBnQgPXABBznF+dwrN7sY7BQsA2DECCRoQoGe7ZPLhwK5WcCDm1xKEDbaYE4yt2wS6pQ0BCT5aMQIEBAzAwAIEGMD2rUUKIYEJejJdRAAXlGEGAGpsoIEEARQuRgIPnLHBAqsK4fQULQxgYgFH+3hK3i4C0KaLWeQpxLegF7HO6ERMEOgQGETOtRMisFFA3MR6YP/4GiREzaoJebxOhZlYC9HnERB8LsSgW8a8QALChe18rs/9RljeLaQTot9EEMBh6USg8LPe0wtxeNtRLJCkFRNWPsHd2A9h0cIDAIBTAPEvLEDF8QsQ/40AxB//Bck7FM6oIL8BaKd+7RsCbKQ0Lwaewg4tuJKUIDivByKtfOezwjFOYUGgOWFyTViAszwoM+VlkIRNi5kCBohCdcWsAzuKoQxnSMMa2vCGNAxAim7WQg996AHGe0H1RlEvT22vh+TrEBBF9KsmAiuBVNIR/3CEQCrqKIi++0IEgmgkKAKPc0QYnhGKJyg4DQGEXyAjGDmgQ+5ZAR14G0KajsAmN7n/zo2SeMDqdgWJLEpBdMF7gQcScAQ9ljGAUhCcIhc5BgVwUW8SiBIUkSRE6lXyBR2IEgeFAIEeVRJ5cXQCiXIVgd2UspQPOOVu0nY10HEAOwBAAR6poIocTdFGO8JYjrCIxiWY7wohasEDEOBHJBYzCQk44RSi5qnzjAKKH+qlEhbAwj8uSwHXyY4xk2BC0m0zmsqr5jddJoUETMBx4kmn4daZTg6gkwzwXEM8GUnPetrznvgUQ8xIgZzd9Oafv+kVAXLlG3/6pqDDgUAEgrNQ3zQ0ldGJqEQlOoAUqW6cy9whABWIqY4ecZxQZIE4hzABDIgIO9hUQLCg+aH2eaAY/xdQQHnouFEyacABx4CiBpJD0IT2NKEP/U01sTeCFZGAAJsjQh3zNoIO8OGYTwCcB9zJgdtMlaocsAABrorVBUAAqw9wnTSbMIIFDMAAcJtdNSVQU+65CqpOACQY5fg9XO3xBTBKYhUstwAGEKACRygpq1hACbg2Qa6+E2MR1Hg8M0ouZg9QlaogMBuLDSAAaMssWwnQ1gnl1LBM0F4oX3CCBtAxfC9onV6dAADzlEcDGCgDBmZLnvI4c095+Cpol5AAHN6wrUKMWQKZWY4RlAOaScVCcufKWiws4ACJQmldtznWaGFUW8K9gzevW90LXrdDwi1PfM5jW/MMiDz2Of+Qef2j3va6973wja970xOzC0hWs/dVFQUyO4FSDOq+mg0wf1VlgQpkSVUDPrCC84s2yTq4wRAOW4QDLNmKfogFCvjuurKAgcYlYQQE0PDMrtDXrUHgAgw4wgjaCKIYiniWUICap0jAAQwMoCZEqAirWhA+KHbHtzQELoyfwIIKDIAAcyPAAo644j2xIAHs2K0SQjXa06UCtap9lrn4ugDMHQHDe0rHuaAIx0CSoK6MfYF9V9uETRV3AQaom5LdjKmbtEuNXtzejxSr1CBm+YzCBdZ2ArC8QtMNWCrdzpFZ5YE2WS8LBNCACazFt6hRetKgGsG1Nl1WC2iab2JiMxP/aHbCCeXOO0OOwgQKnYASOQCbyytRH1ptIlmT6NYrROSGgXnGzbEUvNxSkYs13F1Rv1gL2T32F5INBQ/I99nQjra01StcIOtBVRWwAFu3bV/7TsDb2d72BMINbm2XW9zZNvC4zY1udq+b29i2AIVZzCJlj5plYaxqB/Rd1Rf/mptnCldxHFCcf5OzpXgzIxQhwChELcrhioJ4dnhpcO/KyAWOknISFHAp43qKuMYNT6jKQXIWmCpDIkiVYzVOwFtBjbm/0zOf0BzEDIi14qsNUVFhfiQc+26OqfDzHXEeyiahyIuXIoEKSAA1Fiz9BBjSQKiWTvUROGACFSoHBGKkhGWEs4oSn1t4w6+JgEZlxzrJinV0sZhqLgSp0RqAO52ITfTgSYA5vlk5RuvOc3sDGt9+t25L+Qb1TnX08JwigYYWr+nFo2DpjH98cRHfUclTHlOQFwHkrcV3vRWLWb7yFehRmqxllT5Zpwe9ShO9+l8luljFCpbsYW/6s+s98LjPPSqCAAA7\">",
                                    "score": "6",
                                    "selectitems": [

                                    ],
                                    "answer": "2 #|# 3 #|# 5",
                                    "diff": "3",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "119210",
                                                "name": "相对位置（上下、左右、前后）"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96871",
                                                "name": "1.上、下、前后"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                }
                            ],
                            "score": 6,
                            "answer": "",
                            "diff": 0,
                            "analysis": "",
                            "extend": {

                            }
                        }
                    ]
                },
                {
                    "title": "二、解答题",
                    "index": 0,
                    "questions": [
                        {
                            "id": "1152575",
                            "innerid": "",
                            "index": 4,
                            "typeid": "c7413641216b436185b3ebdf96e80b5b",
                            "typename": "解答题",
                            "content": "",
                            "subquestions": [
                                {
                                    "id": "1152575",
                                    "innerid": "",
                                    "index": 10,
                                    "typeid": "c7413641216b436185b3ebdf96e80b5b",
                                    "typename": "解答题",
                                    "isobjective": false,
                                    "content": "照样子看数涂一涂。<br><img style=\"vertical-align:middle\" align=\"absmiddle\" src=\"data:image/gif;base64,R0lGODdhBgHpAHcAACH+GlNvZnR3YXJlOiBNaWNyb3NvZnQgT2ZmaWNlACwAAAAABgHpAIf///+1tbX39/dCQkLe5t7v5uYxOjoAAABCQkpKUkqlnJzO1s7W1t6traWUnJxjWloIEBCMjJSEhIxja2Nra3MQGVK9vcVaWlrmjObmOubmjK3mOq3mY+bmEObmY63mEK2UY1Lm1lrmWlqtEFLm1hDmWhBzEFKUYxmtEBlzEBl7hHtze3NKnKVK3uYI3uYInOYZzmMZjGPOxcXmtaXmte8hKSm1Y1Lm1nvmWnutMVLm1jHmWjGtnHNzMVK1YxmtMRlzMRnm3q2tnFK1vb0xKTGt72NKWu9K72O1Y4xKWqVK3jGt3jFKGe9KGaVKnDGtnDFKrWMQaxl772N73jF7nDGU795KzmOUY4xKjGMZIRlCGVpCGRBrYzp7nFprYxCUzqUZEBC15qVzY5S95t6U76WUnO/mpVrmKVrmpRDmKRAZa84Za4QZ7xAZKc4ZKYQZrRCUnM7mhFrmCFrmhBDmCBAZSs4ZSoQZzhAZCM4ZCIQZjBBKY1Jrrd5r76Up76UpraVKrd5K76UI76UIraVrjN5rzqUpzqUpjKVKjN5KzqUIzqUIjKWcnLWta+9CYymtOpytKe8pa1J7a+97Opx7Ke/vtcWta8WtEJytKcV7a8V7EJx7KcWtznNKa85Ka4RK7xCt7xBKKc5KKYRKrRCtrRAQSil7znN77xB7rRCUzu+tSu9CYwitOnutCO8Ia1J7Su97Ont7CO+tSsWtEHutCMV7SsV7EHt7CMWtzlJKSs5KSoRKzhCtzhBKCM5KCIRKjBCtjBAQSgh7zlJ7zhB7jBCUzs4QQlJrjJxr7+a1nO8p7+YpreZrraXmpXvmKXvmpTHmKTEZa+8Za6UZ7zEZKe8ZKaUZrTEZ73MZrXNrzua1nM4pzuYpjObmhHvmCHvmhDHmCDEZSu8ZSqUZzjEZCO8ZCKUZjDEZ71IZrVI6Ohnv9/+9xdbe9+YxQkpCEDHm9xkQECnm963m90rm93ve5u97pXu1vZzm3s7v1u+9lLXv5vf3995KUlq1tb3/9/+9tbUI/wABCBxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzWhwSYcWKBgU0FiwwxKOEISILEnDg0QGDlARlSPAIEqZAkiZR2tzJU2GDAQNWSJBwocaKkBoFqDDAT0XHBAYcpJRxwcCDoRMMXJCRsoFWBzKGSDBwVGSBpSv6yWhAwYCCnnB7FsjqoEE/u3ezvsQow2oDu4AVDJggIKMDIhIaDAHcYGyDjAUuTCBQ0J8DA5T5totQmGDkCf7iitZYYAAFvIr/9hNrgOtGAxL6yQZ8t98EBEgp+lsxQDXtxQqiXiztIPTBvq4rDhmQ3CDR3KOjRyQQdMhd2tf7RcBMkaTb1LRpP/+YAB0iAQm9Z9cGPCT444nqqOtMKKNdZokkB9w/KGAFhfLSBWhQAQ08YIABE6ynnl2LNaACEfwM0RlD5w1gABF11aYgbVVRsJ9C6sgwgYW9hbdhP4JFBSBCBF4AVAQN9TPABfNRSBRQzSU01gofChhgARLUcEFiJ5qo2F0R4LgQARcQMYEC/6RW5IYr1PDfQl4FpcBd1hm5oQJVSaUQkGTl2BBVzC3JzwAO3BORAMGVpVBWB9Zp55145sndjzNK6eWfi0WQjgT0GeXnlH9SUIOZA4215WIbQgqoYBesCEBpKxhHkQwDEIrQEAa8p9tljA40QEoX4CPgBSt0WaSkU97/FdRBBNSw5XqwhifprkM4UEONAzmQ3p8a6orriCv2BtkEK9BKhKp8tZbQABNilECPcPUVK7Hh4RWqQRR8hOiJRTagQA0AEuHluK9SMIFB61yAqqgDnSYSPenQg9AAmmJUaYAz6cotuYERUZAAA2wJ6MDhhVtQXwzjyq20BH2UEgEGHDyApRP5E4GnBhlQ7UXXBkjBSRH7mSuX7TTnT6gLqifxuIDxG1MCK6d8olAFTVBqRRfsJRDCMJU2skCnisQPxzupoIKJCq73T7FF0kgQwr5tSzOkBkCHscC40ixzBO8SFBtMFAC7MUxrh3x0Rfxg25MM/LyaMqxpEvRABOz9/xkll9ihdlfXBPmjrtiH/qkCBQUNUbZIPvf8M0UZH5S0RglAG10Bh/uNeG01jNxA3QNT/WcEDxg0JKyI59wPziO1DVnlBLElkjqOIySySCUH6F/i4/6tq7sGvayAztwOACwAnH4ueKQKEHG0vRrZHrLcEyVQ6uX8MT/iA5MD8O+PncdcOm3RryiYq0dyuytgKqRuOZHGCj6wsgZhzHRDoRFAxIoOYFxGwJSQ3SHEH9RxgASyAAamxc1HEeCHl1g3MXoVJAEqKNJaCKYgX2muIPdQl+tSNgH5HSQCjOuXRASAAAsSBHYWQSC6prWQFXSmAQdY3gv3x5ME0G9rfbvL4v8UwoDyLUx4CsobQiKQACBGyi7RWwhz1GERBTTrgH15G0SUeBADssg4MjjA5B7oIwWkLYg6m8lCEnA8dtlvPVzM37BcJ7yc0Q4hDhCTcq44LR4uZAJCs5xCJuSPC8BIIZnzEQBQGJ6podF8QlSBFJF3Iv0QcQBiQ9RPFsK3izRGin5UCBl1p8WYDOAA5FHIBbAHlwJt0EtItAsSKXDIhPDjVpS8yz9q8MEBEUFBUcoV1PAimIXk8SIOqCVCEqAvi8hOkAvxR68McACQHSQBoYTJPy5wvqgBRnsLuUodTfdELhlsIUaEpC5PJAEBJqQBfKQIBcIXuYkURgDnLGApR1L/gzsaZJQBwhjgyjXQ8PxPhQUJ2OdiyUQA7DNhGmQYNxdSgARchHAKkYAeJ0IVKQ6yIBTI5zV7GR0BuIWc5AyPBB5HH0xy65UbSoALDeIR523ofxR95kP8IYAGsBQhMjDhRPagQ4LoVCEqsGhCVqlIAKwUbAwjQviQ5gCbAiZJZxqW8xYzpIZIAEYIZUhpAllAVipkOWE16iAVcxOKLTObMMFHVIy0Fr6tZ4PBeUtDvGIk4GTIRA8y60DGMyW7opEfQh0TZjrTrwLIoDyhWQD+GCKjqw1EAATI0T0bgNOFtINpFziAIVcQPoAKSAZEeNp6ItCkBBBhAA9wykwGQISi/y4RQyoFCj9eSwHZPmAAS0tr8RIgQfaYkQgJoC2rrhCBpCIGIqitSWFCFKSqdKoBYXGAgWx7QuZMiCQGstAD6hIW9DCVIdwrnkNDmcimXiqkryWCVRTQGQIooJ20nOpxXGsA2hJhnqERgAwUsLgVKIAAAd6psOL72gggpQD/kIAKJpBBAezzIPTIyowOxE3jEKAxE8gvR0kEFQPMcyAyYAmzFEBSffJOsKMpQAEujBEZ09giMs7NjfFDAAvDRcZsS8nS3EvkIhvZvV60FoyPzOQmO3mLQobrk6dM5ScftSK9q7KWt7zl9F5kyFwOs5iZ/NkXT3nHGOmMAIQ75jHDdv8PD7iAnOdMZzrHWc5xzvMDHvAsLfO0zQi5p2jQTOQCEIABh040ohet6EYzmtGE5snIUkwTKTPknmIRigwEnZICEHgFDshMpBlC6cRYuiEQnslJ2LxTQC+kMD+5AFgaUwMV+PgihQFSOk6T4qrM1J4AYBJsrJOka/25IoL2iqwXswIiyInVr77UWCagGDB9y9U/nkDQnJOmUT9sACqgIkHwMZ5TG8Q9lemLXofzANMukjvejglsysOkVMYb25cd2k0GoMyHGUBoO+b0cn5GFEFfeEKdAdL49L1vUXH6ow69FJsEglBQJSfgBLH4AVfwAHFHHN/DmSxQFzsRx+5JR6n/LPlKmfayBsSbOAvpy5IHtByzrhzkyCYQnfqNkJ88gLtXO4+L3Nq9/gQFwZcuwDp4M6NLE2BNCvCjAHTeX2u+c0ZAv6zQlfRq3vAI2ji/rAAuM0+4+kMGCdiKwS/bv9+CBewD8TRZQgIgpCxHplIuwApChZS3FYDsj43IEOTMlYcThAC/lQAB4Dr2oMw47GJNgJwospyNNk7kEvHHWH6W1JnTSjKWiszkJwIqy2f82hQRwOYhH07TZ14A/GhWtaY+ALJSBGOMGt2aK2IcB+DmILLOiAAuYOuDFeDfGUEO64EqL+ELQKYGeZJGzo7RuIsM7gxxwE8BMPikIGx51BaJ//6WbxAVMEIk/ji+Cq9cEUbEM9hKFQkCcpSYTicZAANocUU+Rn7JpaSQzVEaRZNeIgITn0QQ9XQRocFT2KQpAthpXrZ89ZcSrVIQ7FcRz8QAzScSBWg2v1YRaWOB5tZH/TcQJQETCSgQKZgR/oRPMDEE7iQQ8ISCObIH+gUR/kR+pTGCByE9BWE9GtFRBbEVAIB9NWRBpeFxaXZ//fB+FyGEJSgQ1GOEBgFr21cAZZZmABAhBtF9GkEdCCV9WmhGA1J9MQR7WQdycsWDcddZBaEA20cRDXABb4Mz96Y3rocPFwgR+AJATiiHGxiFAqFGwyFB03KDCtEXlsIpPBgaK/+lI38IEel3AetWGXHEUWYoiGjIg7ahEPqjhBJhNQmhfcPRNcIFQxXhU4loihYhioJIEA5QiaQXiRS3hw2xSsL1dCG3EBO4R1J0hwDwAJ4HcsdkEU24EGAGNJPDAIk1EREIi7IoEQc4Lc2kjK9YEMVYEckESqmHNEzzgBVBHZzkehARAeRoKmw4AKD4iv8QgxMRgnOCiLqzjgVhAFT4MHFIEMdoEfCYECsoEekAjGJGAPH3Jg5FLWwmAedXEWiHXiO4Gx8oEFAYEQFGLbwYkdFEN9eoMeYmYHS4EAtgUfFmL/tEPSWXiV00gt3HZhMpESa5kQLhFAejb2qWb5dCdIH/Vn01+XE8aYLP+G0JcWxxVzE8dxAqYHnGYXgMVxpTpQ4nVxDi5nFSuRwwGTuugXAAECI6RnFMco6Ng0022T+LR5MOpXENMQFSERK751DxQRnloQ4rcAFgp4cykGA8GXjVgkAJ4JW1I5cCsI6OZWH9IgD/gHxVKW81cRMEoAJAMSPktRZZgZEFoQIXsABxJwCO019BARYykGLElU2lIQG5IWMOkFwDgACJIQMM0BgGoALYtxz/MJoMsBRQMQER8A+d6VOo51X6kXAkkRVrAmpD0JlMdF6H6RltwQ8XABVsghQptlITsGoSsRxaMXQP0A9DwxETsJ0RII8DsR0zcgHt/wBue/FhK8UqDaB/njgBQrKcBrCXzmlFkiGdggcVcmYhE6ATjoVC2wkWRXicLBJ4PYFAYykXBNBjcHFobPhqhyaQANp/9/hkC/igFFqhFnqhGJqhGrqhHNqhHvqhIBqiIlpkETqiO1GixymUJmpkDnqNj7eiyBZxC/pRdrkThfFnLVo405WjVbhmFsajUfiX5zGMEqF9M5oQc6ECR1qFAMCeRAoRBXAAMwSjW3gA/NATU3cAB8CXF7EOBwAG1WgTBKCl7pgS6uAAWrqkG5kOB5CDKcEAWiqaPSEBX6qWNoFAWsqlFjEBX6oO9OihAkAPcQoXaHoAtpcSfFoDkgYAOP/UQHBxSoGIoVjZk2F0AOtAEaC4doPYpnkJEZqqQtQkAUp4Y5yWlD1Jpy2YeZbFWFlwAO+xk0BKZQY3dfRgp52Bqlj5YK+2ZjJWqwWgDtVySlLhY0rJpMTqWEMwnPRwawDwpZTBacyaEPdEAEPACHWxDnYKANS0kBFHrLsaqCUhGa0SEsA6pmBARWsXq35GAHtXA1JqAP1AAOLGp7I3derAeEPADzWwr/s6GWqppTJwrwdaq8DqEI4DBmBQA2AAAWCwSgJrpZdyoAf6ogsRIkUBBgOQAApbA6IZEgpbAPQgE0OxAEAmVopSA6gpAfyAsHKKQ+QBYswSasUapCJyAJ3/EhYlYQBgcBQF0KpsYQD8KiQOUI3lgRQNoLAqoBPUyg8HcBRwWgOXAQYHAAFSKmu2WoXUIVoW4HH52rBnKloDwEDwwEBZcAH9gBQqehN7AAYr6Cu/sgBtmgBSmgAjUgMQIEHo2nNZ4CEGwQj9tA58mgUQgCDh8gAKSyM7KYj0AAYGEKYmWANZ0A9aKloOMAQhq33uOnoqcQDtgBAE0A5ZwKc2KwEMEBLUGiRgQCjRWi85NHLpQE0cKzTxESQGgBJvwwCMS49j16ZSqngqIQEN+6wHMQQQcI4rsLCoZHvn0bAU+4oTAAY6FBoUoKUX4LgDwQhZYJgGcaZg8BiasoB6/3cA8PCBEQAG/HA0uUYB/FAq6hBaC0dTYCAmRyMDWSCqn1ID7KcO9JAAYGAmN5S6TAoAjJAOQ4BQxsEA7YCSUegA0PtOtJhrYWu9A4FDQ2ApDYAtglYryUhTEIA9Q6C7JgjA2wsAcCpJCLGsRSeFWSDBAoGm2ONxKuRxWvGnyxciYFCU5tG0o+iqwBZsK3AA3KoS/XRqhfFh+wogFrYHiwJsK9EOYtRz1dQxmEUUNguTtUIeWkTDwaYoYFBbCNEP0KvFgaYO7JmwSnoQpTGlYtyF7ZCwE3CpB0EBYECk/aOzzlZUBADABRsRx2slj6WuRZZrM2xPeZwFDcAA61gYMv8QvxVBp5OBEFQ0AfAwgqeEncY6BE+8QszDtitiYQVQA56gG3DJw1UZJDxYvjb0NuqgnGs8xs/7gZj8wRVBxg2MEO2gpwqxDlnATJciOlnQvNN5w62MbUUMAWnYPVk5BPDwLiODmQdgmRchARCAnc2sFRbRGSsAD8BSGAzMwg+BWVrxq/w0rN0hEMSLy/gWAVP6hGzLcAIhZxrBCK6KlWPKvnw8x9HaDvnYk6taELh7RRMiuR+iqQexjrEMyO5VGEYhEpicI2MqmQ1hYexZHlUSo5eFhYGYpTlSsPv0NpjMANWSFcg8SEdT0a+YyQczoV8UfQaghOsAptu7P5mVuFb/YoFxuJoLMZyTBgYLMCGYPF2Hp7mNY0MGMRg8CRtGCdAIQWGgWABgcKhhJwBemhvoikPijMaCyjjVAqf7oQKKOhDAWgAr680AgKYwUi0q0LnWt1EWhsluKhDAyqfkPBAcC4tqrW/0ewD7hKY6Bbye8dRiN3wHgAALEVoSEK38sM84t0seB2taKrwIQaZbmQWMMCErQNhix7RfnRCYfACcoY+OCtetC9ZDILWRahCF6gDVQgHcg1X6xgBk+5f0Ib4DEKaCKq9wDQEBOAEMpNhNirBXUi+nDXljRzsW9sPTK8aDu8seF5oEQTxDgzG19tYoFr/VpGaYnBtjug6CpgJb/4rUGVUDOGRNJh2T8ddTEHAyELAkB1Ara1PEKD2m1Sjd9GAAODwQe6fL59soww15vhISCMSe6wCnZA0ANQBI+Ivb+KdMxNPW8IBN5wKSYCDVoft4mEy00FvEF9DAZGFMp/LSKVfeTpU0QMLIaMrei3cBWaC0B6CEc3wp/ZAFQ9YpC6EoJPy6IC0+VxqFXmHOjEsZY8oxCt0s1PErWVkD0CyFV6p3YGDCh7EQL72s95AF9uFUdyQAhsyo2ZsZHR5oTtV8C1ADceMPsxIsp0I3WV7WB5CVnH0A5Hq8DqAO5esZup1hIryFvj0BSkUPKl7ZkldS0uGlDDABEAAaol14Cf9xAJYMAD9MWu1t2eINtMkxBL/M5sM74TfxvHF5OX/JFCsb5wPBnjW0B3F3Aeldy+aMSmCwB/pCRVGKoPzhtxmHsTVA6gRRA+2A64E0AXe9L/HkALtsqO80FMRe7MZ+7Mj+VWoqrXCLsXDsUAIAtUTk5gMhTdSUBQUhuam7H2EE1QIh4urgt1FsVKJFVuXLwoVhYgShDkf74gMxpspzMGnOH3G57gQgx8AyIi7UD5tdGZcCDw592QpRIn9R8AZ/8AiP8JYUHSdxENrGz8ECAZDFVt8VagdR01qEIFUoIflGAJZJRZqiDqhehdpMKyoE1XJGwzQ+wtLqGe0N8dwH0xH/8ZPZo57SgUOAiTS+zRDq4NVIHGwvfxGmwc8W1gCYvhHUvqpjmuQVofFMOgE7HhH2KBLGSWQcq8oHYAEYMaYc7xzoAozyDNkE0eUXUWtL3evKgc8GgbsuJxE0LxHtVWRHa3gCIOoZweudIW5TBwFBnHrR/jgT0s0ZgcliLwBw6p0JgQCP03eSQRFZmBFVT2QdPiHxQcp8Eb/Q6gkBqYUNXZOfTIsSwRTQMXwZ46CLDCwMAAFa74wpAZZHVto1cnxRnxELBB04hPiBJgB7gNn3xJ4oahAywPeXhaa4nxBtcdX0UL8YmKPu5l7AC+vAW/y2RBi55mxFI+M+Bvswgb2b/xZsjMw2dFgYUHFvbx8RcW9kTkk4DmDMYnrglyLmO4HJUtEAwg/zqacCWUAA9OD+t5OVBLC3ACFgQo0C6gQAQJhQ4cKF7QowhAiAgAIHDyNeIBBR40aOHREWMDCgwQEJ6jyeVCgjS4QJCR4eRHlyHRgJNAXAjOlxoIELFnN6lFFjQI0FAHD+HOCRwAMDDXxCdPlTakx6BkhOPWkBXg16WDsKcJBlgteO6ij0JMtxyIOMZA0chRh0wNOI/NqmxZtQ3T2TeSMehOuXYWDBhSP2JZt0I0h4hBkmwGfYK2DJChE7rlwZs2F/bjdLOFDxrsYEozOfRp1a9eqTijXWODBgAP+YGg02omWdW/du3njnahRwgCCAAjXAmFY4AHnvwQg3k6X8fLJR6szTRp/qGmKBAxcSOgit8UJk69s/GtRMvChqGesoFz5YwMF6yQdX2MbqcGP3hDIOrCBtufIQIiCLAaTz6oLQ6BKMHjAOWADBqcDTzjB1DjhABgkZqpChGgzoL7yLBBwQtAwzUwe2sTIbAkP3MqNAuMwEGOmArqZ6ayPw2mqRAY3sGjCiFTBk0C/u/jstAgzvSc+qFSsbMosNOeRIgAuUI2AACTaCLMiFTLLKu8xqlOG0PYQzaEqUCMBwiNOsoqA6pIpcSAYFGiARIYx0Ayw+526i7kg3TTJJQkL/iaMOUJjAMwCxRD2K7qY+YRoASYVe8gjTAgoQ4KGX1GETjK76fHQjwNTZlJ5NqyvuADede1S6Dr2Kik+jCHBAAgnwg8k/MApKaEPAcL1yAgcI8IdSEauT8CBcBwhJy6cebGtKi9RxYDYIIDCAAvpGitOoKQFroJ0HD4CgHQlgYrOGj4y6zCP98gKStfgkgC0kfvIdwiTwxhoiVxUcWIdOhhqwKqQL9u1uiINgk2EICVa4YAIJhjBYIQYmOKDbBhpwIOF1ALAgNhkk2APaGozNGCFswchCBUYYIKABfmLLiGOQE6ihhixWZoRTtXpeoa0CEAbDAXVGMiBbDA+gjYIy/2UVrMvcHACj6acImAAMjBSEDQzZrgQDAqkRXSi+2SSgi2swJvD15wFWmPgCmCUgQNK0AWDkgHaQI0DBCMB7UEsHGGHJqhUK8nOhBJZViAAEwGDEKr9XkIEAGRoYKIsG0IOo5BUCe3lhDAeIYAFVcU0ADAoyyjjHvErT7QIIBFzAAHgeNCBohcBqB4IIHLWsZwKIR8iCLB5ciS51KvccUIbkcmyI5Q/Yw0eGLDCghlch6geMFZBHCOuOv7cM6wmEhmgCA/Ahn4B2oEY/pdbrp9Ivflo2rIALaijTdji2paP0qQFve8+loEWXzkikBvuDiKQiAAEHNEciPIELYNbRO/+XlYo4KwAD/qgzEwBFZAh70ggBQkIYAahDBUSJYAFep5cOEkoCEJAB+RDym9nlKTPQAs7IOMIA1zmGHgd4EkOAxZGR4AciIwngYBBEgeNIEQD74h9E+lIA8YFuIU38CUxQ1T3MzAorEMyNOoZgE+AABywq+FlE/FcDH2rkaBS4WQX31qIttfEvMsAjbW6Utj0QgUlSIYAEhuK5CGLNNjoETiIH8DMRJmQADnAARTSZSU5u0pOdzKQCDFDHvGiQjVJxgHG0lBGcwISKGYFkCmsAgQRIoGBfIg48ShhBjjDqYglMSATAMLJYasQqthxksCQChmNgRUG2lNMTMemAwVH/05qDw+Y1tYnJwSlATZMpzh5o5arDgAUCQkRk1uh0kwSY8SRDgMAFMNOiSp6kJnrEJUjEFEYBrCMLe5CelwyzguFgRR0rgEAlizO6qZgEJKM04QF8VMyNEMB4EWnHA765kJmwbTAzydtU1PabjQqUl2xiREkVEiP8CUCYyZxKAdphgCINIIlhRAg+hJJAAbCJPl5pkR4dZVO8qBBEJhVMKlW6kBtOLVjdiiZWQkKXBZwIL/RYGVwoUIOlKmSNI8OJg1paJVjphSZIxctBEjCWpcIEJBW6h1XJYhICUG4hqSwlABqAw98ZYJd4SZmc1liklrFPXHo9QBbR2hEwKGAh/w9xgG1YCIAIOOwo/ikKTPz5lBbKYH0bkQFGCpUQFeQIJhPY57sUuRkV7CGkCoGqQg7gRHiBpI+vWdxR6hpFABBUiQPJGEFZqZDaLJYsDLDRl0Bz24jMhrYAUIe6FIKv3wFgjY3ZyDo6xlvrHmA0WvqSCmT0FwCAZi5elEAWUpLYhajwABHgSKUm4EUAtIO2qLVMATjmro1wTDkLuUC4jCuVfrJXIRwLTSwRzFwArBUnKqjQGn/WwhQKJwtRRBVfE9I0ZlGxBglgonDo6FUI+ES7T5HB25K2mQt0by442QNzA3wpfvhVdhFJpd1464DUDjgnLbJIT7sng9u18YUOoP9gdSYg4N6uqCAqoAleK+qqC2TBPYDRMEIMQMCe/k8GA2AyRBjxq6GEVACDDVGhCmC9kiRNI8lKAEZqgEIAgNeSADKIDHiy5qNqZMz0oICVJYVfH0vFP11RR1AM4KMDoBPH7krlZ+v81xUg4CMcYwQAQsYRB1kAADFqwEGqerwN91HRObvpwfirs/JlATFHfMhBKYiqGjiAxd4pwFACeMkDe8ecn22AuwwW7IPc8yELK7RUgFwA0FDgJcUl7wQUoxIEZMTOCJEAiIZwUU1zdSNrHBV4FseILDzFrwQYkoBX4M5igyEhNXH2WX7nXYQB0JIM5lC4ZJiFY8kVAKhdx2z/Mo2QIWBXIy9MyF4vwIBaJ/sn3KFA92gLZo7wY5+B02WWrQuBri0uIS3KE0g/bgAwzHQhD6CNAdA35lhSDLoIyZ1xwvwzmjyF0Bpxs8uCDRsKY/tBe3jKAn61kQeIMyEbwxApHb4QCGRhXS9HyAT4YarZ0nDn7e0OAxxVVzc5xn1fChk+yycShlS1kgeJrV5sRh+TSEAFMNU0BIDjn1jrRQIVxAkBKKC9S51TI+qwK0fxvfSOvPaLv6pecr/EIB3yBHkWqcFfN+rXsirEQdx9+IkII4F2pKViiTc84Q1DjyRHsJ1pwZqAgJyWFYAog72tAUU5og6e/KUGKpjrAZFz/5Cbix5KN75U1ee6EsLwYwCy5wg+IJeQhVZe2d5FHpKVzhG/Io9NlvV9ZYgsWWUOJC8ExZRzWoT5nxgEuMosb7nzYoAHVLeug5dKA+ARfuJcKfuoISg9jlLVgaelOGNxlNorpbNSCKETu8nQLow5MP7KiwmYgIAqOPK7P78gACKQJ+YzAKPLixbhld4SFefDqbh7lU15oLwSiBEDAH/AGh/pKpd5PzVzuglEDe3CO7MYOsGoialpkf7zi64Blq2avpPwBwNwCAEgIh7Mi70KNXW4gARoQRk0FUeiLIlCvpMoiH2hB/+AryfUC5miqUCTQLKwqAlgOA0UDHWoiSGQOv8uhMKNQChMq4xc+xmjY8Ongo3vqcKTSDH+yAzxAgPtqcM2ZAiC6kDDsJK/kowCUIF6ygt6YMS8kAG4E0TBCETgMIkGSo08JLDT0MRJ9Ip4qQ/V6MTFaiVPNMVTRMVUVMVVZMVWdMVXhMVYlMVZpMVatMVbxMVc1MVd5MVe9MVfBMZgFMZhJMZiNMZjRMZkNEaL2BSHSsTzaJxnZJyoygtmjLVKRJtVoS9dPKiQqIjTCBktkUS/QJi5CUO8+LJu6brKCByeCDVftBj9+sDKkICegLJHBKq5SCX4Ykc6GoJ0SDUjaYchSEdb7DmfyDU9OxZmgRe0scJ32bB7qDXuOsj/nGDGhLiALzsbWKGwi+wITOk5AJCZB7iAfsBE5oPITEmUvhgCCsgWp1AmYJLFBlgBfiiTo1m3aFEBxeKILLkPoxiCdYOWuQlCO2oHBSAgiWmnkICbvBiAIQAxAJCBCGgxhcHHk5iABjgQiXAAaTMAA0gAW1MNnuwfBXgAfoixBmAACVAAkTC+FcCY+Ai7DrIjncOjPVgBRtgcRWqAK6EAp5AUrURE8hIAfwhKi1sBgrmHinGAiJsABcibm5ABiyPLk4mzCaisXFMACmi9C3AADTkIz1o0j+iLRGpCi/kHfHjKWhoAfpAAGeAUf1BElYuLj7FN27yTj8nNBmAE2+zN/4/5zQbol9x4CK7ZMtjcy6FQgMjju8dKgEJkCIfKNswpAAZogHrcMiKAm5NMCH+wGGqESPkwgAnohwIggCGIAKZ4gAdIAIdppAugqDUbgAvAE83pSmiJAJGoHh5qoy+7JAIoABlwgBVonX4ggm+MiwHAvC3TlQZ10Ad1uwZVAQltUCIoyrQYAgNwLC1alY3AB5rqSWmRo5YZQh/yH2cb0Y7Iyo44iwDyh5PklIPgzumCv+lSUDnSG404ofzJCzpTDRUiy4iYAEYEiXM8iQjgx8PwzLQIrbqUgIDMCQFIhzbqyxbkTy2rmguVigZ6gOeain4YTIUYULwoACfUiNBqwf8hrKjjwwv9aDwtZQgKqB93kgo0Gss+E8Op04grxQoBoNMhdUqDyZUGDMMmxQtMWgjgIwvaWQ0G6DGsyDU7otOcANHmoj+saEohNVKU2BWNoCZIRMRJzQk7PY2DuM5qdCfJ8YutjAg8JYtMhYog9dQDhJWNZNKbUlSvqBfVOFWnhIjO2JhVNRhX9Qpb5RBZjYgI2ND22VQ9bL/kqBpknRBajalZCU0olQo2bVW/WLg9lVaG6NSIeIDmBCpEzFWGOM862tXUaADcK6pHZT5RRYlz1TIu/K+LGMefkFONgMsnVIAk3SGO0K8HUAB+oIDNsBrV8KwUJAt/oEmNoAd5VYr/qGyugIJUOs3I66gzg2HL76sfesW2GugMARCf24BTqci1GZUKCUDCheDTqWjJ22jWwtPTZG1ZHAEtbB1V05hUMHjWfwMDzKiV1ajURWUSlf23mX0zkfRShRgcvHjYv1iLoqLYhegMmSLTAzlJkGWTJwGPMFzX1AhXr8i1WIpatyCPiCAAM33Vc/TTFkTS+DrZ/vhZS5qyfVKSpkWIhFXYmsWKs5UjYo2J0KzaCCIpSBXc33mAdRSpl2UqgJ0KQE3UzTCOtlCSemJU1rhRr0CATf1LsvhJjoiAMI0JBSDdlIDXmJCBwo2gokXZl53UFrmkQPOuH/nWqWiAMBNChJhM/49ggMS1QiKAlLcoKXW41/hS2ur6t6tcUazQFYgA2Y9AUhkgAgNA2gab26lohzK53sOos5k1lu51Q2qFiAjQXZRQgLEQX6lUjG/6svUFgA+9VCt0Xbtd2oRQgAP4h40g1dXQMzU5iK5ECXxIh3wlLz3riAby0+RNCBVKWxUlX4HdXLJiiYf7t5sFgOgdlpLlkuydCpboSOdwxmxEiHt4n5gYgsPlyFhpoCJVXYjCjhh2Dn+gz5hwYZiQYbiYmJxYUjlxq5VMOLblUeBAmBpNiP5dDQHgTLjgGpsyDe5h4PLCDeZbtwuonyzR2434h+OV3gF4zt/xHyOOCIajSJtBHf+ceAiXs0iyW4gTmhu6YATH3aGMmUoE5YjM5RMIuyW9Egl8yFCnqM51i2KEECWYZN+K+DK2Mc9s6weEgF+vElF/IAB+WJylmAAArZmm2SifDCn9uoB7UETl2JQU9riHu4AHWICXUCTYdIDtHeULmGKIkNiTQOLckIEHmM/5HKSlaIf5/Byv0Lt2SADj4y2hvKTbLQChbDEn8of8lA286VP5GBsDANgGQADZMNbys+Y4mxucCK1eltyNmBe8wOPeMM/bPYlO8eBM8aFHTj5kSY1zTgzB2B93Vg1sRL/VsGdYjN6cKGdlBGj7pRd0DmhdJN4eQitJHsWfANCxfODMMM//sRwulHANGQbPuiiAfT4N85SNbllnhkgW/4GWjI3DFejl9mTYwkiWcOQ1FomWp2sNGZBpmWYAmV6Ama7pmdbpna5pLg4S+jyhdCBojdAVz7K3yliLeyDEiyaLL0skInDXRFTQbLlAe3LAq8bqrNZqrX6AJStMgZIcm8mhjyCAhgZBP8LhjzAAPYPNBjZrAE7BoxgA7mmAtJVn7FDJQWzLCLAI2QRQUMSKXOHM1zJPM0vi3gjhS7zOAVAVGahJnrhmK0bWramYfjmZKxlm2TBki1SgTyUW2QBtOx7ckHzK9pMPactlosyJLUKMCdhiAcCH3JUNfkiA8bwHfA6SADXm/wuAy8f0qwF4gH6AZ4LjbZQIZNAOsOtUJEXyzLxpoMCBTyukh3oE7cTsh4qhgARIgAjgLXRTjkemBx6TjbWqrEsiSS1p64/Ilqv8CM4BbYtJYa2UNuoMFoRJqVQUgMmUbOIgADAdAAVIAAW43u80mBZqYjzh7yFQgbA8Zk/FNUtM5ksqCvOcygCjABUgkSEY5whKltJ6TeIIUAdgT5YIwwr0oZuIY7jxFDuJuOuup1xjb8IDi7UmWzn+OCJgRFkhkYMwYbEkr+4NXV7KNZieCtOtkvXMV+lYXVT8MoIe2+2AKLIw8o14yrRggEk1FrwQWR3RWYr+6AF5CJvEi5jl1/8ItmFL0wjOSSs6zZJANQ8B8DbWa2RPLNuspfKHzg+DIem08Onp0qOugkuHTIkuR4lencSFvapZ8ZRZ7gg6Bd6fGFeNeIBBhognZ6os/rHTzT5Dh45UTd1sHVaNjoh9xei8OByNIHUrr9s2ZAQfJ4tIjQhE942NePScgNVjzYsIyOIHOKRbNUVOr3GNcFS/qF/YEnWI8FGXHWqm1Yhb94p+iOo2FIB/iHavYAAzbC80x4tH72eKNpiwxYpJ59cYF91lFcQFaL8WBHYFyovAofKh9tP+onRcT1Yzj4lUF0SQ+L45t9SG1StNF3cm/XTKsvd5zdnZWXYv6fNszZNATwv/CuD3JxLjk1h31EXHgQcAIlhoBcJt3uhYMYzdVf+JziCCzWjztBBz4Cj2nwjy5vJgwJ3ELOmqQaW++VVdjP/eVxfVlseRlqHJY8fIeR+wPScwG0+IFTB3qbDijshdrOiM5x0iRoeIqRXYlV8TqV86qGTqiGigvlxfkJBWSa71iETcLKphrOhcj4D6KWkgl1zFs48Jh1r4Sp/45rASTFeI63beak8h692ovqTfCz2IK+946wDSTpyYRxaAtf4mm4mJHs6JBTB6pmIoi4xyj+hLWb17oE82m5Gea+kU0E84qdezIGOWDr0sq1fbG02WR0H9RJGp5PVTJ4qODpUT/Sr4/4WgAAJyfVTBawFQgfNFxQgo5xTW7KNoywvNUO4KLWj5RphY/pgA1qb4HXzwylImEOpfY9GO8IwaDf9ZAY2eAOwfO57QkGChmML3EoTha1RRpIyIWLx5Fkn7CT0rmptAmJt0QJrpy38+iSwBiAkyABSQUaMBAAASBsigN4SCgYEJJ1KsCMDfxAIXLgwRIEDGgAgCADQw0K/gCgMILbK0WGBhgwLqNE4oAGCISgIyIhiQ0PIn0KBChxINKmDhAAMrRk6MkCCBCgZFW/pTkMCAgQf0KCq4kIDCQIxTK/a7gJUfAYoyHgyg0IDpWLUTDAwYMIQigwkD9jCyGZcigZRJHQpQfDngggS/QAMCADs=\">",
                                    "score": "2",
                                    "selectitems": [

                                    ],
                                    "answer": "",
                                    "diff": "3",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "118840",
                                                "name": "10以内数的认识"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96868",
                                                "name": "1.数一数"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                }
                            ],
                            "score": 2,
                            "answer": "",
                            "diff": 0,
                            "analysis": "",
                            "extend": {

                            }
                        },
                        {
                            "id": "1152576",
                            "innerid": "",
                            "index": 5,
                            "typeid": "c7413641216b436185b3ebdf96e80b5b",
                            "typename": "解答题",
                            "content": "",
                            "subquestions": [
                                {
                                    "id": "1152576",
                                    "innerid": "",
                                    "index": 11,
                                    "typeid": "c7413641216b436185b3ebdf96e80b5b",
                                    "typename": "解答题",
                                    "isobjective": false,
                                    "content": "我会数，我会画。<br><img style=\"vertical-align:middle\" align=\"absmiddle\" src=\"data:image/gif;base64,R0lGODdhGgHSAHcAACH+GlNvZnR3YXJlOiBNaWNyb3NvZnQgT2ZmaWNlACwAAAAAGgHSAIf///8AAAD37/fe3t5KUlLm3t5aY1qcpZw6OkLW1s5KQkp7e4SttbWUlIw6MTrFzs4ZGRkIEBlaUloIAAg6UkqEhIzv7+atWhmEWhlSjOYQWhkZjOZzzmMQjGMQ3hAQGXtze3PFtb2t3qUQEAjezoTeWoRSraVS76XelIQZraUZ76VSzqUZzqUACAgZKSlznGulWu+tWkpCWu9CWpyE76VzWu8QWu+lWsWEWkpCWsWExaVzWsUQWsUQWntjY2vv9/9aOhnvtbWE795aGVJaEBmExd5CWnPe7+YpKTGljJxS7+alpWtSreYxWhkZreYZ7+ZSzualhGsZzuYpMTqElJSl72NC72OcWpxCrWNC3jFCGZxz72MQrWMQ3jEQGZwQ72OllL1CzmMQzmNrc2trWoy1tb0QWkohGSGtlO+ElO+ElMUQEEopKRkIEAgQWpze9xnOvebvGTrW3ubvGRDvGWPOGTrOGRDOGWO1vcWlzhBCjBClEHtzzhAQjBBzEHtKWlre963e90rm1q3e93sxEErvWjrvzjrvve/vlDrvjLXvOrWtKRnvWhDvzhDvlBDvY7XvELWEKRnvzmPvWmNSjLXvlGMZjLXOWjrOzjrOlDrOjLXOOrWtCBnOWhDOzhDOlBDOY7XOELWECBnOzmPOWmNSjJTOlGMZjJTvGYTOGYTv7/dSWjpaYxCt5u/vjObvOualpTqtKUqlKe9CKe9zpTpzKe8QKe/vY+bvEOalpRCEKUqlKcVCKcVzpRBzKcUQKcWlzjFCjDGlEJxzzjEQjDFzEJylznOtWntCjHNC7xBCKXsQMUql7xBCrRClMXtz7xAQrRBzMXut5s7OjObOOualhDqtCEqlCO9CCO9zhDpzCO8QCO/OY+bOEOalhBCECEqlCMVCCMVzhBBzCMUQCMWlzlKMWntCjFJCzhBCCHuUnJzO3t6tve+tpaWl7zFCrTGlMZxz7zEQrTFzMZycpa0QKRAxEAjF1q3m3u+ttZzv1s46MVL39973//f/7/8AAAgI/wABCBxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFiwYtSNjIsaPHjyBDihxJsqTJkyhTqlzJsqXLlzA5VgAwQMGAmwOOJDiCUyfPmz577hT6M+dQoEeNFg2KdGlSpkqJSm06NSrVq1ZzDhijDivUr0/DOh1bFSxZr2LLpkV7NqtZPBJoxsVIt65du/0AgGBwt6/fv3QTxB1AAbDhw4YrtEPMuDHiI4PnOp5MueECvpUza4Y4YJXczaA1Xw5NurTAAYM9m14NuEI+1rApo/4cu/bFfopt6wY8e/bu3xBHAx9+kTBNAsSTI8S9WLnzh70l983bj3pm63kBZM8s/Ll3hZ1pFv/+a91f9u2TsWuv3K/79/cFo5PH9yDBADwP0Du2MKDMzQcDbOYafAQSNAByvmFknQUPAGhBPzhVYIF5+tUlwHqqMHiTBaoM0M4CA1iwXoV+MVfgib2pRpcAR6hTQEEChLhOBf2ISB4A+PiX0Q8PgPAAAP5M5t6J34WX4G0PlBHkQDYONMAC/JnnlwVlHAHAD6ddOZAqFawTIInT5UYkfPJZ1I8A9R1RBh5nAjDhQFgC8IACP8apoAD9rLMOHgyI+IMFVhLUzxEK+NAkYkOO6dyBx2E0QI/tWGBBAg+oAqOcC4xA43p0MSgBHiGW0eeS2mHp4RkK/MlYe5gp6l2ZE/X/48+jDwQQQBkAqHKAQQOAMIKtBDxwYadHWGCrOgItECiQNKlzhq31VDkQmHQN6OqrCCJXkaQCjRHAGT4M4MOP5q2jgK22ShBogw9yGpEFDASpTgBs+JDAOvlhaYG36Drwo5t4TNhmmM1du2hkFf2gzr8/tONCAC5QkZ86ErSBLgJTtGOnhsxCJCIDeAykDhIBjLDATA/48DC0U4DgpkAdJmBnX4kaDJyRKk7Un6EC/eDrCAg8e7ECFPzY7kD+cOtuQzfRI2I/P1QwQj0KSIAuxAo4QM+WcN60tIJiTiv22NTSdR7ZJYp99mSwSpQXBQFI8IPXeJRBj60OgHDEA30K/2Tjkj/8QEWApDo0rwOADtAhPXcHAIEE9dFILQP0lD2Re7IOkMC0EA4gK2A1NjjiD/eKOCxeAAoka+c/WMcYo4xSFGQ7I7gQ8KEAzqwl2hV8GdEALiABQtJ+A1DGA4cWz+R6FVDxeV2sFmTBAjwLgIcBPvggAQOWV3QE9fi4yYABEvigABXJY5SyoVC3U74Pq/x4+mFtT2TBCA7I3XN1+nG4u6DGY9NEJOAAFxQEPXnBk6UQ0o4E2Kh7DrGWdvpRhgYwYAxUUICE/GaArUEQIv54QDsOIAEQIAAECwTAGFx2Fwa0AwRUqIADGhCndXzKMcY5EkXGgIAAgOBoxNNPdf8MYp4j0CNSElGHA9oQrisFCUzp69mHWle4iphIUDNhgAMQUCx1CWRc86vLEVzGgDMgAHkSWEeyqPC1iiRgAQBoBwWmcIR1GMBGFNjc6wajLYu0Ywr1+Eew8GQBfRHEPFVUXQEUsLWIkM4FUwhAPZBVHTy5q5AJ8RkBolgR91woXD/IxwjoUYEAYOZJfhGABQgQICqcQR13Y6NApIORVbZOHRBohw8CQLgeNaZ+E/mBAn5Vgez9q0Nl8JNe1JGdC+UFD2cYg00mYoBnuWAjRktawJZ0QRsZMgE+QMACXPbBhVyRIOqoRzseQI8zZDBAArljOR+isoXRQ53TFIjeODn/ERAoYJ13o4cCMAkAWvImNXR5wBhChhsHjKGQD3PAlxigONXJSQJnoAcFFDDPgUAmXEdgAAF++INdnqFO7cDDAvOiCnWMYAyZUmMiKZIoCYzgHyPwgQH+NRD0/cUBv4obAfCBnsHZ5QdneJgLTPg/ADTgl4XRIV1+sA5pljEAbaAjACpAD89lCATRzAcCEDAA3VFkXwgogwFKNoLNtWMAahSfAxzAAJUVzGyJqsAUDLCAE+qHAfiYacIKioQVtqypxxPsRHxAAR+AwAVwJMgP+oYYYNYFrW1wwbkWw85HgQAJPhhfBBDAz4moYnxn+IfVkCM4C+CjAmNVRwXqEQCe/9pFgtOC5zp8YFGBLOwvgBJIVS0qL1zZRWn3YKPrxrAswxipj36h6lqfhQAFgGAMUzgDCNoxhl/VbnMdVQiWqBAAAkByDOiVwF7p0YBnEdOsZgobQiAHtSVVID+ISSOQslMB4/5FAkQFwLCgtEfaOBeSv4rYTX5gNSQ87B+tqkucIHOGSE4BAV7qRwMCEIEI2OoMza1LzQxEp0fpE56HWYcDUlqGvOjNMOugQAg81K1f8pExn6WtApJZrHExoGTMNAweXGBNl+HjCDAdgMV4RjCG7Gtc+iztcVeI3yY6VwIHgOcYUnhlAxtmTpF0QD9U0aE/UUECUlYQBUBQMjUqDv9LWrQtzSKckCPw9otcPswDZvLFEPvlAbIUHFRpkjPD0G4EVKBHkhpQBqP2FjAPeNY/12GBdRwAP1AD3YgL4o8x9PSBlWUhAKxsGAvwWS829vJhjuw3PzeGQX5L821fs5AfQGY9CyDX6gT8PLvggYX9AMEAKCQlEUlJfZEFgAHCJ+D1ODOMFXmuzWBzTvD4SCA6Ut3MwqsQF4IAS8j7XF6wREW6tKMMfEYecdVDF8v+pXWrge9hNo3ObPfI1BtBL/mu3expmUfd9KQxABgApQVQQAKNlYABxtBii54nRnJGiLKa0+jpbYQACiCAY/+FQDcl0yGwg+60SVPthKDZacL/RUDlCrIOEBCg4YfywT8MQDzx1nhTclqx7izg8nYcAZEDeUAb/AWmOG2yAlgSQBkI0A79pEwCLX7iksbggjszxN0jFw2dD2KBrcXpQlEMEj6o19x+fMoA8gagBQomouAipKU7PuQBfICHux7QTY2cVhTz0qsf9nZcPkjgQoxkUIoIPtOuLdbR9hPrYgkgToolD70FArLeDkAd4xzcOtTRXMGUYYEMiMsY7FQ2KM2MndgTNqDLyiQf+NRNA738QiqwrLysgx4gaN7e1IG7l9uoDLwlsOV6Mx7ouSkBDCiDOuxWN6MxxlLwgiWLU1qdtP8Ft3cfNYq3OoZ2UBoP2avA/0Dj9CcDFGqjxeojP/0hzJnh3j8/KAMIfNAAB4S4AQgggAQQwJcxkGs5fSQrDQACVUIl4Wd1fhNOCqAAXDQABgByCFJ4ExEk/FEp0sMgVJBnfxFSBKVtAyAh3GZ48kVE/VAYZZMADUAPkCM9C5YrY6BfC+FLC/E9c3dq5JYTcXJmQVYhPDct8FUGYyBQdMYfR5AXBaBT+CBlWPcQ49Z1h8JSA6F8L4MXUpIjegQzAjEsXSclkWcX9EZBCKgQCeACFXAA/nUQqFFa/aAOyNIxgmUBDrV8/BRsdheFyEIqeZFIkbYA9HCGY9MrVxdVhXZWIpQhqrA62ycQFRCEU7IOPv9XVhQIcAMBflASghBRcgaBbgXwKG9yEBKifEA4E2Z1XQvARmnHaMjjNGCiDvhyblRgAIdoEHWlgjPlQiESZAeBG0fAJwwAAm04M9PDb+CBMBYhKbuYhI6IPGaldPUQMsdlRN5nAXigDgGDEEfgUEKydWLTDrSnGHF1EO3ARgmgDgpwABRVED9wT72jEP7QAOtUV994SBDCW+uQD+dTBn5IEwzIUAZxRI54Xx0jKOqQBP2Agox0APFoHs6ijfFBjG4jEA+ADwxQDw4QPj+gLP4GIecSAP7iTU8UEZkWQkrmAG14AAzTMzz3K21ggTYia27THexGEyAgAHoDg5YiK9//808WcAALMFLcNTb+0A50tkBP0w/0wABHECnT5Eyn8YK7Eo6FEnrp8wMGsB27BgB4cACqEDADNUTZUQALsAohE44I4APAB20+0oW9IXIPYR7wQhPPQgBsgmbF81noMgXJVGYhKCUo10Np5TP/ciFaFFQBgHT9EJGIgX1BcjoW8ID1UROYASGVBjlxIi18CEAuJ0sFsUBB4oAA0FUPAHVaUh8PQADfKDq9mJEPYADqhzR58YDJdCB8ISIhAn7w9AP3ECAV8FTTwiX/FIiqFhEf5yYEACw+8ifthC74c4aA8iBdiBDZNmq2cj4sVAZWc5czMSwPQGm5UiIjuIb0QD4V/zA++JAh2pE9rvVYdIIedsSbAuEPvrgOZxA+h/ID7jh/BKgAGUJu6BUiBnBhAzA/CTAGTCYQ3GUBdAIAgcKGBmAA20UAGYJJIIBC4jIFaIYeDghH21EB1EgA3bOEDKFoFtgwDhAAU0CgFvNhFwYCUNMk/pBM8OaSeVEG9/AAT/QAPZQ3zqKcF7ZTqrMknDiFXhhhYBciqkBp6PaeMyoBBBAB6uBAFagOjsVsKPkAoKUADRBaYrM3blJWFtRboUkAGfUAxXIf6jAGBnCbfnM3DNgAJyMie5M06+APbFgQ4CcB9cAA63AE+GCmjlV7/mBnAWB+DGkgnmEc21KcUJITAP9ABS5nKxFQjgRnJaoCjI4WEeRFAXMjIkBYnFilXQr1I2eSF01CJXyhgVY0glpinpT3JyGyHQNAcD6wQvfVJK2zANXEAD0CAorGaX6TQrjiNU0SUhWAn4xmKeS3APvHcFQQhMa1JP4DkRlSUU7CjdkDAg3wAMA4BmKqDtxFAFeYECDKELs0Akegl3Lii9tXI8pDbgWViAsxLO3wDxNwAH8SJ/jAV3LWiS/DflulmUMqNvYxfy8HF9KEANxaAY1lJTUSJxMyN7sZIgFCcLmWlGXnHyDApCIkAdLkAOTTk8vmJkrjP72iGAVJVeiVTLp6JXgwoKyZJBonAQrwsQf3JcX/Ems0cTIho0YXNAZ6ko+8glDFyGEVICWCZxAtKih4soZ48HgS4QD1cAYENUQI8YTZ0WLQFl929wDL5yZsGCD3QhP+0Xe594oS4Ki5h48RJ66/ZQGwZCVeAgDrAFhHQAU+UIqvaF3FuhdrcnXr5LUod7NJCVe42jzUM38LME7J13A645AVQQAGMAKY8ZEEYWxjBp0VkADhNQYkM5tAwqWSJbLL0Q5teFuFiobnGJBwwhs+lxCoahFJGY/SYxc5JIHBQTIuMAbw1JKzaxB4Ajy8JxFl4AIjkFP4pTySpTvHJk0u2RDMsR2RpwpcQaCiMn8c6li8OjbBRCr7okvbVVcl/0QF1HO2AMQQ8qYKPoB7BAiEElCGFYA9VGB90OG4FDEACOBhG7EAXycp5OcDdpcXD+CxXvQuCoAE/zBWP2S0mHQm7bBy/qod+PBZVFC6dDF5VYsfTNK8xeggOFtqx+NRVFoXRlJ8FnEAZ1A0q2kA1agAEfBDEOJ/DxSoSVAPyjoFGtwzCZBUuko+o/JYaAZnOmId0IQAVCC5eKGqTEhElSG/xDGu5hsfVICw+OBhATB6AFCKceW2ZnQABFAPa+sQdvIokGsutmLDKpS6chK5jopofYF9DxkkpGcw8OYXsGO7FoEmFNBDrBkAY+k0DYMxygc08Jow+CBNSMBEhRmoAP+ZMmzQXyysJHeBiVlnGyniXAzwMM/ii6QEAlOgNQcQSQEwUKprEbY2mDl6ALrUAATgAAsAfraykn5hwZNcGoSHGGWQVSMQAfXgepHyM+jyw36BBw6gyxCDAA1Ae/QAVCk6AoOstbN8M/T7FwoAyr9JVaxMXhFwan+BfxFlxYRCAbccys18EeP5zL8RcowxPj2kn8aoTz56GNfoLS4gKZKSF2XETEzsNkhszqvhxKTcD2s1qGSKD1TQDt7nGOQVAPxHZi1Xp4YRPfxMyVFFwofxwapAuqxHGXzjJg8AKo3xvBFdG70xQ8dc0rtZASeN0iq90ih9zC290i5t0g1ABVT/kAQzfcyyJdMpzdI8rdIxfdI6LVvqcMxJANRG7dI9ndQw/dIl3QANMLNDrdM7jdRU7dNW/dJYrdRavdVc3dVKXdVZDdZTfdUpbdIZSxMk6a3qkA9syNZuvdb5kAT5ENdzLddrbdd0vdZ3TQ9xzddJoA4HkAR+rdb5QA+BbdikW9eKTdd57dYHQA9/XdiofNdqPdmke9mojMpyzdib3dmKDdeRrddx7a2rMAaRHdmB7dZ4vdqq3dp37dpu3Q50LdtyTdv5YNu4PdftUNu6zdu37du7fdu9Ldy/TdzBzdfeCtus/drMTdepLdqiXQHRHNKNsQBAS92h4c/YfVt1uN2g/6Hd3o0RshzeryOI5F3dp3veqSZV6t3G3d3eODTd8G025TzfmYEPh8qW9l3B6b3fdCzf/i2C7x3gf6HdDyw7+XwQCY4QWUsZ403gjjLRECGMjtQA4RoRAEkRy/e6jPHgEG4RTmwptWLHB7EktRKGD/EAOVW/+NNG6G2JHw5yh0riBKFevNSdEEEBw+w5DxEn0zwCuMLhCDEGZ4Boz+mdAx7jIgzgrjmR9utpHqPihIHiCgHAvBROEqHiDDBbNyxi/a3kID4YFJ0QjSwnNw4RCDATA8DMMgoACgBHSsabQk4QWA4AoIXjk7EXYN5l7I2O6hAB74mNDnHREQBPDkDlDP9eBgFgI5ky6HIyAnHVDhHgaomZ5HsO4lFF4wBwBjiHB//wxQaBVOSElczsEP1wouTnTse2EAqXQlXTa6tS35feF5WMEFS0AAY0LYeOhQexQM6CHifUMwyuHVxOEPRgrgqxQJK+fXgwAqAOGAtAa7N+F0sYqGywKwTBAG0wzkzCBgBL6gyrEAKABJqZHWdAYAsR7AWxyl2eqpY+7RKBdXnhA0jgLnnByuLVD5zLZfeebLmoFw4wypfM7XEUAemzDkDu4F8O79ARVfo9EAjf3Qew7WASqCNAwQPBAP+weLwySiRSKNCXEaf+VGY1Bg5gSIyxzwzfuME5EAIgs/BlAYf/lRA+cPJf0w/nrhD7BybNLrsE8VmcdAQj8O4Bu/LtNuMJoeIcZxDzqqYEIfTXPXAG30ZKFi8uLk1chq8Xv18HQQUuEMIP7eFGL65iHupn0lgKYQFIwGfnYR4yuxBsfGwigr62Wx3NfobZQeTyRoEToM3zxj1jXxzTTUETIKoJcewcLycR4IwJMTLpkwABcOEHoTIuShMu8O7pRPD0TfSBP4wtLwDRxCkkYgFkqLQIoCLsRqqjVDg/gAAPiCXqYR1r3ip5oV4dNyJ+k83o3fmYTmhI+2PrFAIPIPxJMvwNsp0+MAE/F4UToKsN8h+PchPrkAD44AMgRhDtEAAiCiDc/08pzw8gBIAEAmPmveMl0Q8g6zBjz09ewrLg/bTwvI+G0SwAFMAGc+UC92//U8AG+48EBcQGANEOwMB+Bs6cqXdmxBkXEA6eaaPwzJR6Agf+oMBmRAQ2Dx8icSDxIYOBFnww1LgRwgiWGwNMGPEP5oKBNW3exJlTJ4AKFnf+BBpU6FCiRY0exTlgFYABEnT+qNkvqk1VOi30U2Uha1YLV7P+uAr2piquFgD0+9EPbdiwaG2qBbC1a1Z8dC3g63oVadF+FUjuBRxY8GDCOZsyJVBY8WLGgUH8bRxZ8mSiAxIfppxZc+Gemz1/ZnwYM2jSpXMugGxa9Wqdoimwhu25r//P2LVNi3ZqW3dj1Lt9ex7wWulv4oFnSy2efDHuvM2dP4eel6tc6lrnSsduXXt07tOtVy/LXfx45wL6jWnXTwB59u3dv4cfXz78B04HuECAQEF+/v39/wcQAQf4GzC/AgM0EEEFETywwQUfhDC//fI7gw0D95swQg035LBDDz/kcKnRlCMxKL9KRDEw3FJkEae+Umsxxp9EW0rGGHuzMUfD7MtNxxJn8zHIgSxjqkchkzvxSB1XVLI4IJu0UbTEoCQONeSoZDG4IrH87TEuW2TyS9s6ExNF18qsrR8c0VQOHxFXueuIAuS0YIA677QzTzz31LNPPv/0M1BABxW0UEL/DzVUTwvGSKKrRBGF9FFJI6V0Uksr5RMP+85QoFNPPwU1VFFHJbVUU09FNVVVT3WBjVVfhTVWWWellVQKEOCRzdgqKENX5QrI1dfV1hTWt+GIFGqdI/BI4IEH1rmIKAuOaMfZI8w6ygI5jlhnna6OOuIBeqp94FrKKshHs7TMjQyqIwag7F2oQgs2KBCmQIKAMShY4IGrpJJqXp3oudUFFxjwgYEB0gIAKoFz+mEMF0DwAQEqqFjHLbcexmmBEaZwgQAQqHggAahUCbiwJyeTyoeY1Gm4sXZGCAAEjgWb94EzAlDAgptVrHcnqCxAIII2DEZgijGqAsEBA+B9ygID/5BwYQoCCLjYLBAUoKAAoI7YF+QFjDAAj7MqcECCI36yYAH8IijFhwXGgBcEJNS+UjBiJQMhgAcMGOFnwRgIgAo8RuiVsSNGkOCBNmha7rLXhkogggCmiICiKRgoI4AAXEh8J7AdMNiFMXzAowzL6wl9JzyqvnUEsgcog+Z6HhAagNenUKgeBMZYhwHbcSdMTRgBcyuurtBqJ4Bef0g7b6IcBuBac9cZAXIQRoDaKOob1otoAqSix++YCQszqB+o2GijCFxoh4IAzoA2KHosD3mKKUAAoY0RiA+KOhBQD/3V438GCEAEALiTfjCgDRFgiP4qsIB//GOBg0GXYh4whv8zRCACI3CBAiIgAZMsy3nek8oDQKCQf7CkaGewABXoYYEzGAAp/bBAOxRgwA8KKAADYAAVAMC1sxRGSyMSCgNc4LkIGKAfEqgZwIKSgCkksB4LOMICRggAf0hPJw9AgP8mQAULTGEEFRiIABg4EDwULQAjOAAAEEgFfwAAW4JZmXEWEAAHNK0NPqjAGBDwxgDATEB3HEo/QDABpQ1yChXwgQhppgAAMOAf9SvKAzBnAAl8bAELIABL5tePB5zQiEEbigDwkA/UUAFwPojkY8zCsJzkUB3qCKIE2mAAXFnsSoKzAB7oUQF10IMAAaiYAyiQD60U8SZwuQcVFuAXHyD/UwESQM0sA7O3o+DQZSMgwAP6UQYEEGBt8hsBEoIZAEwCJS0CoABMEMAACzxAAQ7AXd8+h7szoDGRAmhHRM5Ajx8MwAfw+0ECEniGXiHAhqdkSo0yCQKjBeAfS1xiAACHgAGoEWJgM6MLPvZAJoJzhl6siUET6AL8tcFznptCGfTyTAA8wAdICMADXVCPJT4wIuqQYjfJtE3urY9TA1CkC0Kgjjf6kw0giJaJIOAvdZwBnz84QATacQTPSQBeVDgDSltzRgBIQwJniCMeHqmKevARXuoYwUwFk76g9CMJba0aAjLqORf8430RWIAXVQHGCBAAZP94aWI9Bzmc+GMB/wbMn2IZklEQILIm5JxC0fyXWMtt5JFiFQo3h5KzESigfkmFmTrY0El/4YMB/XxKtKSSgDYoAICPRWMZ6tG3CkwrBNuzbE3mNVwKjMBsZ8GDA8YwLTbs0QdrW8f2qoI+4UxJKKRkSWZBUAoDOABknnOA5TznA7NMFwDrUAB+ynkrAiAhIZYz2s4MEFzs4UdpICAAArLr0sRKoCpXeoB9YZe0D7qkDVX8Y3CHIlqgIKdlSBjDCOg2EJ2hcQyf+8cDwangIgKsZWdwmVeHpFwAMJVmFWwDAsogOGfONgJNc0AIkDMGB+BjACypaACQQJu5opJtSLAcAigwhjKMgQrfBf8Zzd4YgXYCwAcGNMAfxqC0UuhVsS79300sIAGDYQ4ZCqBH1fDzUveZzyYu2ylF8stLCuyUry9tXVEyaBQ15iUCQsSHQY47gDMwYD+qGECg13Zdf1hgt9U7CQOkcp8KSCACd1nHAAbd4Dqj7SxgrYBaVDEGA5SvXM5KQFVYbJRjGQkoAzAaSzu9DjxQYcou4G9/EZlZ2I2BASpEsGLHa96Gua9qDVBHEcaQ37Z6zq8f7JlNWDqRWy2ACreaQgUVO4X5jjoneXRn9RaAAIbsLHSvBWolP9c9F+HkCBVI70EC4JMyPJLCOY2zM99CkDIc9CBNrMkRJEDehjkgAGisI03/B0PXn5TBBQxBQCkScAQGLKAU3i32QgOAgCtZQKRWGwM91vGAbeMn4i+NAEEGsrgP1mMM6ngAA8bwBw+SGX8uGEgdBwBZh2LsAVQwwk4n4PJ6EABeoNUJg69dgQBccZAwvVICXPCAAaQ3Adc920q2xt8zQEUtCahI04072n40vQ0SaABJ2VkTCxDABwBowIszc6ahzLwNt2rHOvCxcRDU432DNJ3+YHhHAxjWBzLEpQEAVw+ctvyDj/ZoTUE4hT8YgR7PerbYP/fmIyDHAhHgqdL6RQWKuXSQHuRdYTn8E2wDBZlm2SDXAiABdax4y2yoLdSsXRNkshGUCGT98yQw/4F64NMoK3z6AKpaAcI3AA9QcZwZhbh2H+8EHy6YgAsMUIoyMIAe9KBCGJd4TM/bTLgEiICQp2yEMRgBhB4U75LPoGWWwnoKFxs2Yj9XxcSuvybP52vIBG+EAULEc/wNmb0QOpwgGkpiI5HiGf97IwLgsaHoFOR4ANKZOAWMAAVoQKHonNM6ifnRr5fqJ6BTjCMyNdIbpHpIsT8AAX45OIOZvJcigIdRgJx6H4MxLJAZoMS6MATAid8ZoCm4FQpouZeKNY0CADWSCkcDISA0GIZ4oBZ6qSU6u24aQJxQqHBLgDLgMp/piiPgNaNwHCqYrSILK7CYltEjvYHYD7OwgP8GqB3cAYtrmb0QtA+JEormuSgX+IOkaQIgjAkZ5K84sokDeCDCSwgWtJydA7lCwgkqMKyiw7yLyildoxl6kDd6SCeFsByE0LXEuiCimDOhgIoFaAM66osROJ7AUIcJyDQAeKx424tFq4dkC7AoxIk4HDgRGcGfwJ4EagACIKBl0Cua6avJmwKOoSHMSaBBAiGWqBpR+hwvwgcQ+hyDgS9dQ6wIIDc7YinMOb8W1DUYuqGh8kSN8oE2uEDBOADG8QGtKoyAYwr9scRkWw2CAwqJmbyLM7wEEkYegwp6MCAhdAnxMhrEOp60oAKLUrJI1LUH8qeb0KecGkJv9JzlQ4r/Kby2doC+cxwMPFCIUxQMsziCahoDW5wMIkEWUOy3B6qiDyIzR7ycnVjHKTiwILwyBTCPWvI3mtzEUaqlo5OsJ/QgAjBD0hPH2Eg8ynBHkZvH5gOKB5DGjFIyJNCvD8pGm7AAHNtElxKpJrsJxwG5hGSiN6o8nWAAHnK5IeSebfLIYoENKUEKJQrLBEogAzi4FfuJIwiv/2NJixKpXgG6MvA3vko/zxkBmDnKqGojzlIsUyTJnPAStjQWpgwKrxMlkdoI21JKnQjJjagHxPIuxqlKzXwymKAZkFEufFijgYiu8BqkiDAj4MEgjYRM1TgiOgQKbLmjAcALelgAvOhE/5FzC3esEwAoAyp4uiMAJjuSNztamAeogARIHhdxMC4qibVpByFiFzxKktm0DXp8pi6ysXXYqqgiTy9SI6Yrg437TWtThR94F6YbysaqE2epkwHowpgrjMfkzto4FusCChBAALJxJXqgpxaDC51gRAUgAF6SG3hJSqBrGgNwNmlah+mKw3tRAGozACpgANSMT6QoysbohzqyvMgwLxDspiIEzuWQTOGyIwd4oImwNTICACoAJDOUmqoJP9NhgIxpBx8AAdTUiao4Ar1CmjFA0qpQByD1GecDGZ6iGgQAqh+ApDE4gqRUy8yQCgsIUVoKDLMYpg8tijsqg97C0oG7jP9cRNDPGYP34ZcHaIedQ5ymNMEByhwpFZ6ckjGgYADv+qtna4cBYCKNhIp8iLaM6rl2OBzPccVwlM3CKFKaqQBRs4kzPYrtGQF+4w2aQYCxlEPEqCuC6BuD4b/N0azj0omAUwfEWoijETzLgQygi0D/0R8KKAVdaoPWkR6p2LQOgq8RELwWWsuKHFa+CDio8CgL8K4jKJ+nmwqooyUpUgUQsCCnpETlJAqsOIsuoormoYcbg6rlwMWi+AGnhMjnGqRwSyPQylPPCac9CtciOsybuB++8oECuLAeAUF62JnF+oEqYqyhEYzHQNFEIsMyEKcfcBmoIQAHkCui4FZVOIL/EDgCAfiB5kkcKpiA38xWie2KhIoAf+qc45pXpKARYz0CEFiAaikDAmgDSOIfVI0tBthQzonBBVAHEKgAjlXKfmiHBaCHMmiHYxoDCeA0niUIn62ABqCCMtievlMAEHBWwQjRbio0tFnMAOgXBxiAdQiAa5WWgWgHnyTMy6kPdfAHp7HaBNhAkGODH2JaAJAAHSxYoTBJNb02qcAHKoC4FEu/Dmqcm7SJH6gjLvXTy5HLN4pFgVCPcmNWIJS8xLLAh7WJv/mu9lEszMRWo3gRPKopf/OBJf0jYUIgz6FEg/hQd8yzAFiFJa3AMqCH7fGc1+gcpH0mNTpIBVCHCjgD/yRggANYgH69jABgAEs12Ra9iS4qg51JsZ5KrDaIiHpAW5paBwnAHARULEhUOwLUnZ3pTLA0NmNjLKu0xH+gCPlbzA+S2Ust1qDwh8PJLzZQBwEwqDMwmxg8uK4zswYbOavituWygBWiRKILiadDgHhtsC56JemDlwM4A6hSKJGCl/040LmqrqLgs1Qrpx36oIhUxJvgs6M5GsyjycFcxZs4AgUQRsNiQcUSrwWwrAdwwsK6HBCSP2n8oDK4z6GoWr5wAAP0MwQwG9VigL7RXBBLo7o6KOgigDNQhx9YBzbY2aJrAKgAKzEFgPLplQEAARdYAIlVgKVpqqo4gB+CKP8kIj0DwDwCwKJSUAe6NMTEiitea4DPORrl4lsjXQgh9AGrc8eYrAcf2JekYblNzDKy67a7K6eisbLETRosvgmLxAkjlAqiQwDoPIuyhKraqSI2LAMtagDS66K06Jwz8AkwWgVVwIczGKSdvYck4B3BmU4cgoiGlBoHuJb90ChnKQMKCKsz9k936sH3wwPrwwODYCmx+wckeKia0C8Q0peTE6TigkrPQQAfOMofgIgRoAAjYAA8cDYfzKi9+of5iouaKrr221B6+IP366Dn/WDO7WH3HQgXYL3eIx4+Q6O+adjPad1QHYhVcIED4J3E+QEJUIB+KGMF6Nf9mbTGws//ShoBejAIdcAWdYiAueMjnJofHzAZ4yU15K1cHfNB1BmABKBokIE1xUIAL20f07E5V6NJAjuam8ADV22iBZCGB1AHdEJfGQwAgemcadzQ4FkA/YHeltzeo5DkZ0o5BmCqp1OFCiArppiYMToK2hHaf1g+jPQBtcCIs9LBctMJHEq5ls2NBFDQJkU3wNnhuj014bDNGdGfy3kBjWMAhOkulzixN7qjIsUcw+JQYyIAWHugikqIAJCr+2CI/Lq+DRKpHEtE8zJX/PiDxmk1Cig2y0HfsWbfumUesjWl84ItniDCbD1msGzIflAAfnMcF3hotmGKCtjL1UOOH1gABSgA/6nYGdvtsS1puxGgVQoAAewbA2SgmvQTL1qsZ6MJP05bAAMwIw+yu8RygJtIAM8yHeqDXTfSNQi6COwyI5AxgGGjAJncyWY2inkmQAX4o3bo14kDsHoIAX5drqJwGQVggA4Uy4bphyNgg6YlHa9ByZlxAHpIx/8DoB/ouwGgy0YNQREJZqBYycxiYyMwLDdKMSZ62Yfxx/fJrPPWK8kOwpG8CfAjICnFL1iLgAyznFizIamoI/C7OL0q7INzYcsZ32zdzqDAhw9eB33xNxCjgnaAb947gO8RigAw8QGgB06bHwPoCXqAohGorGetRwRQww3SotIyvjItOgd4usbMav+RFq6+8TUKOJrrdak29+ubqKpg7LIlKjYDS6DjIT4IMkSQ4a+BFK+GHIiHpIj8sDtp9Jx6iL7b2Qv9rKvMKiLigwhXcgAQkoACZWpwLNcK/LeTMCAEqACu5N9SIp51kMpdOuoKobb1Lck0xWDxqge6nB/DfrMFNMYzKK6SsrsKcsJDHwEvwsucGqAwyimFeN5/qIfYztOe+ivFtCodA2mgYG+ccJxQZop1cADmxiMQ21LLsL/CmBp4qRO4im3QcMtEAoAx8KsRoAKRqmbxwhyYwQlLZKm4ZAm/Sixsj7k2LVsA3ERAHwhVECG5rKjIfsI3AvUFa9+pIDo0GgA2cFj/xcCuPpYjBcqJkv2JgLOADIUXeviHhC/JccVgJasg4VZMlwLHZ+qH6Tb2xM0whXz4nPj1nXRhBVuHYjP56h7CEXp2onzUnFjVVeCdgw8MnWGDUIJwwEhhEFP3nWe+iDoK4TH2OzTk31SjmSkwOc6xCABEgcsqmeevETh4ASA6OZbLWMNluO4Yj+9Ko4XkokhZCRD6j6QCCTh64GD1oXDHqlLuK9txnBCeFif5IIwJqBq1fBDInRQIkE67Jix4wiQetLcJgiURyE/RpQRu72kH+ktcl5oCsC04nzR0HUt4f1CHwNS1g1EfBnjbrHWAuOfhnt9P4LhgwKgnC8jZB5DY/8ENinqaVh9QloWBOoJAztt3zx3eCX9ZhwUI0kizOuPo8di3fDRmSxSlfIdUe+gvSfuYcOxvjGjn/qaX/u9XjKYW/8aozfKPjNJDf83wzvXPUvf/jP6E/8WQ/Pln/03xAU7SfwmQAE7i//8HCAkSDAgkOLCgwIQKFyY06JAhxIgIJ0qM+NBgRYkXDbBRcPBjxpAiR5IsafJkyIsHCQDAt+pBgnUxZ8qsSfPmgJg5c8rkmcAn0Ac8h/6cCdQo0p5IjyptWtTpzqQ3bR6NOmBMg6JRbXKd6rUr2K9iw5Ida7Ys2rNmczKQAGCAWwBy59Kta/cu3rx69/Lt6/fv3gXtAP8TLmz4MOLEegesehtXMeTIkifXXVCGMubMmiPDfctyM+jQmxcwEG36tOgBLDujbu3ab4XBr2fTBtyZde3cr0nr7u1b7u3Gv4dr7hebOHLXtx8nb56Yt/PomgdQcCz9OuB+0LFzT3z7c/fwd0n3E2/+L2Pr588bl73+Pd7l8M1vn2/f89vq97G3339fvn/X1RfgeQAS6BwIpR24noELIkeeg+ZRl1+EyR1XYXgNYtjbgBtGl156HvbWn4jXaVjibB2iSJxq6q1IW4IvOneijKdBWCOLjU2IY2sk8vgbjT+OpqCQvbWIW5Gg+ZhkbcExKZqKT6J2JHNSYhajlbMFmaXfYjdyOaWO4H0Z2ZJjpuYWkmZ2SaSaoVHZJmRlwpnZbfrNiViUd3JWXZp6Aoaln5g5aYEq/VhAKKKqJLqooo0y+qijkUI6qaSVUnqppZlSKoAFAhjajwAL5OMpp4Za8IMFpqKqaqqHrupqq6fG+qqsrNoK66214rqrrr3S+uusweYK7LCtFpqAW/ic4QACDjjLLLPNIiAttdFaO+211WK7rbbdZvstt+B6Gy6545pr7bMOsMGGs822m6677z4bL7TzwnuvvfnKu2+9/NL7L77+BtwvwQDr22+8VQa6MHEBAQA7\">",
                                    "score": "3",
                                    "selectitems": [

                                    ],
                                    "answer": "△△△　   △△△△△△△△    △△△△△△",
                                    "diff": "3",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "118840",
                                                "name": "10以内数的认识"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96868",
                                                "name": "1.数一数"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                }
                            ],
                            "score": 3,
                            "answer": "",
                            "diff": 0,
                            "analysis": "",
                            "extend": {

                            }
                        }
                    ]
                },
                {
                    "title": "三、单选题",
                    "index": 0,
                    "questions": [
                        {
                            "id": "1122984",
                            "innerid": "",
                            "index": 6,
                            "typeid": "7f88297d5a78455d8973aba19f38ccf8",
                            "typename": "单选题",
                            "content": "",
                            "subquestions": [
                                {
                                    "id": "1122984",
                                    "innerid": "",
                                    "index": 12,
                                    "typeid": "7f88297d5a78455d8973aba19f38ccf8",
                                    "typename": "单选题",
                                    "isobjective": true,
                                    "content": "数一数，下列选项与图中的水果个数相对应的一项是(    ) <br><img style=\"vertical-align:middle\" align=\"absmiddle\" src=\"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCABDAQgBAREA/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/9oACAEBAAA/APfqKKKKKKKKKKKK5/xL4lg0RrWBTPLfTOGjtoIRIZEBAYEsyqnBOCzryON2Cp2bO8gv7Zbm2cvC5OxypAYAkZGRypxkMOCMEEgg1geIfFdvpGpW2nwedPqJMUrWyphDAzlWZnYbQQFchQwJIHbJroLW5ivbSG6gLGKaNZELoUO0jIyrAEHB6EAisfxH4mtdCe2hYXM95MwMdrbRB2kXODuZiEQckgsy5K8ZwQdqCeK6t47iCRZIZFDo6HIYHoQawvE/ie30AW0ebiS8lcMltBB5hkQMAwJJVU4JwWZeRxuwVOxZaha6ikrWsu/ypDFIpUqyMMHBBAIyCGHqrKwyCCbNFFFFFFFFFFFFFFFNkYpE7rG0jKCQi4y3sMkDP1Irmv8AhO9IXUp7aZbiCCOLzFu5AnlynAOxFDGQtzgAoMkYGcjPR2863NtFOiyKsqBwsiFGAIzgqwBU+xGRUlFFFFFeX3eoxa/4ouLuCQXFlHiO2mT7rKAMkcDI3l8HJBGCCQRXX+G5ooXntJL28mupyboJdHKqnCbYjgDau1cgZILgn74zwouLTWPGmo6pYy7oJWAzksJNgCK6dtpCEgj7wIOcCvQtDk5kBjtk85RKZEbEszj5GLLjnaoiG7J6gcYGeDuru21/xnc6nbyGe3jVbe3mRm2PGoBJAwARvL4bnIOQcEV32gSym3eOa4uJ24kVpUAVFJICKwUA42k4JZhkZOCK4a81CHxB4ouLqGRbiyjxHbSp91lAGSOBkby+DkgjBBIIrs/D13Gqmwku55bgqZ40nQKBHnbtjIUblU4z1K71ycMtbtFFFFFFFFFFFFFFFcj4zv7sX2k6RaTXFu10ZLh5oH2krEUHlk9RlpFPBH3CDkEiuI8QeDrGSzW0gkubaNECFIpMLj024IxjjHpxTLbxLrWgahHcDULu7t96C4gnkMxeME5C7yNrYY4IIyQu7IGK9ooooorH8U3F1beGNQksopJLgxbF8uQxsgYhS4YA42glun8NeZ+G4LXTrV5SlpaRqm6VUIVEwBk9BkYHU44ArpNZ1dbDw672safbgGthMWCPGk2FOyTOUO7y2wA2SoGP4l5rwzb29lHhYIbYFQSkIGwNjnoB6dSB2+lb2s6hdQaFNFprul2hDs2+RPlfMZ2lSBuAZm53YKqdudpGJ4Xs4bWIeXDbwZALRQ4AVuOnAz6Z46DiuqvdYTT/AAvfwwSeXeSxOsbNcLFhipC7WPIYnAXAJ3Edskcj4ZittPtpneK1s0QFmEZCxqo75wOwGfTHtXc2uow2/wBiMaWv2pZ1gMlwQp8uV1DKj/wknYQuDuKheCQw62iiiiiiiiiiiiiiiuY8XWoifT9aS2eaSyZ4nKljshk27m2gHPzJH6YG4k4BrldU1e2uC7xlsHpkVzUVlfa9eNZ6XAJ7kYch5Aiou4DcxPYZBOATjoCeK92ooooqOeCG6t5be4ijmglQpJHIoZXUjBBB4II4xXn134GTQrOe9GueTp1pF5jtJbZaKJEy5OwgMeCcKqgA9Djnd0vwbHZXDve3r38Btmtvs0qfu3VsbvMDFi/C45/vNnORjFi+HN3YtEtvq++EPsP+jhGWPovAYAkcZI2jg4UcCtfTPBEVrdmfUdQm1BfKlh+zuoSFkk6h0Bw4CjaAeME5BPIw774dRWVpIx1dE06EIS08SoYY0ALSMwZVyCN2QE2jkcrzt2ngW0M+/WJ11SIKVFtNAPJJOPmZWLbiMcc4GTwTjGNd+Bk0KznvRrnk6daReY7SW2WiiRMuTsIDHgnCqoAPQ456HQ/CjaRqK3cmpzXPlwmGOMjaOSMsxJJY/KMHPds5yMdJRRRRRRRRRRRRWP4i1u20ewKyTypdXCOtskEYeQsFzlVPy8ccsQuSoJ5GfI5/GHiPTtXjmms9c23BWO68z5wYsYYxqsoSOTCghgAMnpya9T8N+INHudN0+xg1OSS5WJIVS/kAupGVMndn77YBLFcjIJzXGeMvEF7f3c0OjwavcacirIbmwuXizMN6kAh0bZgJjB2sTnHc8/4WuvD1xd6ldeJNP1ezDO8ixsr/AGfHy8IiEyK2Q5CjKYPGMhV9LR/DGiaEYtLnihivfNjimsy0zuwLZO5SSdrEjJOFOFyOBXmeo+MPFmn6q11DYarDc3qCCRrgNPHbg7MyRxCURhgAcZUZPU8nd6h4a8XaVq9vbWi3U8d/sVTDfhUnkIDc/L8jMQjMQmcDqBXS0UUV5xr17cXnjmeASzRx2IiRYw7bCdvmbwMABj5m04LcIOQcgdrorzvbStKkSwmXdBtdmYqVBYvnv5hk6cY215xrTSaz8RLi4N0s1vpziG2WJyURlCliQePMWQyLleg4PIwO18JSOF1C3ub6e5u/P+0FZSgWOFxtjWNVJ2xgRlecFmR2xzmuZ8R3M2o+Np7YvIkVj5KpGWJQsAJRIAVADZcDILfcXkHIHa+HEWHRoYVZSIsoqpGI1RBwiKo4AVdq8YzjOOa4fxPI2r+Mbqxm3G2tBFH5D5eNztEm/aVAz84BwWHyDkHIHZeGftv2S7N5PFMGuWaFkBUiMqvDDoCG3Djr97qTW3RRUc80dtbyTyttjjQu5wTgAZPA5rzDWfGmqX90fsDtBbrIjJErBGcK2eW7E4Hy/dONp4JNdXpPjazv7gQ3MX2QySCON2kBQscBVYkDDMxIA5BwBnJArob29t9OsZry6k2QQoXdgpY4HoBkk+gAJJ4FeY6p421S+vYrixMttDDIHS3zyw2kNu253HDEheVyF74YdTpHj3T9SmgjlTyEuXC286vviYkDarNgbWYkheqnAAbcwWusoooridbjeXx9ElwU+znT0NuHzkt5j+btzx08nOOfu5/hrL1pVDvncdpxz1rz3xEsr2Nwto8yXMkbxRCD/WOzAqEXjktnbgcndgcmvUUjRdEiZR9773PWuS1UR7mXaOaj8EW00uv3IuBcPZJEotvMZjEjlnMix54BP7ssF6/KT610esbdzhz904Ga5ONc67pzxRGaVLyJ44g+zewcEDPbkD29a91ooqlrGox6To93fyNCBBGWUTS+WjN/CpbBxk4HQ9eh6V5T4ckkubh7p5PM89Nwczby4zkN6EndyR7da6nUNQj8NadB4k8l5nVTYyRI5RXDuDG0hCnhHyAWwFWWQjLEK3L+HZJrqVrp3Eiyjf5hk3l88hs45JByefzrqLrVD4Y0ka35Zli8wwvArFEZ5NgWSQhSBgoi7mxhWbGTtVuW8OPJc3DXTy+Z56bt5l3lxnIb0JO7kj2612738+j6G2rvqFvFaWiSb7e4IVJS2AgMmMo2/aAfmGGYbSdpXiPDUr3dxLdmXzRICGfzvMyQx5J6buufcd67ITwaQ+maw6ysZpV0yVYs4IlkURs+Bg7HyBuIAEsmMswVuxoorI8SBZNK+zO6qLhwnJ5OMtge/wAv5Zrim8NW5x87jHvViHSobS+klMuUdA7BuNhxgnOehAGOOx56AdN4hdZ9Ft4JphC126psbClztL7QDzn5ScdcKfeuS/4RqDcGEjjBz1qumjadDPqmmT28i6dLbmaWWSQhG85pPNUNxjGCx543joMV6PpMl9No1jLqcKQag9vG11FGcqkpUb1HJ4DZHU/U1corg9W+MfgfRri+tLjVpGvLJ5I5LaO1lLGRCQUBKhc5GM5A98c1h33xFtvFugw6jomlyrDb3CefeXmo2lstojMULSDzS4yRwpC7sAg8DPKat450+2EcdzfWrSyDOILmOcA8cFoyyjr6+vpUkeq3nhnWLO/u9G0+7ZozPbR3Wv2dshU48uZCZDvB+fGVAGARyOLvhzVdT1VZ7W1s7PcjSTLaWGpWlwIYjJ8iKsTk4VWRc7QOKx7vW1mvZraUi1nhdBPDeTxWkyBhuBCXDx545/Eetdre6drUOgaZDofgK+tNShnWSeWS7sjkMoE37zzNz52rjhM7EPAXYcbxDqN/oyWUes2M1rc3z7Le33LLJK/TaojLZPI6Z+8PUVQ0jVbXStaudU1qzS4tdJh+0NbwXdm8kbhgN0kbzK6FGKgLt3byo4KgN12pfHfwppkVpK9vfXEd1EsqG1e2lK5VWKuom3Iw3bSGA5BxkDNdf4Z8beHfGP2r+wdQ+2fZdnnfuZI9u7O376jOdrdPSjxN428O+Dvsv9vah9j+1b/J/cySbtuN33FOMbl6+tcfJ8X/AAn4lvpvD+nW17qLyhRG+YoI5mJXaF86WJmO4gbRgnBxkc1kReLbXSICNRg0Gxnj3Lc2f9ppLLE653KQsxORtPGMngYB4oPiq81/w9qFzoelWN9bCAySPDfRRfZ0wcGUyTZjIKmTLRkELtxyWGTYeIbexsrW5vdT0lTGm6SIanbTSK/3c/u3OeCx4HfoMYqxrt/r0eif2odEksY750gMl/dwWDBVDMq/v24bfu42cruwfuvV7w8dZm0FdRtLeK8ijAS4W2uoroq4xuGYS2Wwc4A5yOBVu71DxhZ2jajZeGftOnyQM0wvZ47IRxbGDb/McOpDAMSQBtJHB+aq9v4ii0vSLLVL6y0Sxt7xJCgGpLKHKff2MsxD4wRx3IHBOKgtfi3pdhrUi3FmE+zJJNNGiiORFXKGIieZD5oYZ2hSSOAp+8Oo8P8Axr8GeIbiC0S6u7O8uLhbeG2urZt0jMQFIKblAJOOSOhzxzXT+JfGGgeELeCfXtSjs0ncpECjOzkDJwqgnA4ycYGR6iuM/wCF8+EJdX/s+yS+us/cucQ28LfLuPzTyJjuPmxkjjORmDxH8TLuBbzSbyysNFvvMZUS81KCWTysDDkISIpMMrANuBxxkZIyrfxfrd7aXUmkafY6uLJfNvJYtQigjgjbcUZi5I+6pyc9s8AisrU/iBE2pWVudZsrJn8qTyxJHcLuyQVeSJnjC5weSOAC3DFa7TXPFWtW/hG3kurW3iEkYI1WWaNoXUnaJFdCURjuV1zw2cbeu3GsfEviPVfMh0TSLbWpoNrXH2e9jhEaSZMZ+cnOVB784zwCKdqzeKbi9t7KbSLy0EsgOxrNrpXTcyqJHj3RLnCkqSQBwSQa6Kw+IotNDiudRgS8gjf7M2pW+p2AillGeGLTIocqA+B2bOF6BzfF3QotRksLm2ntrpbRLtFmvLIJKjFQoWT7Rs3FW3gFhlRkdRnP0z4++Br/AM37TcX2m7MbftVqW8zOc48ov0x3x1GM846+bwnZw6jcaror/wBkancYM8tugMdyQWYedEflfLMSWG2TGQHXJrnI9H8Oac81vr/w/wBNR0fbBdadon2uK6XaMvtjjZ4Tk4KP/wABZ8EjXh8NfD650s6pBonhiXTwjObtLW3aIKudx3gYwMHJzxg1JfeE/AmmWcl5f+H/AA5aWseN809nBGi5IAyxGBkkD8aLr4ceC7zyPN8L6UvkyrMvk2yxZYdA2wDcvPKtlT3BqQeDPBTXD26+GvD5nRFd4xYQ7lViQpI25AJVgD32n0qvB8P/AALo1hFCfDmjLArhFe7gSVizvhQXkyxJZgACT1AHYVJY/DjwXp9nHaw+F9KeNM4M9ssznJJ5dwWPXueOnSs/7N4EtNR2aN4b0rUdVtZf9TpVjA8lvIp/jfhIWBBI3spJUhckYrQh8LXF3eXN/qV99mmvNv2m30lRbCQKPkEk4Hnuy5xvDxggAbACwPSQQQ2tvFb28UcMESBI441CqigYAAHAAHGKz9Z8O6R4gSFdUsY53gcPBMCUlgYMrZjkUh0OVXlSM4rn9S8OBLhbvW9J03xPaxoFa5urCNr+GMEngKm2YZYnaojIUHAkY4Mdjpvw2v7yOyj0HQ4L6TJjs7zSktp5AASWWKVFdlwD8wGPlbng40LXwn4EvvP+x+H/AA5ceRK0E3k2cD+XIv3kbA4YZGQeRUdn4a+H2oXF1b2WieGLme0fZcRw2tu7QtkjDgDKnKkYPofSiP4f+BdKSZ28OaMiT3G4tcwI48yRgoVd+doLEAIuBk4A5qT/AIVx4L/tH7d/wi+led5Xk7fsy+XtznPl42bs/wAWN2OM44oi8C+B7qVbqHw3ocvl+ZDmO0iKZDAOCoG0sGTHIyuGHGTmvqeg/DvRvKGo6H4ct5JsiCJrGHzJyMZWNAu6RuQNqgkkgAZIqOPw/HrGlzaZY6PaaD4fmffJC2nQ+bdNwVkWJgUjHyp/rUZzyCsZUE9Jpmj2+l+bIjz3F1Pjz7q5lMkkhGccnhVyWIRQqKWbaoyak1LSrHV7dYL+2jnRHEkZbhonAIDow5Rxk4ZSCOxFcvrPhueNIXl0u08WWcDhY7PUoomuoEZlDGKZ/lcBVHyyYZiCTKTgVHY6Z8Or+8js08NaVb3UufJhvtE+yvNgEt5ayxqXwBk7c44zjIrUj8GeCpnmSLw14fd4X2SqthCSjbQ2G+Xg7WU4PYg96jh8J+BLi8ubOHw/4ckurXb9ohSzgLxbhldygZXI5GetRx/D/wAC6Ukzt4c0ZEnuNxa5gRx5kjBQq787QWIARcDJwBzUk3w48Fz3ltdP4X0oSW+7YEtlRDuGDuQAK/tuBx1GDUZ+H/gW8v0mXw5ozT2LsjJFAiqrMgOJEX5WO1lIDg4yCMZzRqXhr4faNbrcaponhixgZwiyXVrbxKWwTgFgBnAJx7Gq8ek22r6XNpGjeH7TSdDmffO93paIJzwP3du2CHBX78yYBRMJIpyOg03Q4bC4a7luru/v2Qo11dyBmC5HCqoCRg4XIRV3bVLZIzWpRWPfeE/Dep3kl5f+H9Ku7qTG+aezjkdsAAZYjJwAB+FV/wDhBPCH/QqaH/4Lof8A4mj/AIQTwh/0Kmh/+C6H/wCJo/4QTwh/0Kmh/wDguh/+Jo/4QTwh/wBCpof/AILof/iaP+EE8If9Cpof/guh/wDia3IIIbW3it7eKOGCJAkccahVRQMAADgADjFSUUUVT1LSdN1m3W31TT7S+gVw6x3UKyqGwRkBgRnBIz7msv8A4QTwh/0Kmh/+C6H/AOJo/wCEE8If9Cpof/guh/8AiaP+EE8If9Cpof8A4Lof/iaP+EE8If8AQqaH/wCC6H/4mj/hBPCH/QqaH/4Lof8A4mtDTNC0fRPN/srSrGw87HmfZbdIt+M4ztAzjJ/M1oUUUVXvrCz1Ozks7+0gu7WTG+GeMSI2CCMqeDggH8Kx/wDhBPCH/QqaH/4Lof8A4mj/AIQTwh/0Kmh/+C6H/wCJo/4QTwh/0Kmh/wDguh/+Jo/4QTwh/wBCpof/AILof/iaP+EE8If9Cpof/guh/wDiauab4a0HRrhrjS9E02xnZCjSWtqkTFcg4JUA4yAcewrUor//2Q==\"><br>          (    )  (    )  (    )",
                                    "score": "1",
                                    "selectitems": [
                                        [
                                            {
                                                "itemname": "A",
                                                "content": "3个  8个  2个",
                                                "issure": false
                                            },
                                            {
                                                "itemname": "B",
                                                "content": "4个  8个  2个",
                                                "issure": false
                                            },
                                            {
                                                "itemname": "C",
                                                "content": "4个  7个  2个",
                                                "issure": false
                                            },
                                            {
                                                "itemname": "D",
                                                "content": "4个  8个  3个",
                                                "issure": false
                                            }
                                        ]
                                    ],
                                    "answer": "B",
                                    "diff": "1",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "118840",
                                                "name": "10以内数的认识"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96868",
                                                "name": "1.数一数"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                }
                            ],
                            "score": 1,
                            "answer": "",
                            "diff": 0,
                            "analysis": "",
                            "extend": {

                            }
                        },
                        {
                            "id": "1122983",
                            "innerid": "",
                            "index": 7,
                            "typeid": "7f88297d5a78455d8973aba19f38ccf8",
                            "typename": "单选题",
                            "content": "",
                            "subquestions": [
                                {
                                    "id": "1122983",
                                    "innerid": "",
                                    "index": 13,
                                    "typeid": "7f88297d5a78455d8973aba19f38ccf8",
                                    "typename": "单选题",
                                    "isobjective": true,
                                    "content": "请看图，下列选项填入括号正确的一项是(    )<br><img style=\"vertical-align:middle\" align=\"absmiddle\" src=\"data:image/gif;base64,R0lGODdh2wB5AHcAACH+GlNvZnR3YXJlOiBNaWNyb3NvZnQgT2ZmaWNlACwAAAAA2wB5AIcdHR0bGxsfHx8YGBgUFBQZGRkcHBweHh4XFxcVFRUaGhoWFhYhISEmJiYgICAzMzMpKSk/Pz8+Pj4lJSU1NTUiIiI4ODgsLCwnJycuLi4jIyM0NDQtLS09PT05OTk8PDwwMDArKys2NjY3NzcvLy87OzsqKioyMjIoKCgxMTE6OjokJCRDQ0NTU1NQUFBUVFRAQEBHR0dFRUVPT09OTk5CQkJcXFxRUVFLS0tZWVlNTU1KSkpERERVVVVSUlJMTExYWFhGRkZISEhWVlZBQUFeXl5fX19XV1dJSUldXV1bW1taWlpzc3NiYmJ0dHRwcHB8fHxoaGhra2tlZWV4eHhjY2NhYWF+fn5paWlmZmZ1dXV3d3dubm5vb297e3tkZGRxcXF/f39tbW1gYGB5eXlycnJsbGxnZ2d9fX16enp2dnZqamqSkpKfn5+bm5uKioqHh4ePj4+enp6GhoaLi4uWlpaMjIyFhYWAgICUlJSOjo6VlZWIiIiNjY2Tk5OYmJiXl5eCgoKJiYmDg4OBgYGZmZmcnJyRkZGdnZ2QkJCampqEhISlpaWsrKy2tranp6eurq69vb2ysrK3t7e8vLy7u7u/v7+xsbG+vr6wsLC4uLihoaGrq6u1tbWqqqqioqKpqamzs7Otra20tLSoqKijo6OgoKCmpqa6urqkpKS5ubmvr6/S0tLQ0NDc3NzCwsLJycnU1NTExMTX19fY2NjMzMzAwMDa2trf39/BwcHOzs7Dw8PV1dXNzc3Pz8/T09PGxsbKysrW1tbHx8fZ2dnR0dHb29vIyMjd3d3Ly8ve3t7FxcX29vb19fXy8vLx8fH9/f3t7e3z8/Pj4+Pu7u7p6enl5eX+/v7n5+f4+Pj09PTs7Oz8/Pzv7+/g4ODw8PDm5ubk5OTh4eH5+fnr6+vo6Oj6+vr7+/vi4uL39/fq6ur///8BAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMBAgMI/wDXCRxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzatzIsaPHjyBDihxJsqTJkyhTqlzJsqXLlzBjypypkg0LJjhx0tzJUyazZgBauHhBlGgAAc569mzDgEHBAUo/MoBRtGrRGAOeRXXZgIDXr2AJrIMmdqtGBw+sqiVawKzKsHDjur1oYK3dFwfmlozLN6xeik1k3LXL6G/IvojBGoY4gCiMGTQizxjcdnFHvgYS+7XMEALRGY0cNWoUwcmTGg9q1HBio8YACZw3RoM7gYA0AJq/ToutsEXRG9SoBagGI7jx4FCoQeWNEa40r9KkUchdlrlBN76JDgjO6rj3RtTYQP+zbvEG2OgVbEe3lvsN+YJRssuw4L2+8UfM3lf8WiH6c/8ItHKBZpbBkdA1DPiGASTY2GffE9notx8BzbTin3raRLcNYgksFgc1CW0XwwxyOOigFNxIuJ803fjnnzPXZCiNN3zNMVckFCiwDg7USILQdlNsZ18EDi6nIkWTsOJidGJB46Jcc1FhXA7U6ICQE5Tc8IiJGRxXCR3WFKaXI9Uc5Mor+VmUQAIaLPmVNs44QyNcekXSwgYDcEANEwZYclALOpjoYB2X/AWLBbGs04FAHgzwwQ5VXFSAV864SIVXC3zzjDNQugVOI9hgE05w0YgDwQSyrMPNeHZMU98ADTr/aMU4W81Cq0AVRICDBS3wAEN2L/hp0TeZPUNLdM5oRUAC4JDzDRsEDPDVYpcMcEU59YEQAhY5CCSCd7UMMIABtth3x1Y1vMCBuAAM9oIIClg5UQC3ENBNFtE9syEBB8SCCzkENCCNNnhUp5cW1LiQBwP1xdDGFiOQkAsP3pUg7sXimoAtD1tl4K5dMPQgESa6EBANCNI48005tCSAyS68sOcMBA5IY1kEAnQjUAcDVBNcL3q0EcAeUJ3gy3EDWCJCnt75kAlC4vCB8S/XqDTBx3b9AEFElPTiTTTPpPwNNrHkogkmrYSjQKXS4GKZOQM0EMdAwOQJQBtt9EG0QHV8/xscOANQwMVxwQRwUBUD4IAQG1OchIIOWNu1QRcQXSBMOCmw/cwEfsCSyzCzYPMN2x8sNoMDRG0SAAUDQaMBG2zssUceXhgwDjchaCCOd96EUIA5VRMExADmLMTNACmOZIACkds1wDkRebDNps9x4kA4t/BCDDrbYLOswXMNcENRjf1ATQUFfOCYCljIvscXRnbyAxhRQJGQBmE8ZKQw61aQzkaNad5djPSQBbCtAp54RjTKgY1yRGMACVCMW1TwCQz8QC0+CIJahOA+91HhAD8QCAOowIsf5QIiPxjCELwQhj+I4Q/i2IgQBHiXGTRjIgSQUbKeEQsADCQsBuJJMf/0MIsovCAAOGgeBxRAhQ66zwpAkF1eDGKLGDqkGwf4gxa1SII/3CBNGRECEYBFw6o4oCFl2c1AxPCiBOyBINmgE01iEAEdiKCMRvlCByLjRNmtQAeAIAgkzvgQEGxRiy0IxBT0wBFxDGAoeCzKEKC3EBZw4BY1G0gAtOEAQeRQBSewmUC0gY11RECCMZEGHFbgmTK2QAF4i+UMDCAI2VXBCmGIwg6Stw4FBI8h0hjAIf9QhwcAwkcdMUYMIlkUGwFzZnDQhEAAUAcfAEAb2hhDi24jEGkEQBoVCMBXQBGTAZARjwOIpTrbAIQxCCILewBOICrwiUGIiSGh6MAwCWH/LWB8pDFCEIIAiAK55kmgCA3pzwGis447VACbEJ2AwBg6DSZJQwOVIIAoOhSTYwwAACOIHAU0cABxjaIIIUhBEbawTjKA4A0d8A4HHHKBOwyTBAMwHEjE1YUVKIcGKtBCAF/AgAFSwxYCaIh/QrAOcGKzDnvAJgD8kwJpIEMaxhAlT0gxgQtWJQM8iEAGxIUBF7igEN5JJ9780IUSuBULIeDGCyjQiVEFp4QL8YYwhwmCHlCDFOAQyQOmVIbgREAEg8XBA3gggAHE4IIWYMUAYvGHhiTDP1WQxh+u+YeoaoMCRVjSRZViA7tEwBPHMUMEzOAdM6h1nXgzUjRKMQCc/11BIcjYgQ6GuYMB5AIbnKAGEEQyB3Q4aBhmGAIxhmGcO4ZgD9gwhBoZ0gUX/WECENWGBbDpIhVs5RorKMBaKhCcbQwgA+Hwhnc0UAABHIAOgPiDOgk4EDBQch3NiFMYJvDRG9RBi4A4BAMAsIngGOBDJxAJJYxAjWP0IlbBQYQ1rjGC41SAFeTYzhV60INJJAKY0QmHDLKrjT8wQBvoiE4Z3AJJtcwgOAPohYlgoM4w6GBdEKDvQC6mgAyki2HUwADGBkCItK6DGkYgiDZqAAmObGcD2cDEcRq3DnAYwzjMpYYQggOAXORiDAO4YUKuWkpsOgERJF4BARAwlz4s0/8qFDgDNfQqqAEc4QmwbYOOBTLUosRUy8EJRCZcISXvHDkSjxhIYTMMQOWsYxzHUaBArmyfQlgiF2IIzgW6tRADaKMZfxgEibX4lwEI4QFDFVIiqGENhtXiOLEQlxzU6QIdhEHPCLGFD6wSqOPQYSD1Ia+j1zFY4/gwI9spxjUOcBxTPGAd5rAPLFDg5VzIwDjVYgg2W4ACbMoCmyZ4dp0coIIoIIIFL9jBcYIoiOM0wxhEKAMQACCuFKSAvyRIiAmqMgFQeOfXAjlHFpAWnNuuQ9jGyQhOjTOI4xTjDSYqRbVzAYLjKGMhB9iFJcgQgI6X4RSlaIMhODqXirdhGk7/oAFajYPMwRlHXExAg8xnDoU9E+QAIRgKDbbknR0MZBxCqo8J1lGGNBhHEBaBRhpMoBxBvfw4CsjFJaZeLWKQ4+ViPsgyXoEJVHTiEqLwBCM+IQdDFMLmPCEBNdBR2Ck44TjLWMcrQnAcATBg5niXOSEPogZfsOEWB6ABJOxzgms0o84CMQQFgmMGiwzgFjB2unKCzoJqI8ESUDmGBhgRnFQAQmcGQQAwuO51sINi7HJwQyH+sILwUYPZwdmDd6DRh6ArJ+95x0JSD2IFamAjBODQQSokbxwghOHlAkkCjCcyAI+q2zjTwMBxMPEK4xBjAHoQEgYwMXEvO6WXNjBO/wUiVJBkjB4TquhEJkRBCtSrXotb8BTFiH8cJ6ChC7iX+QVuVRBlKKJBEQAMRkd/3nEA1bABwUEOgSARD2cfuSAu3qECAyB9STMAv9Bl3VdtHAAB1FAN1UcNQ0cQ1+ALwbAMuRAJqjAKmdAI7bcJqbd6f3AIc7EGCvBq3nEMtFAkGOAGQ6AGeMcCA1ABMIAQ6pYB2OIgulAfsXAcn6AGR2Acv+ANDAhxwREHNGAtirAOjDAAbuAgiWAGRpCBE6cEdRAGRCAkU0QQCQALJoiCKsgJpJAKLugGfwAIe+cWDWAfmKcALud7eZgDrbAO5RAEMscASgAOwZFvCOECC1RnA/9wARcwAB6AC8bhC7ZHDSlAEQIQHNigDgchC4+oDuoQC0EQAgOgAKEght3HB41jCdQQDHKAEDAAA5GgCaGwCnCYCqaACD0QCS2RDQ3QCAJRC4K4BhcTA7/QCtO1Dl2gh0hwMUSwCVdHDSyACgLxBWhgBAOwO8ExAQrBCWswAb/gIC2gAeJSYffRKMfxA6xAEaxgAAOwBgoxDmtQjz6givjYAm4zACPAEDn0CSWwDmHgH97IEgYQHKDQBNRAA9OINGgABSjAAusgAZdIDchgCZIwAHhgZALxB+KyDkF3bAsxCAdpH7zQAURgHB0AATInAcaxUCdxBPiIj03wEAkQHVT/5iItATeLV2d4dwMD4Fr1gQiYx5EGwSNc5hDnAIEOEg1UMAB5Z5FoBxJZMJNiqAEQsQAJMA1ZIBAh0A0KYAZ88BJMZyJQiXf4VwSZ4B08cAPlYhxL4AgIYQfKkJQKgQqPwAQ+gAZk0ChmYAbLZQZRwAFiUAw7kHdQqRK3QAVWWW2DcIcLkQ4FEA6UGQ4CcQKVaZktEQDBAQfgsAICsAKi+QXTYAVegHdesAUzoHzIIJr0djGi+QJaZRB2QGkiaRAY0AJbcJp4NwUTQA7PoAErcAThYAgO0JtoYADklxInYJW24AEFMAW8lBDS4AjhUADa8ADhcAGamQEB0AyftgAL/xENINEGqkANDdAMTJB1AoETvDlzPTA8A0AC6qMWSJABIJAQtUkGTGADCAEMAZB/8PkBPVAKwbAO6HAGM6cFRMAELdGcqngFOVBbLdAQKDANlbkC2rAB2pABKaINHWAAEWAAkTBTK1EHCjCVvIkFTpAGA8ADkaMA8UebWrAOPVAACVYQQuAJxymgeccETcAFeadTLBEAVeBlfMADPFAA4mIEmUAGaGCiDIELGIAOlAkB2gAB6ABB2pmZNPBLO8EDAyAK65AFFUBDP0ABYBoIsEALKzAHOjCf9jYAkqACwYELPpqnM2cBduASUlAAAWACCipzXzAMI3B/wwARCPAVCP/wYetgAAaAAAWgAAAwB9qQozFhBlIgBRQgBQPgABqABERAQxZwAC9wm2tABH2gArGkAVPQBm5geyigpwKKA1GwDkngEg8AABtABTL3AZogCEvAl4uSEQzAqAnBCQOAUCcRACWQHS3QAk3mAeuwBef0MQZAAS1ABgOxBoiACLGECKiwDQGgAN4RCUYgcwWQBrTaBM8jEJ5qEgpACQEQPLcgYx1YAJLQoVBQiCkRAN0wDAMQRCJhDANAA2pBAjVJA9YgXgIkUS9gJK8VS07gisfhCzQABX1wA9SKDGeZfy4wADIoEEMANLk6EmBgCcOlI+sAe8GxBAOgBDKnBgPgoAX/kYURcQIF9QIZwAfDNExosA5wULMjIT52oQO/UAkgSUM+gAEMgA4DgQ0CcAQiIAIo4ASRYFfBwQN3AKZ8hntRkAEQgFfr8ANAkBQMsAQyMBI/YAmWEAK0wK0eYBxZsAZPcAFoEAMw4AVpcEICUQUTIFlPABFT0C5zFQg/O0xfIBBvEAjtCBKH4i4CgTo0NADjMRDm4B4CwXTo4DfgkIYGoQBZkAVAmTihMBC/MAGKsw6pK3NH4AMhYQFuawlaUA0NgAF+c3towEQyIHNVYAsC0Q1JgAYZsA5OcC4NsQJFEbKJ+7OKmARTeRF9thZTFAKVmwwGYQGaNABeQA0fQg2J/yKLB2EOiBO0AqEBR4B3BfkREDC7lqAAnDAMhfCWtzAAWoAGZ2kFZ6QCcDACQoq/64ACXtAQ+0YUF/BfzXtITIWrf4CpHWGqdyEABWm97uIDLeADKxAAlVEQ5wAFWrAN5LAN1AABDEYNxXoQzbAC5mAOS1ABCmAA34C5BgADeVcB/HcRXpBTBhACG8CkaoAJbjsKojAGIPl66xAFZeAAXiAAAeAN1dBxTWAMo9CvaGA4BeC1B2EAQ3EDR5DAP1sOHQkDs7kRA3UXz7gOLkC5g/EDUcBzVOAKC/GRp0ANt3CbBgGZA2EDA7AFuDcAMYwRcJCfO7a8BWBplkAC/kkHrf9QAevwCOLiA/aBUBYgc2VQDLwQvQPxARvgxT/rXetgBn+AlR5RxnfxQtlAAnYRBQ77A29JDYvQZA4xnT/CAizwAQqgAVggBQKKAXMQCFphEZfgtwSxAhpQFRKwB5ZABevgjfQ1AK7wKuvQK3oXzQ7RAYbEyYfUeiC5WRzxCnnwChA8QCeAAnZxAtSAAgHUyuHCEaZAq15whmNwCG2QKhXxCkSMEJdwATJABHSgAZQQCNkgCLugYw4gBZ2gC77QCZ0wADIQB24gc1xwBOswwAxBBw2AzdnslX8AApuQEc4wAIm2tIMxADswQKZAiQ3wAisXHFvwCxyRrj4qZHuAN1j/IC6TUBF5shDU0NHrwAGqgAr1ixCuMAUe8AIwkAxt8APFqwQRIApQIQIN8QJt8AIYrUWNtw658AdZUKMX4Qdboyo6IADXWhXTaxUakAt/EwMrHRwBIMsWoQC4twUVMAAiAFtYcAAbkBQJYQ0TAMYGMUMuUCgMwQCWcADqAHAL8QzQ4wADMJYg+dgM8QLUsAMAUNXyKBCAEAdcXRGqUJDBAABogBojPRgvVgrBMQ0FdhxgcNMa4QYGwANBcDESkGdtYALDRw2YJ24FoQHcIAPfVxDaQRBAyALWYBBwwAlyQAuI7RBGItHrqxCS/Yp7xcna3FBZcArSKxCrsANOMACN/2ABg0EVgyGkJlIA5NAR06ABtB1LcUAJ3hHUBNEzINkGBvEKLzAC5z0QEkAUPAAAv7wOJ1DMloACy01TAvEApSDKCxHd1GCwLkDdA8EETzAASBBIEwEb6/AMhBiEaTFAMDoYUWAAOWgfmDwRB5AF690GFWcfTr0bL8pn3OBMA8EFL6DbvVQVPHBx66ANL+AbiFDiB4EVTYzhC0ECrBUcIIADA1AAetC8XD0JYTYQOPUCN8wQywHaSuC2pKwWGPAHFrCza7EEJiIBl7sRq+A2pgiusAVk9oGVW+pdZBpXWFAQXJA0mqQWOm4NL+ADvQULJvEGQadB6TZkhM4xCCHIDf/hCbOwDlLQrwMwCZbAB+BtFQOgAUXgthWABOMzXkUSvhsRCVvADIY7VgrABrE0BbRADEwwBsSgXsaRItgACdxQDQCQDsHADeREEFxQEJswQ0UhBDouGAagCyZxDQVADX9wHIGAyMRADMFwAy2AnQ2BA8jwEKWzDiWABkmAA49ACpZwhUVxhocwu6XjGmBeFClA4h+BAuuAsERhDhIpLkPQBhZjCd7ABphQ0wwjyIYTAqPaeqVgEEhXEL6QFjNApOvQLixbEsXxKjQQAXlIDRcQ3AyBB4xBsmjQAm1gCYWwBoNQCEo+AFEACbP7AgG/DgIrLhrAX+KCDMdRCDsA1R//QQPrsAEEdQ7xTg3vOACusnsCYQ7BsBxBIOgRuw6KyBCxsAIn/3M5ExKuoACREAltMQEkvgqXUAsylmohlBAL7xBntOvm1AjuO/aza78DkQ5k3wUQgAjH8QLr4PMdUQnEUBQycA554QgOZ3NCVhUckCJdPxBwjxDFXQ27IBK2tw4OYB8NAAbUwPbkUNRFEacSXRDMAOQEgQGPfTx7kAVkP7uS4AFgQBBo775EUAlmIH2+IFRowA2r6xFyXxQ0oAo4iwLlcAiumhDA8OEvQAONZwSeaBBzMDzUahA15wE50AAi0Q2H3/CCQsFV0QLiAgX0vQ4/bgwS0Rb5eQ0AUA7h/9L5MjAAfn32Yw8VTaAAWlAOMXwDf78R11AJiFAUhmA73QAFwWS+CpEuPc7u17ABCSEKAdACAPEBQ6R1BQ34eAGASUGGDR0+hBhx3QBqFZWt0yaj4kaO0TAgfBGyQwFA2tYxK6clQDCJLdf9aCWj0QBKBacNoDFIZ4ABJyCmsyTJ0lBPAxo1dIBGhIdbLp1CHLCOWMgJauSs4UJogI+nA16wKFIwqssBEl6MXRdCwoA/T922RGFt45N1Gohx3KgODLWQIS0MADyAzVuXxsBFBPfrFzSJhSx9GGoJCZQB29bdiYIGTQYIaCGuWKaI8MR1AF5A+LV2dMELBVkkevsr8P+AX6ttNxS2gRO1PirW8RGBl+MADQAGpNGcHIiGc7edO1RgSUTkAVC8ZJtDRvMAkxPnQKW2aEADVW9TELQzABwMc7fFMXse//aA3dQmDfC07skAQ3ep6QIMi+RUGCC55AqQz7liLLDkE+oK7CGH7aZpqJQBmjiGITvAWaOQiiYwTwmG3oAiQRNPbGmTKDiSgw4S0IjCg9ko6MJANAaAoYbk0viACSYyQfEpECypxBHq3PACCs1AjMgAhhSgpoiKytHgrQFIaY6LH4LkskuKODJASRs1A+CEMW18gJpqcACgy4gyycMSKSKzZABVkisjlXVCeWiP79YphZCN9FjoLWf/0jCgglPcZNTETgzYyIMQzkxuAzEpPQGbjYZotCHI6BwKsORMKIiJZ5xoiCIaBsBlowYY6zRWWR0KRL1aCqT0wFzTEIKjPoqJFRkTSDAF1Be2uHSVgsypcp1mvsSLDVpmpbbaHVjQINcdBTjDxjVw5AIvE2B4hNEhtlEBjRwAs+CvAgc4QjMdUpVigGjw8qSUavetdhFtDUwDiBgA86GJAfRoYIAMvsDrGzejokWH5KBQskBgBKBiO4a4aSAAZThSYDB+R5ZVAB991OJfA1XYRhlcCgKCIxrcnEGTdawhYwwDS2htHQU0c+IHbsRCg4XZSEZa1k46WYcClW1EkKEA/zZqxQtGB2ilIHImGOCCKAAr6BgGNHuCgx8G6PbGpNem9hsOMnsaDSm0YAhaz7qMALaGmImAAx+S6caRGyjdgG3DZcU17gm6m2iAFWT9tqGf5R0giFxhODxzRmmIO7m7qb1GvAwyCKDzGTRHPUgqUu78hiPW5kK7uE9PvXb5dCm9czROqCZpLi5VeYZybCfeudx1/7zaK2YwncLin3fLmxWO7/yFtRMP3nnot5dogBRk7/wAtqEZAIAngteFe/Uf+kCBFASIGwoAeHCImTCy2fcbD9DQgusBiKDUDNK3PgKuwxKoIIIJUPCvs0XgIQegwgpkMABfUGsbYvDcCb4QQP9hFJB4MBhADxoiCWqAgwMvQIICFHCCE2DBhSwUwAB4oCeHjCJlbUBBLkBgQQxqZgXaEqAHazeAbzhjHSkIR0FoUBENtCAkXtFAFKN4g74o4BoOqYNmcJiLXCSvS9sw0NhyNQPtCTFzGkAVKwYQh5rYLSQ3oEBf5CjHFjRkUmggQjO42IYqyAp8aMjW5a5oRs31wQktuEFpxsABaAmAARc4yxz70oICgAAABsBkF5h3o2bwgYteDNIfxUgpUBKSZHEIxxZupCfvVeQQ1ChICcYQBEkGQQXCAUMdVLmDiXDRBcbolB6wN8ozldKU/GLBOgZnBvoNQBLooAYYhla3OQb/AVocySXcupEKRnCxZ4wSQgGyoAYfamsAMjjm4aIyAaCJIIkbiAQY6NCQbhhgkoARDjWisgHNCGAdIPhkp6KCDUUoonxlOJMPWFCBD6TTcFGRxhI8V5BtKGIXWWOIMg7wgBcUAJ/CicoBNNNHPAS0UZ4JQNM8OoACBMAAIbDFFRXgULbNwhs+u9QA2rMOO6TjIQYwjgJuog5qREMdexjAGhhgAKdBIQDk62KjfKEshnjAKf6k6fXGsY4GGOgDgPlmS9Y1gCL0IVVOAMIFjLAOJBgzPoxYa92cwoCssi1qXvDBjuQQn3PQZB3gIEEWwtolAQQABa94hU8kUokC/MAus3VF2rNqsQ5VbOAFBuugfB4gh1dMQgid0gUP5AgYGJzMRyAcQA364lbINgoLA/DRCex0omToK1aRIIIcYRASH7jABT7wgRPn2KzWIi0d6WiOB1mwhwKYBSSSlOSqijvdWNGwGAz4H3TnGIAHUNe7jRLEAKx2Bq14jwYuoMEO/CfDguDgu+9lVCtWUAaJNEIKAjADOeC73y5FgwMcME4BBFwADlghufxFcIIVvGAGN9jBCw4IADs=\"><br>    <br>数一数，有（    ）名小朋友在玩球。其中男孩有(    )人，女孩有(    )人。",
                                    "score": "1",
                                    "selectitems": [
                                        [
                                            {
                                                "itemname": "A",
                                                "content": "7   5   2",
                                                "issure": false
                                            },
                                            {
                                                "itemname": "B",
                                                "content": "7   4   3",
                                                "issure": false
                                            },
                                            {
                                                "itemname": "C",
                                                "content": "7   3   4",
                                                "issure": false
                                            },
                                            {
                                                "itemname": "D",
                                                "content": "6   5   1",
                                                "issure": false
                                            }
                                        ]
                                    ],
                                    "answer": "A",
                                    "diff": "1",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "118840",
                                                "name": "10以内数的认识"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96868",
                                                "name": "1.数一数"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                }
                            ],
                            "score": 1,
                            "answer": "",
                            "diff": 0,
                            "analysis": "",
                            "extend": {

                            }
                        }
                    ]
                },
                {
                    "title": "四、操作题",
                    "index": 0,
                    "questions": [
                        {
                            "id": "1152574",
                            "innerid": "",
                            "index": 8,
                            "typeid": "9dadf5cf7700438681516a1e1f8f3082",
                            "typename": "操作题",
                            "content": "",
                            "subquestions": [
                                {
                                    "id": "1152574",
                                    "innerid": "",
                                    "index": 14,
                                    "typeid": "9dadf5cf7700438681516a1e1f8f3082",
                                    "typename": "操作题",
                                    "isobjective": false,
                                    "content": "我会数，我会连。<br><img style=\"vertical-align:middle\" align=\"absmiddle\" src=\"data:image/gif;base64,R0lGODdh+ABuAXcAACH+GlNvZnR3YXJlOiBNaWNyb3NvZnQgT2ZmaWNlACwAAAAA+ABuAYf///8AAAD39/cACAiMlIxCSkpja2u1tb2tra1CQkLv5ubW3t6EhIzW1tZSUlq9vcUQCAjm5t4ZGRBzc3tSSkohIRljWlqEe3vv9/+ljJQpISkZISmlpZxrc2s6MTq9xc5zhHutUuZCUuatjEKtGeZCGeYQUuZ7jEIQGeatUrVCUrWtjBCtGbVCGbUQUrV7jBAQGbWtUhDmEOatGRB7UhB7GRDm9++tjHPm1jrmWjrmQrXmlLXm1hDmWhDma7Xm1mPmWmOU5qW1ta3Oxc4hMTFae5ycvd4xMTFa7+YZpeYZ7+bmlITmGYQZpWMZ72MQGSGcpa2MnJTe3rWtUkIZUkLmlObmQuatGUJ7UkJ7GULma+ZKEBkxMTpSY1re5u/m1oTmWoS15qXW5t5Ke2NCUkq15t5K72NCGYwQGYw6QjoIGRAQCDGltbWcpZytvRB7vRDmva17EGsZhBAZzhAZOhBKMRkZWhBrUuZrGeZrUrVrGbXWELWUnN5rhN5rzqUphKUpzqWUe95KhN5KzqUIhKUIzqXO1tZKWhCt7xB77xCtEGtKhBBKzhAQUmutvTF7vTGtvXN7vXNKEEKtvVJ7vVLvxe9rpaXmpTrmKTrmpRDmKRB7EIwZhDEZzjFrzuYphOYpzubmpWPmKWMZhHMZznN7MWsZpRAZ7xBKpaXmhDrmCDrmhBDmCBBKzuYIhOYIzubmhGPmCGMZhFIZzlJSUnu1nN5rpd5r76UppaUp76W1e95Kpd5K76UIpaUI76VKUjHWxeaMUuaMGeaMUrWMGbX3ELW1WmuMWmut73NKpXOt7zFjWnt77zF773OtEIxKhDFKzjEQUoyU5u9KznNCKWsQKWutMWtKpRBK7xAxUmut71JKpVJ771KU5s5KzlJCCGsQCGt7MYwZpTEZ7zG1WoyMWozm91Lm9xnm94yUtZytMYxKpTFK7zExUozmvc6UhLW1jK3m973v5veElHNjWmuMlJzW3uZSWkohCAjv3tYZCAD/9/9SQkL39+a1ra0ACAAI/wDZZGgTZWBBggYTIlx4sKFChwwfSowY8aACABgzatzIsaPHjyBDihzZcQFFiCgnpjypsiXLNkMctIEHBUFNmwhw6rzJk2abnDyBCt0J1OfQoESJHvFCsqnTp1ChHnBwtGpSpFitZr2qVSgUBhYciIma0cZPsgsIdLkIsl/HAxMmWFhAtq7duyIPXMDL124DAw7YAnC77+K+jP32LTjAoDEBAwkCBEiDsfCCi4kBFB7CAETcDg4qSJbAFICCIQvcElbwAHSC10cCSNBHZG7f27ifHpiXu7fIIaAFA2jzJAAZuhjZPJFQIU2CLg4cQBFzhAEADAQkB4iS8QAR2Q4sTP8AweCAFygVLjJQIzkwRigS/nExwADKAfMAyBiw7bu/fwCM/ScgRn+5h9EEATzBxhFkYHSAPlFg8JYEHwwnWWMBDAEAGwEwYENH1BUAwAeSpbEAERMAsEAAXXjE4QH8DSjjXXrN6N9f9zBlAwMVxDaBFwEcAMARKYIoQWAGBCDaEwAQAQIADjTokQEVeIGAGhUMEIAXUaTHo4QcKSABAQDEaOOZTtWIZm4FXnRAAGow0EFqFSAAgATIcbQiat85wMAQ/XShAQAJ2OkRBZRF8cQADmj45gJdHOGRDU9AUWaea2YK0m6a3jYEYGwpgCBb0WGggYYcxZShg2qQCWAAhlD/1ZECSRqQkQH/lKZBBzx2NERsDVza6bBvWUfsXW1qpAaqCPzDwJYciSEBEai6VUEHGTFYQYUcdTCApRkhEABb61XQ4kY2pFElRl3kc+y7AO4FL1k4lnbduGA68M8EGLilERv6gIuRqYYCYEgFCfir0QdcFODvYfDZy8AEhnDERgVFAkAPpvNmqmbHTxUYQUbSgjnwRocxIEHGGCmwLUgfDsEixwlI+pFbD9ajkQMjg6wpp3cllhhbqsn4qYHDPfEhRgpfN8QEkRmrkRfLeoTB0w4w11GUJm/0QWjGbWSmz2cGyBcbDGighgRccIHAYQImi1Ebg76Vhj5kTFCwRoYE/0AXmHB7IVoC5AmXrZQcORBABzV1LSzZa34MFWEPdFEnBg9woe9kC+zTNJsG5JgRcQooMJZGQgTARkaOqwirAkIujVEFiHtExhEYCDEEBnADMIHNHY0NuYySRwUfuBhQCKUDkaHqWz9yjzguGQlspMAT2H50/QN9Y4oBCBK0rlE9EiiQhgMbHYCnR+0OjybQUSlWgSH7SGiDkEMoDSVpNwLWM0YSQMAD/iGk62BEXMj5HEYSQIZ+pGEZTMuIBI5gOI0ooEPN+kDTbqeA3mVkY+4rm9QmVw82nOYDQ2CLDQRzhDYMxiOE6ccCLhNBkUQPAFBQ3TIqAAXOVMwGDkhDBf8NaAgJLMMQeEOAA4pEIiiI7zBR6BAZjNgBIQLAC08IjON4FkIbFe8pDuhSGshAhjR0wHETQF9IDpCGI3ChUE2p10YmoI82gEAyR6iYaY5ABCgM0WC0mwB7JMAG3lkoDW1QgPiiMIAEpOFCYBqCBJ4wD+c9rosD+qJTEvAEPR7QVlNLD0iG8LIRrW8kN8RIFNhTogkgRwHrUUMaDKAh2akoa9pJQCKTYwAJKGkCF+naAxyggX8E4B8OQI4XGBCbChirfZjMJG/qUoAKCKke2SslRhbAJO2R4QFDiJQaNPDHVAHmdHoyxAcIwEfBXA09lPGIFzDAhg5sx2vLuOdHbPD/AQZu5AFp+MdFkhnNTI4QKgog3yPHlZ8CYuQDFPzIAbowBCJ8oIPi80gqO/IA/i0sAKDsiMI0Z71puSsk86hbdzqEEeENy5JoEoK87EIikM5OLEwDzT6J0IYjwJQkG9WTBITkL1j6bSRfimAOuSOSji5gaTZA0AMwYgCOrUlM2jlo2WZql8tdpw0MIAJbiDBVjyxAAlBIQDlvJrKRVICpQ0BAZMiw1nAxFANtWMY/jmDVkkigYguA2uLyddJOeYYDCGiDAr04Tbu4zHE2QwDwNuIWUjJACPQyAF2RqoE2QKE4AWzKiqLggNhIoAN1zcg+slgz5qwuI13o65kq8FOP/2kVKqbqB3Y+sI82VM9gA3Ch+BaggQLI1oagGsmb8HjRjNpOSc5M7RyP8BpPZsSlNnrWP5xJLE0+RQFqKIAuFdCl0uwDPkjTCCkRSS96iG4kH7ioLZuyD6aAyblQwe6MFoCACfgyve/jal0cUADQpGECXOjcCxeQACJYlbhLzCyAM4VfkTigsMNSQGQcGrnGOvYJyxCChPSnEQz0kn5Tk4AZyXI0dNZFum2xC0HfhQF9sOx9t4UKGwwA1j2+RzgGEOtGLPeEBRjSKTfslwFrqBF/6fYAHWCKW5SskfkObDF5s+DJNiIhRSogsMw57poO3CmZ8iUBQ4gCdxpjGo+6Rf8BGkiRyeoRmtoid8Iv3IgXhJATBkDnCMYMUkYUwBThKAABE2OAukTjyyMcxgZ7ljIAPrQA0pKBCxIY5JLEjKYKuPBnAn4KFLG1jA5IkikTWMtGhkDAPA9BA2R+CvT8x7r8BWAZeQrsMZ3DwAkwAAEcoosCOsAepNXjCf84H/V4/ADzoc8GF2CloXoLgSNNbAL1GIIXhqCGBHDaP25pAzAqO9kO28UGC1JAG3iYBux1YQAm5DIBfjswd0dFjhiRZABAcAQ8YQDOFSCA+PxbugLIBgrUlRAdGTBEDpEJQQGAgn871wYJtKF1NoCMfgcEXhs/5tv/MZus/41gBBQgDVD/+A59CFCPsJJhdxqpAKacyYUlxzG5GFAfe9LzhIfjziNLXUABBqAlKKzoADZwlkeu5wAMdEFJAUgABoiAAAw8IccV98KFMzxDGIc81CS5GH2I0Ji1vXbQE+WwA8qKEQd0oOZQaQA9uFjEDlUHANABgAE6sFgAdKACvhsAcxhAFwlY56izCkAbvBCZCoBAQ1BL3t400oaaz7ig/vGuR+Am2Q8cgEhE6MIpZ6WRLuwt1RWg8s0NBMt/cAs9JlYjRw5QARFd0b+l6YJYoZWqKepROcbiAJ7QGqYJVAB9VcV8yD0sEkpXaQiIrNPXmuIAtfMxKi3WSBqM5TIDHOFcG2FD/3jzBKQCvokMDOUIF45wdkLJflqr8loAJvChjSufRjkGCX0UwP4KsGEBd0cSL6cR1dF0cZdcGcFeGPEsMscR+xAarOM6gmF84Ed58FYZ1+F/3UEflLUAU4Qc9nd/dWFmTdEPMtMBVMcFUCMagDcSbEBvG0JGdhYSN8QFn9YyEgI3vKMARKABbJdvPwcSGMAAA8AAHqQA/6AhCqRbprFDDhWCIhgVmucRH6ABzgQaZHAAUFBGUldXBYBZk6Z3VAJylNVWA6M6MGQSkTJ6GcFOHBFJbZAGvqQzG7EAaiAcVBZYgPZXO4NhUdgX8EMS+fMEXsAg4dMGHsCDajVKUjc6Ff9QD0XSdx+Bb/dSQI6zDIJnAPbhQRhxAUTgER3FKG1wAAr0KDaXb/9Adh/gOMn3h7ghciGRO9JBAHayJP0ADBLwcmRgTQpgZV6ASB8iKqDndRsRPTagD6vzOf1wfOWEARNAGUMAUySSf6/iBQ0weYaQhB6xda54G1OIGNcjBGSQNT/RQhhhCLEBiURwfInUL+TVBgMAAdT1fQxwHHUhd5uVgAwgOBwDH2J2VmIAAk+gSDvzBM51QT/hN7YUJXmmEVDYjSTxjRrBBWqgWX1kQAtQD0RABGkQBZyxHAmWEaFRDw8AbIZgOTOISgi4gOnBXTloGkTQdH3nMhMgLdahMKz/doMdsYsLgDGaEUmEtDUuBpF2EYgh8WX7EFeHkZQVsAxD8AHfQQQHYAjCUYjL0G8OQAESUA/E6CuhYy9XZHgcggALwAaf9iYX9xHiAmUBQABwURptoI3iQ5McwmMJ8FoO8AQ/9ZBEuUbUGIEc4RbP0gEdJRmfJgZQ0AZBlADG4gULoG2ceG8rOTe3BgL/IAGdlRH+5UpMppnOkgDskQBLgwEJ4Eyp0RGG8AT88CwDQH8tQwY8hSl82ZcfQYIkQWVgUnHrmFXQkTfAhilNU2F39j/dQQQSIAEDQAZHlBEXM0HSQZAagQDFMRrJ5C8pN0nV2TWQMp25iCq9VQEQUAEG/3ARs0mbbwF2omYDQ3gEbvcAkogbs4ZnNjAEiSlXfDgw9Kk47QcmNvCYQ7AgLdgy/JWLDmgaXvBlCaBGU6ZrQgJN5kkWRnl/lPgRGMBDmqERHaAPHGZWAcAtzKl4kZk+bJgfR/AhIPSgEPqXXRRUHFEAsocR1KGipqEGezNsdYNfdqghOcgGhtd2foiiTSGRISR3OCUSzKQROmcn74kRGsB9HnhaIyEmtZQB/nUEBVSeQOog6FlQLJo+MncA4BMAeDYlhfJZCaJgIoEBYwQaAUAEEARbZJilSMp893c0MPYdstEBqyicKyUb3kaM6HEERwAuCnOichqkMuo+BWIBHf9gAI76qJD6qEdwfA5Qao0aqZgaqa/hqJeaqZnaqPSwd5faqB3QARrwo4cKEkJwBKTqqa76qrAaq7K6d6LqdmJgCEPQALq6q7y6q49pCIbQq8I6rLo6BLhKrMi6q7lKrIbAp6nKNMXqDsk6rdRardbaq0MgrQ1gOE6mGYQhUuDakB+xlJ7jrRe6pM96G+W6rjFkrnnWre9aQ93KruZKr/aKrunaH0wYVwfgrPn6ryAjIdBHUfgKsAbbMW2geAe7sF0EJm9yYwwbsR3jLx4QAPnQAMhhZRK7sZoiMxLQBQkgAfzQlRxbsr2RsMZSlya7spnyLGxXARUQoiw7s76ROmD/CCXpR7M62x8rkgEiGaA7G7S54QBCBgDcJbRIexsK0AUGwBgGULBJG7Ui8WUkK7VWe7VYm7Vau7Vc27Ve+7VgG7YUumX3RbZiqz0bS2gcwADzwLYMcAGd0Rlt62vzQLe+5mueEbfjwba+Frfkgbd4OzF/W7d+C7cTQLiAq7ccMIoTmKCOyw9kwA+vIbkJQLmWO7mvUbmZS7mai7mem7mgG7qiO7oM5G0bGxbRER0WAB0WEBau6wBz57pd4Lqv27qqe7urS7vhER5hARi1Gx2+O7u8u7u9S1simRq9qFuKFIz9ggHM+7ym4bzRC73LO72mcb0Xkb3Yu73a271QEqdZ/+qgUTgBzjOmBYWlD2qomfIhuiVDB9oyYlA6IQECbGe+0cRFEou/joWr0fifUxmN/jlfCxAaFfAEy6EG+vAE62ick9R+HEG+Ilm1HYO+5mkbX8a/CDAEbQATxgpOQsAxC9ABvqQdJFzC95An5lPCKkzCDvYRphbB3Si+CysWpMRKK1zCDuUyN3zD9BZFO7zCEdUR5Osv7/WH6ruwFtAAePrDJHwEp7MiTKzCqAUAzxLFJZyPG/HCbSfBMyK9IHF5DOsnJWzDO7yID2DFKmwdy4XG2vGimuk8WNwfCuB5UZE7KggSFEybFiAubKwdSwEAXNDHWQUAHCDIkqFqGkG/MP8MEvuAaBo7tehXgU2RsHOCx+ALpLEFcYIsRGIgGoL8D6tTxYJ8Y1oMAEX8hr4jAU8bFQagl2ShnCKRx31pG7FhyPzCTYY8VClsy7JTyubbD/5IFi6jk01hAxEgASnJLqgKsFu3y4LcAfuwxn2sBgsgOIYcAAUzxG1HnA/cIDIrEk8wVVA7aBLwgx5xxAcbW9ukJbZMxdeMJ2d1zQXky2vVARBbzJ5GFhjgdha2zP8aIzl0zQwQKNe8FHwsyNTiO85zyhxxpP66EcvgAXXBAUTwyNd1yQNi0f1hJgl7zVVXy4JMATaQT4ZMQYS5yGZFGgVrOJIUTC+ketZzvVezKoT/NkMcoc6d8mWNQVRror+aoTjXbHSeLMhdEAELhdC+PJQckZlOIQbRaAjnh2hxwZkeYQhpQAR8xGjreJzILDYY/Yq0lQ+z9M3+MTb8d80dUlOGjGtDLRnLsRyTdATOUcCefAT1W0EnhAD91ELXNgEcQKFhekzMYYUwmyXEHJ1Rx7ae5Vk2EUUbis4ywr49t03Y3NMYJiHxbMj/sACiPBriBbMacAQG0AVxMQ8e8A/3AACFKaYakr3/hi4JS1EonRFTBLMMMtqlzQUx+xEIwgaocaAHigHVTCQt02R4ldhp9KgO4H2LIxyyTCOVPTsJQNa+gdMbUXe55Kj6Yc8TwCsM/wBWj6QhopyWp7gRBVAkHBJ/IfErJ73NHJEAUWYIwNAAQwBOP7FDQ9QPGgZdT1DAk1QByKkkfqQR9WUAEKAdmDYAxQE2FaAGXOChMnwm4lIw14cm2BXQaCgSCSuSAVBuH+EAZ6c41vURZ0XPTaYc2jHCcOLJE1RITHgRUKABXPB0WdhGHAIFPOpr06Kj8mN4BqAGfmR4CxAw3MYAANVqlxQ585cRITvOfDE2CvMsMAgSDNBNpqEB5ROYjmMBRogRNlAzZHkAbPAABzAE91EPYOVrbVq//yN0dRIa/LUsrzGEFFJxSBNFEWIAGtAvR2An0YFDEmAPC6AuwtaDC2AIEP8AQWcsJGlAGeuxOwagDxXCjZnSD/02BDbQUXB3JpTOEUBUAVO1lG7BvqZhA/0QBfqQhxXABYI71RNwARNgAJ/RHBYUBZMKs2+9joUNsw5wD3AcTPwnVgfgyt6HASSSQudj7LTDFG+iM+KiId3zKhpSRtfRAY4WBfxjfGMBAi0ofhpychdBPXr31bcxwESwmjaFJtY9K0PXHHy0jhqwjv3t30cFJl4QhwkAGGPkAKTtaxv8fx2BARIiIX3X3lCCGdRTOk6CEUfAHf1QAC3CbSkCgMBEBKDEnm1Hb2nQItfzWk3apAyfPQ+ULdYhSRUiMzFB7vAJABeAeGcC2avWAcv/EAX0sdhscB8379uZAsEYITodxRQ8Shc5+lBHVchC8gFxIgEjswBITnZ2pXB77s5HBV6oYqGqlHr5EU8t9Nx9cVZb+h9cTyy+HAHkZXtQc0BA26Nqaiv9EBnxhAAS0DIWlxFHBwAyQxc5RM0AIC2lEZT5Fj5UHD42cARC4NMdS9yZ0ukiqM0HrwBQAEoRhkNYzy5q5F9U1eFQBPjgxVQYEQBlNdn2pPbx91Z0LwFjsSKXkSFhXxecUcprsu4iSM9W8ltH8CRJozDdfUBMgkV5eRE8OjDEJ0GvlQApci3rVjpPkJaIb/f8g/oT0CARfibcnCmr3yk8nx+mc1Z0oZhu/4EAAyAYCHAuH5AeCAB4zPNvT1BA/Nwyq5I8BKAywGAq0y2QF2HtcMOjbpL0dAHGSKzy8KLIAAEAgAMFCgAUILPP0BODCxgKBNDBgUAOT4ZIYANggYQJALo4wBCxAEQ2Abz0GxIgjZoDAh9IIHJAHwMAbCQsEGhg4sAAAQzkxAlR6FCiRY0eRZpU6VKiDoIyhRpVatEJQyA6EONFYwUyCo4Y2AegQkuBT9oIdPDvSQeDAIY8OcLAJ4APAR7k7CKwQ4ABCIR6ISOhJwEFcBcM+cfAi1wJUCBaeDpV8mTKTCFXxpxZr1W0CgyFXMDlSBc1fiekwYChjQQFGNjok1BvqP8YEBV6TkBQQQODvQkmkBngtOiHAj0rDAggQbAENQGEX82nWfp0qc+T9hOIfR927AC0h+xuFEN4gdsBjJdctbuDCE8xQDnC92OAIw4kDCCTYECaD0YVFK+ACyIqICIBMhxwoIIEkHoggC6gQOAAKKA44AMoJKBJKOuo47DDoSxogKmwztsnJABGxKCg1s4TagEG0jhiNAYIYGCCLpZJ4IgEMiJvqQ44GygCrYRSIA0NHDAgyQkMmGDJAICkSg0GEICijQnbYICBryAyUaiSJHhCOTEFCyDDxyLzME3qNjwKgwUMSCCBAOE8gggNjgATrpa6u6gnP/8ENICMsmOqKoj/ulqgRxyznCdLBhzQ8kmkoAjUz3+OOOuofia0DVAD2GjrTDVHpe4ypLBboNNKA5VgSADSWHXVCu6KCgRaB1LAVYhAUI5VMurpsqh+vHgr0A6WCis+QMkaij1Sn83MgRCT2ieBWFc9IihVr/3Toqh+vEoBMYxqI9CHlrKBzD/9YmrbnqAUFVp5JTM1KWu5DbQCnLrAN98FgkUKXLSENKqeQNOA6oBK0WzzCUCfMMrZeSeGik2jFO4X0Aq88MLdfvUNr0ehDO1s3KIcCPQnpuoKNFSl3K3AhqLqpbjmo0BkKoqMAeViWHV3zhbgomy9KgKDhCYj0I6YSilQho9S9s9B/4fqIjqbrz55WqX2MWDnPxPAoEGve2q1vKMEBuAeL0wmqmtAyRBIZk0F8jgvpuQClAKR6Xkaa5stgBcpDO71cwCPlQaA0rF9UkBkodAmiO2hMP5TgsCPWibQAVxGinI/y262b78p7kL0oVBFbnGaUF586aPU66xvBX6+zbulxAbUMaGJwoD2AGT70PTR5cU5Ks+9RmD2xcvcfbNwdR0K7z+P4PyodFNWqrukAXU93uGxtlipchf/54CSyM9UZJIHyspxAI7vqT+mCPdzQfeHMthTomj+vubipXLb2P7xAPhlDHhEgZzRjoK7PzFLKfzSGFR0BqhjUc1q/bOZxKSigP/tje0mE6yUYJrDKqOsL3LNM0SlMuWjQHEBKobIz0eQNDWI8A2DV+uC1qSCgaj1ZAASqMATFJQALoipTgE4C+sCQAQEPGAIC4CiFyJAwA8cxgBH2B3RBla97HiBOQGoAJhmBRUvICBCHxjCEKAXrQvecGL/m0qfwDiE1gCsjgBQgBpwogAiJIeLCOze44CktqQoYAFrxGDp3FizLlwOKmxojmOU4gUNdGcj50pKk4ySwD8u0ij8o5jcOvkswGFGLuwKj4nAAwAvQAwiCDCLFwyxABVBEYr9KIhESjiE9USgeZ6cmfDktYAVkk5+lYkCR6LAACiwIQptEIKj2GClJ3X/aQFHsA0E1MAcCUCgAhU4whPCtBMEAokgwKxYBPy2DxdJ4AhXs4AhKDOifRwAT2KCgBDJcA8HaCCMaYgMdtzkmVyt6DxDsEFb1DfIBSRUAQ59aEFS1BqJqsiiF72oQxO6UYx2VEUpGk9CJzpRAICSYgaJ0dUc0IY0GiKNL4VpTGU6BJceBhiGwGkDgNEAngLjMIeJqUtpOlSgDhWnRm3pEBpggVtNIAH8IEMBKECGqFIAIQYqAFQLYCCqdtWrX0WIVclgVa12FSFnjWpaC+CAOPEjAVLN6lixGqc2Yi0BHrgaBwzQgQ7sla9/BWxgAZukvRaWr4UtrAX6mqTBHnax/4R17GIl29e/Sg6dlzVKjjC7Wc52Vihx8mxoRbtIzY7WtKe9WmlRu1rWjkq1rYVtbDMDWtnW1rZSqdNtdbvbohDTAwkggDB5O1zY3o+4x0VucpW7XOY217nPhW50pTtd6lbXutfFbna1u13udte73wVveC8rN1UKJFjmYYrjyOO++4VMvKhdAIIs8BELyBdB98VvfvXrAHo4QIb31YkD5itgAte3vjqpb4GRRGAE+zfBOnwvMFFyD6XytAGGaMBQHyCFDziRphYGcYhdGmKeDuEBs7TlAhqgYhWvuMUshuIQDtBEFq+4AUcwboT7N4QKEsp2AnULAUBAgBBxhykRmP8AnrrAAYVeBwANmECnKjCBA4RnQTrGLI9PhQAIkskB8nTyAe5FBNZhaJQCUQDeMASC5ARgAm15J5Yvq2WjxLcnR3iAF2LUBQkQQCkG+Mc/fIKdAkgAAWQe5QGewGeA4mUBXegKAK4sZ2A+oMfRk0AHKpCGthzgHwtAgJRs5+NhfZMBEogCRLwQgOSlQWUQ6U4/oqAPKFyxRRKQ514BEGdKe3IIgRRIlB/QBdQIZUvlupyeyeCQLoxIIMsgAl2e1CMF1AMC07zJUCbggBJVYAiTjq3comtpodjgAAYgggKg8AQ0CWEAXuDjqwWCAAfoY0FyIooQAoCTBPR4Hx+AYBv/vHDtE4VnCGowSBq6AO7ThUQB2xlPxPshcYpP3OIVx7hBWjNxjUe84xzHo8dD3o+w5Ji4dAYAApSFAIcUEyIV8ItN5PZtHy6gJLcSSgXOQqk91vuKWJzASHjXmH20AS7N0tFv45SANMRJ6U93etTvKnWoT33pV8d61rWu9SNIErpaVkCCal0BDCDIKFzoyAIkhYB/OODbx6rAAYdigGVoxCSGSEMFDFGYKBxAAjiHiA2OkGqF8VogDE8RIjGjABmfeSr+MBPWQA4AcUMLJT+qgAG0gqkP6KNvHUgDySvgzH/oTg0PWI3iCeAA7EgAGKMJSUqAASeo/UQBhhsKwiBi/89/qGECv4RKW6CghgERAfhTQYCfsaYAMVfA7TZ7QGCAJ4YBLCABdqOKBljJEVwLRO0f4MKlhdKPNiAsmaCHyIVW48ChfOU/+RmKnAzwosbAWycmR4oBnpAjbwGgHuLHDMjzmyFwgA84gDByvA5JCXLqHZRBAGcbig5IgAUgs+uDiI0QDNmAQIgwAC7ogmsrDRZRAAhigD/CkyeYCBf6rACAAiGYP8rDozQAPABatjaAG84Am+lIPr8BAYgoF8UblQZhF4EYgvgAqKPpjhRJgx8ygDzKgBY5NQmYvwM4ifHwggkQjCegQrsYtffhs/1jgDZoAwRgAyiwlifIEN2DiP8EYAAN0DQGiC+BYAMAjAoF8CcJGIlMwY3pEMDvWQ30mpeUOAtxw4AD2B4ZmQAQSIAnGAADOICwIAIGABjX6AJl0Q2HqYAOeAA4MwChUQA2cBsNEKIjWIYHCA+8+iwMSIMJWIYehAhDkDfJkCGy2xX2q4wdlDzvqwBggL4AyMEuFAi/GwAK2Ks2YD8sdCDt2Ae2c4ADoCmGKRcDgBfXwJMZFAo1FAgPMLc0gIkkCTa5kwwMqAcHIIMKkMSSskXK6EOs2QcsVIkE5JAh4EZM+ZeQOoAoIwJHMq+uOYIJCEMo4I3jMIDKI4qisw0iKACEgBHnALOjQMU1DI+w072Vmg7/NtiJRtJB5RudBaCHMqmZB5iABYiyz+kJIkg1JxuCKIiazAMVpQgJDBgCBlg4B5iAD0hAbAQADwiWa0ILr8uMRxMIjJSOdRwerqgZlGOnA6iQtoDADewt/4Ci4+MdPDIEBhACNGG4BKi8Nog2j3C5yoAHuynAjMQgA7CAj6TDoQibJEuDKMAJkys5L7APsnkzqfQOkQSURjIRw5M0l6kRgaCHdJyMNjiWfZgHgqwMoqwZ8jgCDjhKYBsKKLiHnigivqCAhkSKsOsJNWgDLggANRiANsgxBZgAP3EAL7AWa8mQrAwVHuIMB/DJeSqMo2lGYKQMXLSZanGAfMCADEhL/1JBOaK4Jj+hCQQokyPQAH2UQzABoz3yPbkAFvdZgLxLmqXZCAZ4CcfgyzQAEgWIGYEgAIx4OMxgA15bjdhUx8g7ShBYBpaymcsziiIEJzeTmxzBAD6joehxswJQAyApzTRjNaMQAyLoOgwRCgNQAwB4gPLJyqcARaFYDQawrKmQSQjNNLtMCtx8ruDMjoUoQI4QioNriSMQuqEAUARANqHAgH84CwPQAKEZgszrGOxDM5YAgAkgApxMgGPqgGJiJwOQgJaAx7ZRTy8ogGzBv6NAAPVsrl+DNbeohwroAgUIP6JYKwAwBAk4Jo14EUEZggHQHaHQkhRpDEs6NfogTf8uEBpyxKPkiD9m0byCvBDlFJwEuBynwlCj0FDnIrdgvBfqITahMU6tcADlW4Bl+AfVBAAy8zGBSCGcMLsblQA2FJQF0IfLWY2Q0I/cY5YNCY/oy9OhWLbyCJYC+MqoUMwmraC96IKFOICNADwTMbSUe4J+uKZ8VDtQ87yCBAAkAoA2eCcQeAIEUI0FWQYaFYoUCpHMiT8h4ECcCAsE0JUuEEw0s9b2CwoOChVkvE2N3NBjIQMNaIkDBAD4KyEo8JlUeTMAGNNIPAoiaINlJIIJ0Acw64DSsRyjWDWD4Jfcc9acIAsvSLe/GKM/soEh6I9gIQPOwIASFYgoPQnJSNX/5UKJJtEAk8kNL6rWF9S/poOILhgLSTGKuFgAf2JBiKiTKEsNtcSjT9MZCYi/qWEAlUmVYNmUILVWDDAPBhgQByGPCTjJIrHSLnCTBFCDsWCKPW2uYZOAf02cAOAChIOaLjAAfTAYVzkAWAkAQyAP9AAAw0FBBAAdt0AZQ7MBgTIySlGOzhwKDxjCa+qOLhjCC1yLtpAIMsAmeVIAA5C7AyAnLsDMDsicnogC5htWk1tS6TIEa9EVmksAlps47wgJmwAjNug8rxWIKIAV57MSgxgCeuOLeXiPsQ1GCIqLKICHNpiP4JCnrPRJWnwf6hmKhOoAuACOCWADCoCCfdA4/7gJvARoi5nlEh2xDzMhQKlUWuZ6gPhgGEOYy+TggiM1jt3VCDXATIj4gCQLlMftNF/lHAX4AK39hwEYgARog4ZUwTWcW3qDCBspiOiJArlMjuIQOLshA5+EAqJFC5DADgRIgGRyxpM8gi01ioldriGoxCm1zRulD39kALcMFnrAiEbFUpSBQ1oqCn4xAMt6Ewkgg19iuCOYWx4aQhyNjGvSCgM4jmVwgB4cEUgZvydw1olLA5DAo23SQhsICgcwxQz11ua6PAQYAA1oAygypAfgWTczihFRgA74oQ4ASImwjUZLCiiQsjQI1wAgg7k1G5SNv9ikQFexCQMwBGA4tP9XTYDSUzMoCArzHYpr6hI2MEcMWAZsOgKuFQgZVIrEja4hsL0L+ZNt6gAgHIp9mKb7epDq+aVPNCMqnJ/4+0q9IpIoFA4kaQsokuMK2tEu5CMECA8XcVbUk4uleYLrLYrkXa4+Na+Q8yy+9ABw9E43c58PyFdtY5cjgBfWyc9RQ80MIQJTJgoDVi4/pg6nfJasdDkMIIJ6IEWZUaVhEeGiSAPHEIMA4ByVfABIMQjyyFI1kI1UcTxUVq4HiEWi6A4byAcMxlwn0wgaCQoMNQgvaAMPgEOX4Us2JAoE6Ig+Mt8DgMkoqAAh2J00IAuTIIoBjjI1SIM2QKN6CIw2KFT/t6iACQ1mJmWuITjLQmoDo1WJwo0KNqCfBNgTl7Sz6XnEw4NkohADBWFBcOImMgBmjZAAh7NmFhEILwqAf1gGI/khNUjkjpEnhxAmcU6uYRMcBnAY5ygOMAlTYZFDZeHM0uTG00SKhOqgN6vORUOp+GPSzNHauGADDD4KIViG7niCH34LQAMjMzQot5i0fswxPn4ulCCn0zFSCYCVjsCAO6kHCSCI+7G2AfG2PE4AQwijiJ1dVtKAfgvQ86gAwpBSSYu/k4S1sz0AJvoAuX4dsuiHUIu09jsWDhqKKJgaOYaCUSJq5HqAe7gYvz41SUIJNWCDg0PWE8EjREWAAtgY/+y1iwXwvdaW28bOXDWAt7i7Z4sWCJnshw/AInuRHAVYhgqA7ZveN9TUlQ7gRYggQHg1ZgAQ5uT6tqLwO0f8bQ3RPpuAkoYAtJSEAOjxRptAExfRhwnwAlETin2AOVq95x+OvzDpSqNIKEyCCCF4gvwEDiEKFov2u4xAzNQ+rtUmEkMMgA5Q5ro+qH+wiq3iEiFQFgZIIfQUYoPQALuBSa1Nt4VbZQ4ciVWD2c9C7mDcXexATO0uNqIowspjvicViIElisu+HM12LgIkiSI6DmKq5fajiQOQWg6CWgUZiP8eCgiQpzYkuTZQgyMoiVfFWaJ4gAE4vACYbM2YTvNaAP+njYizMC496xLyQADfHQoH55C2MCg5xwDenBgIjwg3wwAm2Qc0NAoiyIvvK5IK+IDegUPhHgoN6Ai/A9CWyI3BsfALrOni4GoxV8MKZREvEh6HaBwAEIO6Cw8irmibSbMKiB42FOEhxYzwnoBh3XGEZY0SijMsT4Niy6MhIAC+FAoyoAmH6IB/kJ8uKIDZEUwFMGhm/axTnYoiMREQGOF6EPCimMBgxEk2gADAA/JncZM2+CYLNQi/E67MWG4szzY8shyaPAqjqwnnO5e6YANXj5gm7AINsG8AUOFlgBj3ou7FIJBK14wCSBR2/b3oGexVmjuyGALje/N8DA849xD/IM25V3M+mx6VIcBbBxC3RfwHM6f4KJs1M4w8t/k9krMdE+kCAtUASGrIEUwOgcOj8UuhNPgHlUtpzAiJPdQIIhCZd++AkDzlTBE8hrnsCdi7lHtxUkkQ7fZVtJCAJMWMB4gkFYUlKQSVkJAZQ+qjlAcAsxgKAkyONCDDB0DRNuiaWbUJgImv5oiLj9CJpT4nHT36qBDY4GWLRkUAVwNeouCjtrDBbe6SIhEiUONveYF4gaCUEg6A7AbOnrBoYuJoP9kmB5iaBOhEorCBB1iG+xAM4iVWNJvVHllulMGmNMiA4OoSnPQAZZcMEOix32hrO9QKNtidLAmJfViGQY7M/7yIgnpAgCfMIFMXiAwIAGaRC156lpSoxCqDwRbBpjJqCYCRCcXokSEQ1iH4pSgYANxdkYKAAgdQg53YneOmDi4AEqNjFwwgg98T26exASaKmys6aY3gtLAbw7hXEwn2weGHiHngwuN/EqMDCAcdoggZQsABFwkGFgBo6PAhgA9p/j1JY6BLAglq0gyB6BHAg4wBNCR4MqBClwMAMHxsmABiAgYtZ9IEMISMw30HjlTQUGECAAZEVLY8QKafQyFEEjg48uSAFyITFCAgUPMq1pYOKjhEEACBw2UBFGQt2/LBPzEAxAxhcIQIlwQEEHgpq+CAwDZtHpC1+wEKFAQfsv8egSnT7EyWUAK0YdkQw18bABZ06dtywZEJ+xz2Y1OQYQIoDREcRmz6owEJDhUEKH3viOTTiIdISGD7dgIyuHfz5k0Bt+7evQvYDi68t+qHcmV7RPpWAgPLSBseeTATacYBBiw/hNKhq1Xm4h0kd/kSgALo4stKjv244XQMSDdPn/6QpfyV+h235O8wv31X+QdATOtB9EECChhARBsL9LWAAUDVtIADFErQhheO2QBFBWqNVpqBWE2HWQBD9KXAEQgo6ECILbr44lXLuahABVFM9RwZBThAVIAfOWBAFGykIYEE9bRRQQIMgQcjVncJccABHq50AAIdMXklliEWGCL/SwsMkEYAaWjQxjJVluWlBAEcwQUbR0CRQV0QkZYlnXXaaWcCUbyIgQIYFGkIAiAghgFdFThQD4UzVXUno406KtuWL+4DBRl8snjaAQlsRgZ3D/kD4qOhijpqAiAocKoCXpzqRQSrtprqq6y6iqqqpy5FBhGo0jprqrqiGpNbH/iKahvhjXossndOwJQDZDTrQAH3OButs9VCK+2zzjJFBgVkcFsAP9s2a6211I6bbW7iepstBWAl+y688co7L7312nsvvvnquy+//fr7L8ABCzwwwQUbfDDCCSu8MMMNO/wwxBFLPDHFFVt8McYZa7wxxx17/DHIIYs8Msklm3wy/8ot9vNBQWR1mjLM4i2QQBsIONBFzDmHaAA98AVAlKMv29tXP44JrfNVR1jg0ABCiNoGAwRkEHXUUxNQNdVSZ2011ldr7TXXX3c9ttQERNFGPRlEkQEBaH+tJNI1TRCAaPBUcHSdR3CAQGAI+N33334HLjjgfAtuOOGHF7644vCQZgDkbUABz95+O+DPQwYctznnnd92BOie81RBBXHhliKyCiQQQLNxhnreQ0hJ19J0YjxwgBAL1AcRUhgMMY+zDkxgSI8AyE7AE/oEsLwEDhjCElIMAE0gWdNJ1k+fLqO3vfbdy8cnn9xzv0/RbUgwwABRnJqfZN3PvXx14fczJ/+yYlQQQAVWhprGZg3dBcWQjsCAIQzoPwhIg/KWp6Y2CO0DR1CgAiVwBDZ0yhBEkAARIBimfzggTgxwmkNgl5MPEEkCHXDdTBxYwiNM7yNsgIAGjuCBI6QBbhDBAEbWBoUjlYZ+o1qABoZgPgnYsFHnsQED7qdBDLawH4Y4AgY1SJ4KFLENAehAB/CXG7oxQCGcWYAEyIAZmiEgCk+YwBCIcASyfPAhhckJADgElwIkhAEFdEgbzsgAKHyAAf8A1UMm8AQE8KceFThA/3JCBgP45wHqAYAPRZWApUUkANt5nQL6sYwKcEgNNDzCANoAAuhYRgFL8YIDxiSEB7zlAWT/kEBHkPIANXTgAGd0SBcZkEUE9I4LAVjG6uA2NwncDygMcJdLHqIAP07vAD9xz0OicMjYIUACbPAIBtpwBCk5JAoS8EIicUiBjyxgkJAEpKMkYKxwSRIDCaAiA9SAzGVIIAqra4P/yMC61SGTAAE430jqgoEHQkANX3lMFyS4vGWMhnmj7IAhDOFMA/gxAGlpo0Pe2JAuDgYiYMTngSTQwoawQQ1AY8kB1KA/4/XPAffIDwBsuYBwOgR5VDGWJGGXAAk9Kg0fWJ4aiOm61PjynwxhA/McUJEDPIANGiDDATSwPD0hNQBEGMIE1JAAngRAT1n8h2hWF4BrRgGC/yDL//tIA8JkNuQA/xhpQ6TJHRrxtEfLip0A7/MQLzwhAv7LDHq8MASmLoAhCnhCzdDZKMxM4AAMMEDx7sSU5dXDC0fQQBcckACVAuB9QHEAZSGpwWsuhnUAAO3PYqrBeqg2TAowqATIIhYFDqAjD1heTNYKAI2m4VItKQCIkFerBbChDVCyTno6WskHIGAC83DAUmwzAQ5xSrQXIeYTiOSUClywAgjIwLsU0KpjiTVXAJitAlWygOXdLU0BYEhZISgTDBiUK6vTR12yCEEDGI8IJ1lvAApAHQ0CpR9P+CdGk9mP2zIVBB2gAAYNIDzHqoEhfKpIB7ILUPc+4ZU4A4ANHv/4DyI4YBlYXIYuQXe+DD0wAR2gYJ9s0I8FDCEKQ1qUx5QoISUqUCblDMATAPwE4xVAg4Xphy/TAID7PeFU7lVgBbwAxp4YIgAD0EAfNWhRBnShIkSQ3kO40BB9qgFJE+gAA9I8gTRc0JIbVdMxvaCqWqnKEKBliVfURxNDhHIIAZiAYwZ0KijIU7EXU6IBbHBbDQaZNgGAgCEkkLwJ1EPLASYPPdQAADKw+QkH1qBPIABcInhBnaA9gj4jiBHGCC/BBAIAUieAQo9gRskYqEAaZq0fAHghJAFgiRXTwAA2DEEMNG4A7jogEhM94R9I6kIUGOAABzCg00SK5MYO/MD/Cjw5gmnSwCYHamL8dQEC+50bRQvThgTk2dfLY+Rt68EF/jarHhIA9oE1YFjoSEAIrvaAatNgtiEM4QEFHwIClkGG+50ni8Q8wrMkvHAaZtchFejwVqH4j3+ArgsTECRZlM0GNkRIwl0IjIOkjW2NvZMBBajAB4yiwC5IWQ0MSADOuniAAAxmCGCqwDUBwIUuHOE7DxhAFlWyj7IyYDPrJYI+VGLL+7EBKeu1ElLLvExkvrofGtCAAUDXZvwdwQAEeMATgu6FAdDlAFJTNgHY4CAAdKE0blGmqjInIdrEqXgDpRJON+aBLs7bIXPTE3ok/Q98ikGhh/EC3RoyhH9A/2AASipq/tDzBLWQyLQNMcDyIFCPfUxeWB0YwPKu6eo3VvshNijsQyINtyN8uD9EfEiJaFIB66xEKomEyOSpYmiLJcALSnRAPngN6ckUdY0NXV6F7LcMBXhzeTzFAGr/CPqyK/H200GtVSuw8U//eaNcPw+fiwgRaT+EDd+cCRTK05A01N4jByDCQ7Q5EwMoGccde0lphQkbgFZMuJcEKBcG6Nc/lZBBLY+YPcQQ8JgJgd7yPIFy+Q/4McACMIACLUNsuNoDEsgyRNZKeFdD9I8GGFqzQET8Hc0EMJJDLAAVtQQRXJO/fUwaSIYtKdChJJQCiQZEmM/y0NwTDeHLYP8AGRhUGrxg5XXBSjmEDSDAZmFXBRgA1x2TcjjEAUgAND3EFg7I3X3Ea7VQqSHefRyWbu0WT3GGI+HZ8FUM7FhIAHRBB2zSE0BUS3hBtXHXExgK790RMFxNhGjgVSwAlTxAFwaFbmkUACBWS5DBGvqPBPCenDBi/9RDAhQQAuRKgLSBeUEEtY1G4GmMBwSIYKXZsOFNIgkWFKQZFBAQTWAVT9QGAzyAfPweVriaCOlf7NhE7t2Qs3iEKQEh8P1DEfVDGphhDE6iR2XeOX0M7JBgYjTEArwPBJGBEDiGfSiAAkbQFeHNTKyeMkkAFPTIzd0RCTFE74CEBJCPj/SMfZT/mvqdVmWcig0owATg32iAl8doiniQ0DtpUAdAQGXcx8JBwQCoQQxp1U7UEGJgYQhBxAQwInowyEc4x1SsxKnU3Uy4FQNEQT18XG+1BFJlVx8WU1e8IcWIkGmQUBQYnwE8ifvVgyEYymoYwBNgFSw1RKQ5AKG9xB21hDi+R6QdU2Do0nvNhBX1oUkeFADgYkPwmAIp40N4iZZ9hyhCIzjShClBwARUgKY5RBeMxIEBGgBUGTFZVV/4SXYtj0pI4/rpFksCAJgsUVDCmqXBlfHQnQao0RHkxhPmn+SMHBtARUpC42lIxmwVXRUSGwIMAGCkyd0QyPJAARCVXUYUAGTA/89WPsRQPkQ9pAEX0FAaLCF8XCQCeMYDvOIQJCJzQKV93KDHpMFd1sQDBUBdWFEEIQUFQgFrBMB5pNry4MRpuWVZQCRbEYz/ccxcishhzaFLaFBd+FlrVBVQQB4EQUBH6CbX1cRnDszKZUwpngYYudmtEVg/YOcEAFhl6CYEdQCFHFga0oQuGsxybkxzYkWpJYTmWFoCEIEBgEB0XFGZoR6oEckHmNRxLqLBfAo01qbuDaAlgR+QscHcLAB8AoBUFEABLAACfBo5AoCy0cY8CuX52ecoZkx+0kR+JABwxRas3Y8BJB/keUVHuIWOUCN5GEJDZBgXKNmCutFpQKhHxP8GhBbNUyYpVEKEgyYLkm4PJsnGbRkUED5ABUAPBR4BS9CI9ZHFhyrAPtSDuY2VWdRnVsDUOtLEPcbcEPgVCTpGSOTGB7imR9znoyjABl5AYBoRc2CANRqAYwXA7dQlbjoEoS2PVNxPARCqASxpODJoWUTBmiwEXDaENXIBJTbHZNzm8thRpYZno3AIt/3RrjlKgojHBBjoP5EB+YUSRLBB99XDJgJVRjrqRyDnqzVJPC3PSQAFTMWOAqTBEwToY9WTo9LGMhTWAvjDX9aFrdopo2APF5CFDMLo6xiIEEjVFT3A+3DBPCpIBZyEBpyPA+wpWfxqgHwn7SChdxWWYJX/ndBgAIcmn0OwwRnBVP+U2gQESD/85V62RJOKCrHh0i/2FJFihSv5BBF0wJ5CBDBEGwEAg4D0iUeYaU10ARfMmmX51kNg7EfQBtBcjwMA6b9OBszRBLQyyu9ZUWdeyYpq48R6gRhwR2QpwAeIUgYgwPVcxgSQAU/QEDEqopDWxCZKLK2B1XvYxDTxThx94mjcngulAd4EbLJ0AHFGKXz4Thsom8fBomt6wVfej6RZIcVC4T4kYLfhDyGCGBRySNpyFwjh6or6z5eR4EQSTVSY4Vr6DyctIxT4zhBAQRQcwGClStopSoqGigwa7bU6xBCMpZaxEETI2AREEQRthUNC/yDooNfytEEaOKP/GADQOUCZXZYaWKh6qGvFrtECIFsbTIBxHYAhkBBIAQAH0M0ENItPkI6hGMDL9cXcXBwVEsHnEgG3UeRDgOqjXA559YUtHYqVVcAR0FIXTYV9dMAhxV8HTMDNSW2XUSIGpEHxjewHDIEhbNUDEIGCbhQEsAGHBB3d6cMyPJC/nWhL7EOpKWQFGAfEfe7yaMCWSlUFdMBeKOsCGMLrPtBggBEXtIGJYIBkbAafLED86VpWHgtSTIC7VCqWoJ8+mErRgRMAMN3cYKWfXpE3lQbk9SH+nCBosTDQMMBJLA//2MAWPtqBIcDZKkABkNg/qAkBQKpWXP/IBSqTIQiBoMYRYwxIIinALFnFT3UBPIiBf/AJAhdZw1KtqCAnLPYUWehTWzJA0eyD+ZBHAKjBYKTHQukIjW1gBRhCkf2MDUyeVR2A6ILAmZGjAqCWdbwPPnEgU0IAQ1BgAdivGF4ca3bKXXRABjHET6mBB8DuEBQmldycRiRlegRV6YJOX3qabZBsnSZunQCvwLHNC0oSSLBXNQKnbqSPEptWafEXgKXXWeIWAIBA5/oiBDFEabEIk5EFBTIPWVCnNQ1tSyzGkABZT5DOBRGBwlVAbGwVAXzl6PSWAwQJFGgA8JJBr9VMK+4FX5wWVSavSmbJTvjE7h4ABzNJJnL/IJmWGgSxFjzHFmqpBHX+YEP4kmrcF3xpkJ5w6RHAM5By6vKAAEsoEeZE5EwcFgUd8BAQlyEAg4dECB4hLygKCk9a60cYnwVf8P/1g1jVxe1C0BuBlhpExT+xhDtDmaUuz6ZZVXSSNJ9kUP4sz3fsHKMNlhoc2PRY9EN0QP0Jo0itRoi2RATwnBvpyR09QBpIoxZrjJKJVUeIFQTRRV0uAJiowZOQHw/CagadlqRNlpbpxhFIExhNQAGM69tKwB/Rg1MmZ0sMAWe1hDdZBgZcRDiKEAYwAABrqk+irCgTH4FwWh82oAIFFZDtXDVWQKVx3A8rEMQBpzOdVwLs3BKS/581VVpIilkXLAMBnC4q9RgGRIVSAJ0xz0QBBHXHYqXjCjINRqIC/MMQFI/xlWhDPLV4YgCHLMA/rCf45Y8X2Ib73cXPRF4RtgZS0AMZdEBhkNBPpTHoZd6tfaVoDMETFIC1WpGezJgE6cMEJDRct0Q1WXDjtVD4jrNq+RVEBOPqEm1gw+Fk0E1SxpQnxUlCaQBWBiQBtI8a8FdF/hMQioQDxIYE8Gg2sVdfQC4XLLB2Kq1Ny+ppz4QHoDcC9DULzuD6WbQhNJlHCBvRlrPEJABSzJZpE4iELIO5BZnkudcROMgAVMYHZJBrNYQYfFplL4YD2AxQEaMCFJVC+NL+Nv+g1MotVkiTF+yOO0Wi/yAWLlYAPhVQiTsECXX0kvRjQ9gAVU+XpC2LAiHTgTPPE0BARbhXlD2EEDz2P20VBNUujXPqBNETDdeF6nrE2V6IR/0Dj96qB3wPWRjCP3Q0AzzBKjHVA2jOVeA2xmiU6kSQgLoXqb4qh5lIXRKB+jnQcH6Apds5NklTAHDBPBjAAChEnGQA/OYqi54WYtUMG8CD+M7EeoEOm0FRCNJaAkFQ0Ir3e6+kMu1qZiSRZHPGXk2kpF2cm/SINkLB/BLBUrwkLrKEBLcF97KBf+higPTPgNzze5bqfaSt59HgAvYhpX8qiEfMqe7VA0TB9tYSnVb/pbJepLtj01X8ntyCjwLIGJ8UTSbJB4R83JlFyAHYe73je9EwAPfq0jEZFsDLR5+0sRfI2D70Cb5nj733Axnn+sRkIr7fIllIRn5kD/gUDcW7TMijx8OHz/fIzl5qfPgEPJ9MPEuJvHy4muYcB3HYRrjcg23g/G7wQ83fBj8Yx270vOfcRnCEy214AJvjJ9F3DtAH/dB7Ts3zfOdIbtxUvdVfPdZnvdZvPdd3vdd/PdiHvdiPPdmXvdmfPdqLyrmmvdXnONsjDQd259ufzBDcA2PMfcr0SZK8Nd6bTGOxRtL3/cc4L1CwhtwL/sdEgAPIzt0j/sh4HALohSVxgK06/z7GQJikpQkEaLTlh4zhd/68tKydsMatN8qJJMxgQQnuQMmTtP7quz7sv77sxz7tz77t1/6TrD6VO8pdNyydsIQXqD7r377sr77x5z7yD//xK3/yL7/z5/7wr5SwzcMFzAMDXAADWD/2W79zEXz2X//3bz/4a3/4lz/5nz/4Cyj2qz8DsD/7P9e4QwwHJID1U//3c+/2c2/377/9zwP39j9AMJgwTyDBgRcYzJtwweA8hARBPCyI8ELEhA9BHAGwEUACjh9BhhQ5kmRJkyP9ETi5kmVLly9JtuFQ8sAEBxMQ7Hu578AFA22GvFTA5sKEAwpG7kvz0cNJBUPY6IQ59f+lPwZUsWbVWhJKBpEKEJAJEODIPwgLOA4RaIDN1zZHxmoI8ISjgnoOOngNqSAK3AEVAkSp28ZAAgQdP3osuc/AvwBQtkYOieCqZMuXWbZp8xHDgQQSBhjQF6ACkaAAFEz458BAgAsAdO7zwuCIhCeAnyQ4ghaAISL6yDx5gqEuggK2AUvQ0GFj5wpHlknosk8jx+okJ0gYYuAeZskIVHoXP35jmwxSvSTQpyaAAwBcxhrYuODIkQMAFgQ4DeBAAAljEWBjrADus0uCBNDigoJ+YPPiiAHGOkDAANTwArXs2iCuAsEU26jDkPr5QIIHAKjnQ/JgQkAvFFncah/NNnL/MAAyJiANgw4G6EIDDKCQYBkbNjKggo32QYC9ev5rY58B21DAgRE3GuKf+/D7rx64DFDgv8cUIMO0KANA68OmRsLgiMqioKfFqShb002s2qhHAQUSGFACIgJAAIEBFnhOgvDwU+MwBfIbED73HKhgggHSeMIQjro4AoN+0hvwCQkqMJOIZSpIgAukNiKjCw8TI8mBDieQ782WwFvVVZZeTODSJ2oEcIBlxKiAryc220gMDRxQIA0iMB2wi+gWYIAIBY5IgDgAMGADAkOg0EAC28Y6op4AHpiAiAhyAxUDAnSFbSnrRhqiAt4AOGKCV1dqE955R4InAaMMoS80ABgY/1IDtBTQqZ8h6lMAigDq6WCBZfxDwAYJDPCsuY1SgyAKDCpwgAEEPoAgAPmOIENdIJ9doIsnSCSVoxN16lIwGxZIII1n6R2p1ZpxLi+Nyij24gAxRoyKow/ICA2pNgKwEAAbhvACgWSf6Ifdftio4Im2tOR5CAnbgEeNBd7liAGy9sPgw+soBlsDpLJzAC0GcwZJ3rjphaKLAHrdiDUAnuAZ2ueo/PsIMTjy4h8F+gNJxAlABWACNYQAAO4j2ujvNAY/wBvIUlf+yJAE1DjiA/wqGOAwkKSCTXV4b6Z7Xs0SILOfA/5BQEtV5+MWJMslB0AsALzQ76MJzv0o5OZqXP+gP8E4ShXED9NAL+MP9gPgAQmgAFUnMbYGIQEDGGBDAbjftMp1ejNogw0JyMgeT7SsnnNSM3cDiQxFP0CAtKUD6KIfDIB0gAFEoXEA6JEDDrAATCnAEB+D1kYQIIEJkE9lKlNAFxzwgH8UbyMHkAAXOsAABpDhP3dywP3+AplVte58rjIPALbDPhsBwAH/MJmqhKWB0dUFCs/Bk3wUEAAufMA+G5FWF2g2lCNUQCxLyU8FhpCGR2GgDX37yD64kBikQOEIF3xMSBaWADKIEQrVw0+NJkgzFpmvha+CQt6g8ASyIKUDpNGAPpbxrDrWY3MUgwveoMWeAWCKNwp0gA3/Gme2sbhHAXK0jQSoNAQJpKFxH1JMGtqyADO6ZB/rq0fqWMTCNq7pRSvizyRRw7BRsUEfDCAOBmp0urrUyXb5gUCGhMQbYBDBAiBRAMNAALzSMeCC64KWiMigE7N9ZGYA0EDeHkiVg/UKlOKZ2yjdBAXmccQQT+jCtcIGADb8ow1w68ATCgi829zvix6qgBcYpMB6SI5mHZBAogCpt39FyXQVRIw4K8AAIFFwKtmxEEG9I0psoqgfmgHlPgoAIXR+ZH1uA0YDJNAWkChwLGT4iBeeBAVDXPBEqPkjEZLYhQ0tAKSXNB5H6HMEAixAATZQ40sCWk3xsHGha+qKSIYw/wFDvLIu9qRQAMLZmS5MoB5LTScAqhiAAfxFAV5owwSigBYvEMABXqhmD8fyD8VYEiRt4AKE/AYTHXFEp6vTikJ7Oh4YwWQBdUUNX/44lkdBKywOyBv3EAAFMnhMqtUZigPSECyQYIBQoEIb2j7ShkwhlCVDCMAH5oc6y1wzruMpZVtXwpexSAAu7FHhASpQgW+G0wsG+M8S53IECymgNcOSgNJIQlagSuCpKyFOI0mzQ86IgV1ZgWtnMTNXutbmPxPI3P5gGYCreGEAj+oHMCTwDwixoVYqGQIRoOi4kobkbCThQnE5QlmRPOABPRpfeiMYAOtmhaeretac8ItfN/9m4KYr6Qc95iJHdG6pJhndyATKpQA8aQAwDOjPE0zTKYDx6iS6FUkUKKlGu/S3JNriCAYiyIYEQJMqx3WTWAYUAA666UUkNgkGktUaO1XoCGkgoTGrBIUDRKFOKU5AAxnwHyRupF+4LRMHIcuZJR6AZNabrFTUy5ETpkV39HAWaFlSX1fF7ABdPsCZ4PXClijAahKoI4UegFQHUAADBrDQPhbggOzNJaDZOpgQiFA5YkKLALWbWG45NxJhTZRq/3GA7TjMoElV6XQLeALzTrUVEzMUho3rx23DvM2VZG4IGIgWVg/AgAQ8QJYLcO27+oMWKjJAxzszwEw6mIYKqPD/JGTaSJI/SjkAiGECTxDpMm4Tsf4awK/1yNizTgWqY/UOK5ylFwJw3aJ9/HTMaUAQRwwwgfwQjkhL3E9iQdWPnfWlcQLqQm9HYmHOPIUIWaojJjXJgTakwT/p7AyFEhA4KByOYhUIXLMBhbMRv87FJmngffpxZ8vuJz97ZZBlebOt/Elg0TR0T3pNYoPyhuQBgNF2oiaQVy6QsAAZAhJSGCSGPH1EgRptcwX6iBUtzwsD+lgAlsnzok++JAEVUFKdFtDACTBWcrnBLQZswwAFwlx/CHgWAmrH4XQHui5jO2oHMLCtAUHHAMvIdmHSUIClPkEjz4qAAShgRA0QAb0l/w44vd4Cd1Oy5IIf3F9+HACCTJGuizC9mxw1grQEdEFJGAAB3nDOlJeKJNRsYNcQomCALhhA8tZOwOULUIAEaGzRcQ7Al2q1SRtAWXVRhmBa5zVweLWYKl7A08wU4BgNpOFTG1HpAvr45faUaCxoLQ8EQIBukKibJKA1PekKsB9CIbaAApNfVYXPkUm7KYjRZ5F5pH4SYJTGEEhbl5kSgJR96Ki4mSMDAigwxyhI4Co8wd5J+rFx/77ETFFAbThtTwQEeMELQ0CAAc5KDYrlCeSkJGbOjaKNlJRLJJ5F6shsLNTgNMzmCe4DAzQAdzbiYLJFadpgNSxEf9qOvKjuMv/6oTD2QQ34BHWyQwDVoAIMoNMKB8HIQPimr0Xir+DeRMxGAm6iDAHAi9ZQ45yI4EnQhkGyQwOq5wBk7VSEJ/uWCV3EIz/QIgo26cNerAAoCSVQ71UChl6mLUNK4ilgsEyQIuZQY94GCKEMwcg4olsMoAPyBS3MsHPoEDN4Yu9cQurIwAEq7iNqELm0QgdRg2KixQHY41gipzkQpw3YEG74Ak+k6uLoaQgqxwo/4gNkTB/kYx82ByyGQOMWTzzqA56YjSoUbJ4mYwsBUTJeRNOgRQEYgN7G4gk6AARUTQE6wGoCIAH6ITag5QAMcUDG5iqIg2AoxOY+glAyYkDoTWv/gjFMiO8y0kMCCvCtJKDt/nAVqUIQY2YsMuVuZgRUhuAJ0mABzGYZ6qJWdhEDBiRsYDEAOsBgKE765IgscqWjKIYA1CBLDiZmQlE8OqlOuKALQrAlZi0kDlAbXUSbYIoc6widkOZSFAADGOAfmGPXJCByiKNGjEojAEO6UINYUsYAyGBzjARbsgjF3gUDuqCfAACD/smfyAMDJOnfYOImJuPtFFIyxEySxiIN5GII8sMAfK0iaY0oxWYW74biHIAsKuADiODaACBzUqY/ssVGWuMIniBmZCtGnhIAbK1dyIOg8i4rkCYNCEj6VHEnsaLFoMAHPzIw/sEAMAar9IHt/zZCaiSAAwxhAuqIPfyjjgJLvuDi3PIy2QRiS8YCTxCgP9gALsKvd2zCn8ZrPIRgSD4CbvqQJKjFg7ZJRdgyuShAOdhuQAxhbMQg2wBg/xikkypgGciMCI4ghLzRCw5ERPBDo1DDS8CGNNxltLxAAxBEP9SiAYUE5eSvRTAAAtoi5mgqmk4CCpbl9ELzMuChAFYSPxgAs9pFTy5yPp7kXVROuBCgHpxGQJwEA6SCR0IHKSogmIiDARxgCLbma6ToI77M3+owJtckCoRHdcxGN5eGM0CiHwzhLCBIJ6uTKqgoOA5qPjwi0j7iYAzTpOLxI1RzAKqHTpCKIzpAA4wMz/+0JIHy8kYskjOSc02acjNGD2m6qhQzEzo7jjecbUGpggPqIQ2yUG+6wwCmc2Xcg2YUKJwU4JYA4B/8ZpwkUHA2xzaJSYI+wrIElDJZbCMayELiTALaoE78qrfYYB7qSrJSZjXX0kZdQjOqSGkkST4MAAIaR1gwEFrC7pWa0kJCxw8xjXz6JSkJ6AkkcTXV4KkeywaJI0TYLzUOZK/EgGEkQLiIxAsIqwD+LRvNtCTMYx86QB8QhDEBoDWcDlQqqoCI6GP6QwI24j+84Dm9oAIgKRkvZTv/AwoWoAUnBgPS4AhS5lmicTwQQI7aQETSYBkgMcW+JDP3YRk8KhUrNRD/+WsqiWUsgkJAbtXP8IMIylGN9OcnoWUsamQ626ydmgMK9MExhgRjpAtiYEMBCuAJqidFvUMnCiUq8aZQeKUNokBP8PUt1acN+oUBdAo0l5Uqpm2b1HUs0MIqyWBsjlJ4yMcnw6aEQIAWQYVhSExEyGIj5AIeIeZZQOAfdHNXvaMf6mECGKAeRkcB2sABVPYzBoA9JEANnsADLk9mXVEtAxZOSKwph0AI6mgl+yVlcPFHm8OyXhAKBJBELOsqGKQNJGCvOIIN1OCQvuv9POg7J0AfggIUoRBFEs8l5pBSb/aKBFFvjOUj1u90MAb1nstgh0YNhi5UsgQkpGVAAifN5lzJ9kaFPytzPI6PTco0bGPCxWZVr0BiW3wuzuI0VLwRJISANMxTSPqrKXexrPrHdnpoI8IyARggA6JgcwmAAT43dEF3dEW3dEn3dDNgdDOgHvg1Az63DV6XAfh1dmVXdgmgHgggdVv3dS3gbwE3JDAAHjSmHqLAdTf3SjxXhPi1HgwAQrwRd11XdH2UAaIgd2O3HikkemsXdhNle0s2CqLDUtIHbQ5ACPIVX9E3fdV3fdkXXzmAfeEBftf3LfG1IH9XJFIOfekXAdpAT/ZXT953fts3sNx3gBEAHv4XfQM4fXWMIwICADs=\">",
                                    "score": "5",
                                    "selectitems": [

                                    ],
                                    "answer": "",
                                    "diff": "3",
                                    "analysis": "",
                                    "extend": {
                                        "knowledges": [
                                            {
                                                "id": "118840",
                                                "name": "10以内数的认识"
                                            }
                                        ],
                                        "testingpoints": [

                                        ],
                                        "chapters": [
                                            {
                                                "id": "96868",
                                                "name": "1.数一数"
                                            }
                                        ],
                                        "abilitytest": [

                                        ],
                                        "dispower": 0,
                                        "totaltime ": 0
                                    }
                                }
                            ],
                            "score": 5,
                            "answer": "",
                            "diff": 0,
                            "analysis": "",
                            "extend": {

                            }
                        }
                    ]
                }
            ]
        }
    ],
    "answertime": 0,
    "score": 26,
    "kpcoverage": 0,
    "diffdegree": 0,
    "reliability": 0,
    "validity": 0,
    "extend": {
        "courseid": "",
        "coursename": "",
        "grade": "",
        "year": 0,
        "month": 0,
        "province": "",
        "city": "",
        "area": "",
        "auditor": "",
        "auditschool": "",
        "author": "",
        "authorcchool": ""
    },
    "numbers": 14
};

var answerjson = {"anuuid":"","anstuid":"stu111222","aname":"学生姓名","anstartime":1490342672,"anendtime":1490342697,"score":4,"actualscore":1,"ans":[{"stuqueid":"1123000","queid":"a0c9dd2808ae5da26a90eecb20f7931f","pascore":1,"score":0,"etags":0,"quetype":"1","isanswer":1,"whenlong":0,"result":"第一题[img]http://g.hiphotos.baidu.com/image/h%3D360/sign=07ad353ef403738dc14a0a24831ab073/08f790529822720eb25fa86479cb0a46f31fab9f.jpg[/img][img]http://f.hiphotos.baidu.com/image/h%3D360/sign=e105b9f1d61b0ef473e89e58edc651a1/b151f8198618367a9f738e022a738bd4b21ce573.jpg[/img]","status":0},{"stuqueid":"1123000","queid":"0522e58dc4db5a4e29fa3db3af691c75","pascore":1,"score":0,"etags":0,"quetype":"1","isanswer":1,"whenlong":0,"result":"第二题","status":0},{"stuqueid":"1123000","queid":"55893787cb404d2c3e7e53a7ec8c8381","pascore":1,"score":0,"etags":0,"quetype":"1","isanswer":1,"whenlong":0,"result":"第三题<br/>2<br/>5555","status":0},{"stuqueid":"1123000","queid":"6dc1a33059ad9092a29e2801e970ee17","pascore":1,"score":0,"etags":0,"quetype":"1","isanswer":1,"whenlong":0,"result":"第四题","status":0},{"stuqueid":"1123005","queid":"6b6a6b3eeb6aad35464e8819e52de7f3","pascore":1,"score":0,"etags":0,"quetype":"1","isanswer":1,"whenlong":0,"result":"555555<br/>5555","status":0},{"stuqueid":"1123005","queid":"bb460b745bcf072df048ae28f08715ab","pascore":1,"score":0,"etags":0,"quetype":"1","isanswer":1,"whenlong":0,"result":"66666","status":0},{"stuqueid":"1123005","queid":"d319cd4eb294555355e206417be02a9c","pascore":1,"score":0,"etags":0,"quetype":"1","isanswer":1,"whenlong":0,"result":"777777777","status":0},{"stuqueid":"1123005","queid":"eb146227eb75898b474e5ad08e9a1196","pascore":1,"score":0,"etags":0,"quetype":"1","isanswer":1,"whenlong":0,"result":"8888888","status":0},{"stuqueid":"1123010","queid":"1123010","pascore":6,"score":0,"etags":0,"quetype":"1","isanswer":1,"whenlong":0,"result":"99999999","status":0},{"stuqueid":"1152575","queid":"1152575","pascore":2,"score":0,"etags":0,"quetype":"1","isanswer":1,"whenlong":0,"result":"10第十题","status":0},{"stuqueid":"1152576","queid":"1152576","pascore":3,"score":0,"etags":0,"quetype":"1","isanswer":1,"whenlong":0,"result":"11111111111","status":0},{"stuqueid":"1122984","queid":"1122984","pascore":1,"score":1,"etags":1,"quetype":"0","isanswer":1,"whenlong":0,"result":"B","status":1},{"stuqueid":"1122983","queid":"1122983","pascore":1,"score":0,"etags":0,"quetype":"0","isanswer":1,"whenlong":0,"result":"C","status":1},{"stuqueid":"1152574","queid":"1152574","pascore":5,"score":0,"etags":0,"quetype":"1","isanswer":1,"whenlong":0,"result":"141414141414","status":0}]};

var commentsjson = {"comments":[{"ownerid":"a0c9dd2808ae5da26a90eecb20f7931f","thworkid":"","stuid":"stu111222","ownertype":"2","type":"1"},{"ownerid":"a0c9dd2808ae5da26a90eecb20f7931f","thworkid":"","stuid":"stu111222","teacherid":"aaaa","doroomworkid":"bbb","ownertype":"2","type":"2","commenttype":"1","comment":"评论333355555"},{"ownerid":"a0c9dd2808ae5da26a90eecb20f7931f","thworkid":"","stuid":"stu111222","teacherid":"aaaa","doroomworkid":"bbb","ownertype":"2","type":"2","commenttype":"2","comment":"http://music.baidu.com/abb.mp3","voicetime":"23"},{"ownerid":"a0c9dd2808ae5da26a90eecb20f7931f","thworkid":"","stuid":"stu111222","teacherid":"aaaa","doroomworkid":"bbb","ownertype":"2","type":"2","commenttype":"1","comment":"aaaaaa"},{"ownerid":"55893787cb404d2c3e7e53a7ec8c8381","thworkid":"","stuid":"stu111222","ownertype":"2","type":"1"},{"ownerid":"55893787cb404d2c3e7e53a7ec8c8381","thworkid":"","stuid":"stu111222","teacherid":"aaaa","doroomworkid":"bbb","ownertype":"2","type":"2","commenttype":"1","comment":"评论4444444444"},{"ownerid":"55893787cb404d2c3e7e53a7ec8c8381","thworkid":"","stuid":"stu111222","teacherid":"aaaa","doroomworkid":"bbb","ownertype":"2","type":"2","commenttype":"2","comment":"http://music.baidu.com/abb.mp3","voicetime":"13"},{"ownerid":"55893787cb404d2c3e7e53a7ec8c8381","thworkid":"","stuid":"stu111222","teacherid":"aaaa","doroomworkid":"bbb","ownertype":"2","type":"2","commenttype":"1","comment":"aaaaaa"}]};

var piyuejson = {"anuuid":"","depid":"stu111222","marktype":1,"answerbean":{"anuuid":"","anstuid":"undefined","score":77,"actualscore":20,"ans":[{"queid":"a0c9dd2808ae5da26a90eecb20f7931f","quetype":"1","pascore":1,"score":"1","etags":1,"status":1},{"queid":"0522e58dc4db5a4e29fa3db3af691c75","quetype":"1","pascore":1,"score":"1","etags":1,"status":1},{"queid":"55893787cb404d2c3e7e53a7ec8c8381","quetype":"1","pascore":1,"score":"1","etags":1,"status":1},{"queid":"6dc1a33059ad9092a29e2801e970ee17","quetype":"1","pascore":1,"score":"1","etags":1,"status":1},{"queid":"6b6a6b3eeb6aad35464e8819e52de7f3","quetype":"1","pascore":1,"score":"1","etags":1,"status":1},{"queid":"bb460b745bcf072df048ae28f08715ab","quetype":"1","pascore":1,"score":"1","etags":1,"status":1},{"queid":"d319cd4eb294555355e206417be02a9c","quetype":"1","pascore":1,"score":"1","etags":1,"status":1},{"queid":"eb146227eb75898b474e5ad08e9a1196","quetype":"1","pascore":1,"score":"1","etags":1,"status":1},{"queid":"1123010","quetype":"1","pascore":6,"score":"5","etags":1,"status":1},{"queid":"1152575","quetype":"1","pascore":2,"score":"1","etags":0,"status":1},{"queid":"1152576","quetype":"1","pascore":3,"score":"2","etags":1,"status":1},{"queid":"1152574","quetype":"1","pascore":5,"score":"3","etags":1,"status":1}]}};