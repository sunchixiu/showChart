/**
 * Created by sun on 2015/10/28.
 */
document.addEventListener('touchstart', function(){});
document.documentElement.style.fontSize=document.documentElement.clientWidth/18+'px';
document.onselectstart = function(){
    return false;
};
