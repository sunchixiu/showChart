/**
 * Created by Wilson on 2017/9/19.
 */
document.addEventListener('touchstart', function(){});
var basesize = document.documentElement.clientWidth/36;
//if(basesize > 12){
//    basesize = 12;
//};
document.documentElement.style.fontSize = basesize + 'px';

//var urlapi = 'http://laiduila.jiayeda.com.cn/ldl/weixin/';
var urlapi = 'http://182.92.182.224/ldl/weixin/';